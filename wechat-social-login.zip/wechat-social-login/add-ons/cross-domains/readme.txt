共用微信支付或微信登录步骤：

1、确定一个主站A，作为代理登录目标站点
2、修改跨域文件cross-domain-wechat-mp.php的第2、3行，把appid和secret填入第2，3行
3、把修改后跨域文件全部上传到A根目录
4、选定一个子站B，安装wechat-social微信登录插件，启用跨域，跨域URL填入www.A.com/cross-domain-wechat-mp.php