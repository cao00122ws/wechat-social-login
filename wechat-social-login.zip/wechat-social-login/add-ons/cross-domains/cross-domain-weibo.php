<?php 
define ( 'XH_WEIBO_APPID', '1395788534' );
define ( 'XH_WEIBO_APPSECRET', '53177994de6110977df354f249a127e4' );

if(file_exists('wp-load.php')){
    define('WP_USE_THEMES', false);
    require_once 'wp-load.php';
}

if(!XH_WEIBO_APPID||!XH_WEIBO_APPSECRET){
    echo '<h2>请正确配置AppID,AppSecret ！</h2>';
	exit;
}

if(!function_exists('curl_init')){
    echo '<h2>系统缺失php curl组件 ！</h2>';
    exit;
}

function wsocial_session_set($key,$val,$save=true){
    if(class_exists('XH_Social')){
        return XH_Social::instance()->session->set($key, $val);
    }else{
        if(!isset($_SESSION)){
            @session_start();
        }

        $_SESSION[$key]=$val;

        if($save){
            @session_commit();
        }
    }
}

function wsocial_session_get($key,$default=null){
    if(class_exists('XH_Social')){
        return XH_Social::instance()->session->get($key, $default);
    }else{
        if(!isset($_SESSION)){
            @session_start();
        }

        return isset($_SESSION[$key])?$_SESSION[$key]:$default;
    }
}

function generate_hash(array $datas,$hashkey){
    ksort($datas);
    reset($datas);
     
    $arg  = '';
    $index=0;
    foreach ($datas as $key=>$val){
        if($key=='hash'){
            continue;
        }
        
        if(is_null($val)||$val===''){
            continue;
        }

        if(!is_string($val)&&!is_numeric($val)){
            continue;
        }
        
        if($index++!=0){
            $arg.="&";
        }
        
        $arg.="$key=$val";

    }
  
    return md5($arg.$hashkey);
}
function http_get($url,$require_ssl=false){
    if (! function_exists('curl_init')) {
        throw new Exception('php libs not found!', 500);
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    if($require_ssl){
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        //加载wordpress自带的证书
        if(defined('ABSPATH')){
            curl_setopt( $ch, CURLOPT_CAINFO, ABSPATH . WPINC . '/certificates/ca-bundle.crt');
        }
    }else{
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    }

    $response = curl_exec($ch);
    $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($httpStatusCode != 200) {
        throw new Exception("status:{$httpStatusCode},response:$response,error:" . $error, $httpStatusCode);
    }

    return $response;
}
function remove_emoji($source) {
    return preg_replace_callback( '/./u',function (array $match) {
            return strlen($match[0]) >= 4 ? '' : $match[0];
    },
    $source);
}
function get_uri_without_params($uri,&$params=array()){
    $urls = explode('?', $uri);
    $qty =count($urls);
    if($qty<=1){
        return $uri;
    }

    $paramcs = explode('&', $urls[1]);
    foreach ($paramcs as $paramc){
        $ps = explode('=', $paramc);
        if(count($ps)!=2){
            continue;
        }

        $params[urldecode($ps[0])]=urldecode($ps[1]);
    }

    return $urls[0];
}

function get_location_uri(){
    $protocol = (! empty ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] !== 'off' || $_SERVER ['SERVER_PORT'] == 443) ? "https://" : "http://";
    return $protocol.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
}

function xh_weibo_user_sync_to_remote($userInfo,$callback){
    if(!$userInfo){
        echo 'Ops,Something is wrong!';
        exit;
    }

    if(function_exists('do_action')){
        do_action('xh_social_authorized',array(
            'nickname'=>$userInfo['nickname'],
            'sex'=>$userInfo['gender'],
            'province'=>$userInfo['province'],
            'city'=>$userInfo['city'],
            'country'=>'china',
            'img'=>$userInfo['img']
        ),$callback,array(
            'key'=>'social_weibo',
            'name'=>'微博'
        ));
    }
    $new_request = array();
    foreach ($userInfo as $key=>$val){
        if(is_null($val)||$val===''){continue;}
        if(!is_string($val)&&!is_numeric($val)){continue;}
        $new_request[$key]=$val;
    }
    $hash =generate_hash($new_request,XH_WEIBO_APPSECRET);
    ?>
	<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport"content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		    <title>微博登录</title>
		</head>
		<body>
		<p style="margin:50px 0 0 0;text-align:center;"><img src="data:image/gif;base64,R0lGODlhEAAQAPQAAP///2R1cfb397jAvuzu7o+bmK63tWR1cZqlonqJhs3S0djc23GAfcPKyGd4dIWTkKSuq2R1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cSH5BAkKAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOw=="  width="16" height="16" alt=""/> 登录中，请稍候... </p>
		 <form action="<?php print $callback?>" method="post" id="form-qq-jsapi-auth">
		 	<textarea style="display:none" name="userdata" ><?php echo base64_encode(json_encode($new_request));?></textarea>
		 	<input type="hidden" value="<?php echo $hash?>" name="user_hash"/>
		 </form>
		 <script type="text/javascript">
		 setTimeout(function(){document.getElementById('form-qq-jsapi-auth').submit();},1500);
		 </script>
		</body>
		</html>
	<?php 
	exit;
}
function xh_weibo_authorize_failed($e=null){
    if($e){
        if($e instanceof Exception){
            $e = $e->getMessage();
        }
    }
    ?>
	<html>
	<head>
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
	    <title>登录失败</title>
	    <style type="text/css">
	       html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{line-height:1.6;font-family:Helvetica Neue,Helvetica,Arial,sans-serif}*{margin:0;padding:0}a img{border:0}a{text-decoration:none}@font-face{font-weight:400;font-style:normal;font-family:weui;src:url('data:application/octet-stream;base64,AAEAAAALAIAAAwAwR1NVQrD+s+0AAAE4AAAAQk9TLzJAKEx1AAABfAAAAFZjbWFw64JcfgAAAhQAAAI0Z2x5ZvCBJt8AAARsAAAHLGhlYWQIuM5WAAAA4AAAADZoaGVhCC0D+AAAALwAAAAkaG10eDqYAAAAAAHUAAAAQGxvY2EO3AzsAAAESAAAACJtYXhwAR4APgAAARgAAAAgbmFtZeNcHtgAAAuYAAAB5nBvc3RP98ExAAANgAAAANYAAQAAA+gAAABaA+gAAP//A+kAAQAAAAAAAAAAAAAAAAAAABAAAQAAAAEAAKZXmK1fDzz1AAsD6AAAAADS2MTEAAAAANLYxMQAAAAAA+kD6QAAAAgAAgAAAAAAAAABAAAAEAAyAAQAAAAAAAIAAAAKAAoAAAD/AAAAAAAAAAEAAAAKAB4ALAABREZMVAAIAAQAAAAAAAAAAQAAAAFsaWdhAAgAAAABAAAAAQAEAAQAAAABAAgAAQAGAAAAAQAAAAAAAQOqAZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6gHqDwPoAAAAWgPpAAAAAAABAAAAAAAAAAAAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAAAAAUAAAADAAAALAAAAAQAAAFwAAEAAAAAAGoAAwABAAAALAADAAoAAAFwAAQAPgAAAAQABAABAADqD///AADqAf//AAAAAQAEAAAAAQACAAMABAAFAAYABwAIAAkACgALAAwADQAOAA8AAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAAAMQAAAAAAAAADwAA6gEAAOoBAAAAAQAA6gIAAOoCAAAAAgAA6gMAAOoDAAAAAwAA6gQAAOoEAAAABAAA6gUAAOoFAAAABQAA6gYAAOoGAAAABgAA6gcAAOoHAAAABwAA6ggAAOoIAAAACAAA6gkAAOoJAAAACQAA6goAAOoKAAAACgAA6gsAAOoLAAAACwAA6gwAAOoMAAAADAAA6g0AAOoNAAAADQAA6g4AAOoOAAAADgAA6g8AAOoPAAAADwAAAAAALgBmAKIA3gEaAV4BtgHkAgoCRgKIAtIDFANOA5YAAAACAAAAAAOvA60ACwAXAAABDgEHHgEXPgE3LgEDLgEnPgE3HgEXDgEB9bz5BQX5vLv5BQX5u6zjBQXjrKvjBQXjA60F+by7+gQE+ru8+fy0BOSrq+QEBOSrq+QAAAIAAAAAA7MDswALACEAAAEOAQceARc+ATcuAQMHBiIvASY2OwERNDY7ATIWFREzMhYB7rn7BQX7ucL+BQX+JHYPJg92DgwYXQsHJggKXRgMA7MF/sK5+wUF+7nC/v31mhISmhIaARcICwsI/ukaAAADAAAAAAOtA6sACwAZACIAAAEOAQceARc+ATcuAQMUBisBIiY1ETY3MxYXJy4BNDYyFhQGAfC49gUF9ri++gUF+poKBxwHCgEILAgBHxMZGSYZGQOrBfq+uPYFBfa4vvr9dQcKCgcBGggBAQg5ARklGRklGQAAAAACAAAAAAOSA8IADQAfAAABDgEHERYEFzYkNxEuARMBBi8BJj8BNh8BFjclNh8BFgH0gchUCQEDkZEBAwlUyHr+vwQDlAMCFQMDegMEAScEAxMDA8IePRz+w9TwJCTw1AE9HD3+3f7DAgOZBAMcBANdAgL2AwMTBAADAAAAAAOCA7AADQAZACIAAAEOAQcRHgEXPgE3ES4BBzMWFQcGByMmLwE0EyImNDYyFhQGAfV7wVEJ+YuL+QlRwZIuCQoBBCIEAQogDhISHBISA7AdOxr+z8vnIyPnywExGjv3AQjYBAEBBNgI/rETHBISHBMAAAACAAAAAAO9A70AFwAjAAABLgE/AT4BHwEWMjclNhYXJxYUBwEGJiclJgAnBgAHFgAXNgABIAUCBQMFEAdiBxIGARMHEQYCBgb+0AYQBgIcBf79x77/AAUFAQC+xwEDAccGEQcEBwIFTAQF5QYBBgIGEAb+1QYBBqzHAQMFBf79x77/AAUFAQAABAAAAAADrwOtAAsAFwAtADEAAAEOAQceARc+ATcuAQMuASc+ATceARcOARMFDgEvASYGDwEGFh8BFjI3AT4BJiIXFjEXAfW8+QUF+by7+QUF+bus4wUF46yr4wUF4yv+9gcRBmAGDwUDBQEGfQUQBgElBQELDxQBAQOtBfm8u/oEBPq7vPn8tATkq6vkBATkq6vkAiLdBQEFSQUCBgQHEQaABgUBIQUPCwQBAQAAAAABAAAAAAO7AzoAFwAAEy4BPwE+AR8BFjY3ATYWFycWFAcBBiInPQoGBwUIGQzLDSALAh0MHgsNCgr9uQscCwGzCyEOCw0HCZMJAQoBvgkCCg0LHQv9sQsKAAAAAAIAAAAAA7gDuAALABEAAAEGAgceARc2JDcmABMhETMRMwHuvP0FBf28xQEABQX/ADr+2i35A7gF/wDFvP0FBf28xQEA/d4BTv7fAAAEAAAAAAOvA60AAwAPABsAIQAAARYxFwMOAQceARc+ATcuAQMuASc+ATceARcOAQMjFTM1IwLlAQHyvPkFBfm8u/kFBfm7rOMFBeOsq+MFBePZJP3ZAoMBAQEsBfm8u/oEBPq7vPn8tATkq6vkBATkq6vkAi39JAADAAAAAAPDA8MACwAbACQAAAEGAAcWABc2ADcmAAczMhYVAw4BKwEiJicDNDYTIiY0NjIWFAYB7sD+/AUFAQTAyQEHBQX++d42CAoOAQUEKgQFAQ4KIxMaGiYaGgPDBf75ycD+/AUFAQTAyQEH5woI/tMEBgYEASwIC/4oGicZGScaAAAEAAAAAAPAA8AACAASAB4AKgAAAT4BNCYiBhQWFyMVMxEjFTM1IwMGAAcWBBc+ATcmAgMuASc+ATceARcOAQH0GCEhMCEhUY85Ock6K83++AQEAQjNuf8FBf/Hq+MEBOOrq+MEBOMCoAEgMSAgMSA6Hf7EHBwCsQT++M25/wUF/7nNAQj8pwTjq6vjBATjq6vjAAAAAwAAAAADpwOnAAsAFwAjAAABBycHFwcXNxc3JzcDDgEHHgEXPgE3LgEDLgEnPgE3HgEXDgECjpqaHJqaHJqaHJqatrn1BQX1ubn1BQX1uajfBATfqKjfBATfAqqamhyamhyamhyamgEZBfW5ufUFBfW5ufX8xwTfqKjfBATfqKjfAAAAAwAAAAAD6QPpABEAHQAeAAABDgEjLgEnPgE3HgEXFAYHAQcBPgE3LgEnDgEHHgEXAo41gEmq4gQE4qqq4gQvKwEjOf3giLUDA7WIiLUDBLSIASMrLwTiqqriBATiqkmANP7dOQEZA7WIiLUDA7WIiLUDAAACAAAAAAPoA+gACwAnAAABBgAHFgAXNgA3JgADFg4BIi8BBwYuATQ/AScmPgEyHwE3Nh4BFA8BAfTU/uUFBQEb1NQBGwUF/uUDCgEUGwqiqAobEwqoogoBFBsKoqgKGxMKqAPoBf7l1NT+5QUFARvU1AEb/WgKGxMKqKIKARQbCqKoChsTCqiiCgEUGwqiAAAAABAAxgABAAAAAAABAAQAAAABAAAAAAACAAcABAABAAAAAAADAAQACwABAAAAAAAEAAQADwABAAAAAAAFAAsAEwABAAAAAAAGAAQAHgABAAAAAAAKACsAIgABAAAAAAALABMATQADAAEECQABAAgAYAADAAEECQACAA4AaAADAAEECQADAAgAdgADAAEECQAEAAgAfgADAAEECQAFABYAhgADAAEECQAGAAgAnAADAAEECQAKAFYApAADAAEECQALACYA+ndldWlSZWd1bGFyd2V1aXdldWlWZXJzaW9uIDEuMHdldWlHZW5lcmF0ZWQgYnkgc3ZnMnR0ZiBmcm9tIEZvbnRlbGxvIHByb2plY3QuaHR0cDovL2ZvbnRlbGxvLmNvbQB3AGUAdQBpAFIAZQBnAHUAbABhAHIAdwBlAHUAaQB3AGUAdQBpAFYAZQByAHMAaQBvAG4AIAAxAC4AMAB3AGUAdQBpAEcAZQBuAGUAcgBhAHQAZQBkACAAYgB5ACAAcwB2AGcAMgB0AHQAZgAgAGYAcgBvAG0AIABGAG8AbgB0AGUAbABsAG8AIABwAHIAbwBqAGUAYwB0AC4AaAB0AHQAcAA6AC8ALwBmAG8AbgB0AGUAbABsAG8ALgBjAG8AbQAAAAIAAAAAAAAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAECAQMBBAEFAQYBBwEIAQkBCgELAQwBDQEOAQ8BEAERAAZjaXJjbGUIZG93bmxvYWQEaW5mbwxzYWZlX3N1Y2Nlc3MJc2FmZV93YXJuB3N1Y2Nlc3MOc3VjY2Vzc19jaXJjbGURc3VjY2Vzc19ub19jaXJjbGUHd2FpdGluZw53YWl0aW5nX2NpcmNsZQR3YXJuC2luZm9fY2lyY2xlBmNhbmNlbAZzZWFyY2gFY2xvc2UAAAAA') format('truetype')}[class*=" weui_icon_"]:before,[class^=weui_icon_]:before{font-family:weui;font-style:normal;font-weight:400;speak:none;display:inline-block;vertical-align:middle;text-decoration:inherit;width:1em;margin-right:.2em;text-align:center;font-variant:normal;text-transform:none;line-height:1em;margin-left:.2em}.weui_icon_circle:before{content:"\EA01"}.weui_icon_download:before{content:"\EA02"}.weui_icon_info:before{content:"\EA03"}.weui_icon_safe_success:before{content:"\EA04"}.weui_icon_safe_warn:before{content:"\EA05"}.weui_icon_success:before{content:"\EA06"}.weui_icon_success_circle:before{content:"\EA07"}.weui_icon_success_no_circle:before{content:"\EA08"}.weui_icon_waiting:before{content:"\EA09"}.weui_icon_waiting_circle:before{content:"\EA0A"}.weui_icon_warn:before{content:"\EA0B"}.weui_icon_info_circle:before{content:"\EA0C"}.weui_icon_cancel:before{content:"\EA0D"}.weui_icon_search:before{content:"\EA0E"}.weui_icon_clear:before{content:"\EA0F"}[class*=" weui_icon_"]:before,[class^=weui_icon_]:before{margin:0}.weui_icon_success:before{font-size:23px;color:#09bb07}.weui_icon_waiting:before{font-size:23px;color:#10aeff}.weui_icon_warn:before{font-size:23px;color:#f43530}.weui_icon_info:before{font-size:23px;color:#10aeff}.weui_icon_success_circle:before,.weui_icon_success_no_circle:before{font-size:23px;color:#09bb07}.weui_icon_waiting_circle:before{font-size:23px;color:#10aeff}.weui_icon_circle:before{font-size:23px;color:#c9c9c9}.weui_icon_download:before,.weui_icon_info_circle:before{font-size:23px;color:#09bb07}.weui_icon_safe_success:before{color:#09bb07}.weui_icon_safe_warn:before{color:#ffbe00}.weui_icon_cancel:before{color:#f43530;font-size:22px}.weui_icon_clear:before,.weui_icon_search:before{color:#b2b2b2;font-size:14px}.weui_icon_msg:before{font-size:104px}.weui_icon_warn.weui_icon_msg:before{color:#f76260}.weui_icon_safe:before{font-size:104px}.weui_btn.weui_btn_mini{line-height:1.9;font-size:14px;padding:0 .75em;display:inline-block}button.weui_btn,input.weui_btn{width:100%;border-width:0;outline:0;-webkit-appearance:none}button.weui_btn:focus,input.weui_btn:focus{outline:0}button.weui_btn_inline,button.weui_btn_mini,input.weui_btn_inline,input.weui_btn_mini{width:auto}.weui_btn+.weui_btn{margin-top:15px}.weui_btn.weui_btn_inline+.weui_btn.weui_btn_inline{margin-top:auto;margin-left:15px}.weui_btn_area{margin:1.17647059em 15px .3em}.weui_btn_area.weui_btn_area_inline{display:-webkit-box;display:-webkit-flex;display:flex}.weui_btn_area.weui_btn_area_inline .weui_btn{margin-top:auto;margin-right:15px;width:100%;-webkit-box-flex:1;-webkit-flex:1;flex:1}.weui_btn_area.weui_btn_area_inline .weui_btn:last-child{margin-right:0}.weui_btn{position:relative;display:block;margin-left:auto;margin-right:auto;padding-left:14px;padding-right:14px;box-sizing:border-box;font-size:18px;text-align:center;text-decoration:none;color:#fff;line-height:2.33333333;border-radius:5px;-webkit-tap-highlight-color:rgba(0,0,0,0);overflow:hidden}.weui_btn:after{content:" ";width:200%;height:200%;position:absolute;top:0;left:0;border:1px solid rgba(0,0,0,.2);-webkit-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:0 0;transform-origin:0 0;box-sizing:border-box;border-radius:10px}.weui_btn.weui_btn_inline{display:inline-block}.weui_btn_default{background-color:#f7f7f7;color:#454545}.weui_btn_default:not(.weui_btn_disabled):visited{color:#454545}.weui_btn_default:not(.weui_btn_disabled):active{color:#a1a1a1;background-color:#dedede}.weui_btn_primary{background-color:#04be02}.weui_btn_primary:not(.weui_btn_disabled):visited{color:#fff}.weui_btn_primary:not(.weui_btn_disabled):active{color:hsla(0,0%,100%,.4);background-color:#039702}.weui_btn_warn{background-color:#ef4f4f}.weui_btn_warn:not(.weui_btn_disabled):visited{color:#fff}.weui_btn_warn:not(.weui_btn_disabled):active{color:hsla(0,0%,100%,.4);background-color:#c13e3e}.weui_btn_disabled{color:hsla(0,0%,100%,.6)}.weui_btn_disabled.weui_btn_default{color:#c9c9c9}.weui_btn_plain_primary{color:#04be02;border:1px solid #04be02}button.weui_btn_plain_primary,input.weui_btn_plain_primary{border-width:1px;background-color:transparent}.weui_btn_plain_primary:active{border-color:#039702}.weui_btn_plain_primary:after{border-width:0}.weui_btn_plain_default{color:#5a5a5a;border:1px solid #5a5a5a}button.weui_btn_plain_default,input.weui_btn_plain_default{border-width:1px;background-color:transparent}.weui_btn_plain_default:after{border-width:0}.weui_cell{position:relative}.weui_cell:before{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #d9d9d9;color:#d9d9d9;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5);left:15px}.weui_cell:first-child:before{display:none}.weui_cells{margin-top:1.17647059em;background-color:#fff;line-height:1.41176471;font-size:17px;overflow:hidden;position:relative}.weui_cells:before{top:0;border-top:1px solid #d9d9d9;-webkit-transform-origin:0 0;transform-origin:0 0}.weui_cells:after,.weui_cells:before{content:" ";position:absolute;left:0;width:100%;height:1px;color:#d9d9d9;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_cells:after{bottom:0;border-bottom:1px solid #d9d9d9;-webkit-transform-origin:0 100%;transform-origin:0 100%}.weui_cells_title{margin-top:.77em;margin-bottom:.3em;padding-left:15px;padding-right:15px;color:#888;font-size:14px}.weui_cells_title+.weui_cells{margin-top:0}.weui_cells_tips{margin-top:.3em;color:#888;padding-left:15px;padding-right:15px;font-size:14px}.weui_cell{padding:10px 15px;position:relative;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center}.weui_cell_ft{text-align:right;color:#888}.weui_cell_primary{-webkit-box-flex:1;-webkit-flex:1;flex:1}.weui_cells_access .weui_cell:not(.no_access){-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_cells_access .weui_cell:not(.no_access):active{background-color:#ececec}.weui_cells_access a.weui_cell{color:inherit}.weui_cells_access .weui_cell_ft:after{content:" ";display:inline-block;-webkit-transform:rotate(45deg);transform:rotate(45deg);height:6px;width:6px;border-width:2px 2px 0 0;border-color:#c8c8cd;border-style:solid;position:relative;top:-2px;top:-1px;margin-left:.3em}.weui_check_label{-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_check{position:absolute;left:-9999em}.weui_cells_radio .weui_cell_ft{padding-left:.35em}.weui_cells_radio .weui_cell:active{background-color:#ececec}.weui_cells_radio .weui_check:checked+.weui_icon_checked:before{display:block;content:'\EA08';color:#09bb07;font-size:16px}.weui_cells_checkbox .weui_cell_hd{padding-right:.35em}.weui_cells_checkbox .weui_cell:active{background-color:#ececec}.weui_cells_checkbox .weui_icon_checked:before{content:'\EA01';color:#c9c9c9;font-size:23px;display:block}.weui_cells_checkbox .weui_check:checked+.weui_icon_checked:before{content:'\EA06';color:#09bb07}.weui_label{display:block;width:105px;word-wrap:break-word;word-break:break-all}.weui_input{width:100%;border:0;outline:0;-webkit-appearance:none;background-color:transparent;font-size:inherit;color:inherit;height:1.41176471em;line-height:1.41176471}.weui_input::-webkit-inner-spin-button,.weui_input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}.weui_textarea{display:block;border:0;resize:none;width:100%;color:inherit;font-size:1em;line-height:inherit;outline:0}.weui_textarea_counter{color:#b2b2b2;text-align:right}.weui_cell_warn .weui_textarea_counter{color:#e64340}.weui_toptips{display:none;position:fixed;-webkit-transform:translateZ(0);width:100%;top:0;line-height:2.3;font-size:14px;text-align:center;color:#fff;z-index:50000}.weui_toptips.weui_warn{background-color:#e64340}.weui_cells_form .weui_cell_warn{color:#e64340}.weui_cells_form .weui_cell_warn .weui_icon_warn{display:inline-block}.weui_cells_form .weui_cell_ft{font-size:0}.weui_cells_form .weui_icon_warn{display:none}.weui_cells_form input,.weui_cells_form label[for],.weui_cells_form textarea{-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_cell_select{padding:0}.weui_cell_select .weui_select{padding-right:30px}.weui_cell_select .weui_cell_bd:after{content:" ";display:inline-block;-webkit-transform:rotate(45deg);transform:rotate(45deg);height:6px;width:6px;border-width:2px 2px 0 0;border-color:#c8c8cd;border-style:solid;position:relative;top:-2px;position:absolute;top:50%;right:15px;margin-top:-3px}.weui_select{-webkit-appearance:none;border:0;outline:0;background-color:transparent;width:100%;font-size:inherit;height:44px;line-height:44px;position:relative;z-index:1;padding-left:15px}.weui_select_before{padding-right:15px}.weui_select_before .weui_select{width:105px;box-sizing:border-box}.weui_select_before .weui_cell_hd{position:relative}.weui_select_before .weui_cell_hd:after{content:" ";position:absolute;right:0;top:0;width:1px;height:100%;border-right:1px solid #d9d9d9;color:#d9d9d9;-webkit-transform-origin:100% 0;transform-origin:100% 0;-webkit-transform:scaleX(.5);transform:scaleX(.5)}.weui_select_before .weui_cell_hd:before{content:" ";display:inline-block;-webkit-transform:rotate(45deg);transform:rotate(45deg);height:6px;width:6px;border-width:2px 2px 0 0;border-color:#c8c8cd;border-style:solid;position:relative;top:-2px;position:absolute;top:50%;right:15px;margin-top:-3px}.weui_select_before .weui_cell_bd{padding-left:15px}.weui_select_before .weui_cell_bd:after{display:none}.weui_select_after{padding-left:15px}.weui_select_after .weui_select{padding-left:0}.weui_vcode{padding-top:0;padding-right:0;padding-bottom:0}.weui_vcode .weui_cell_ft img{margin-left:5px;height:44px;vertical-align:middle}.weui_cell_switch{padding-top:6px;padding-bottom:6px}.weui_switch{-webkit-appearance:none;appearance:none;position:relative;width:52px;height:32px;border:1px solid #dfdfdf;outline:0;border-radius:16px;box-sizing:border-box;background:#dfdfdf;background-color:#dfdfdf;-webkit-transition:background-color .1s,border .1s;transition:background-color .1s,border .1s}.weui_switch:before{width:50px;background-color:#fdfdfd;transition:-webkit-transform .3s;transition:transform .3s;transition:transform .3s,-webkit-transform .3s;-webkit-transition:-webkit-transform .35s cubic-bezier(.45,1,.4,1);transition:-webkit-transform .35s cubic-bezier(.45,1,.4,1);transition:transform .35s cubic-bezier(.45,1,.4,1);transition:transform .35s cubic-bezier(.45,1,.4,1),-webkit-transform .35s cubic-bezier(.45,1,.4,1)}.weui_switch:after,.weui_switch:before{content:" ";position:absolute;top:0;left:0;height:30px;border-radius:15px;-webkit-transition:-webkit-transform .3s}.weui_switch:after{width:30px;background-color:#fff;transition:-webkit-transform .3s;transition:transform .3s;transition:transform .3s,-webkit-transform .3s;box-shadow:0 1px 3px rgba(0,0,0,.4);-webkit-transition:-webkit-transform .35s cubic-bezier(.4,.4,.25,1.35);transition:-webkit-transform .35s cubic-bezier(.4,.4,.25,1.35);transition:transform .35s cubic-bezier(.4,.4,.25,1.35);transition:transform .35s cubic-bezier(.4,.4,.25,1.35),-webkit-transform .35s cubic-bezier(.4,.4,.25,1.35)}.weui_switch:checked{border-color:#04be02;background-color:#04be02}.weui_switch:checked:before{-webkit-transform:scale(0);transform:scale(0)}.weui_switch:checked:after{-webkit-transform:translateX(20px);transform:translateX(20px)}.weui_uploader_hd{padding-top:0;padding-right:0;padding-left:0}.weui_uploader_hd .weui_cell_ft{font-size:1em}.weui_uploader_bd{margin-bottom:-4px;margin-right:-9px;overflow:hidden}.weui_uploader_files{list-style:none}.weui_uploader_file{float:left;margin-right:9px;margin-bottom:9px;width:79px;height:79px;background:no-repeat 50%;background-size:cover}.weui_uploader_status{position:relative}.weui_uploader_status:before{content:" ";position:absolute;top:0;right:0;bottom:0;left:0;background-color:rgba(0,0,0,.5)}.weui_uploader_status .weui_uploader_status_content{position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);color:#fff}.weui_uploader_status .weui_icon_warn{display:block}.weui_uploader_input_wrp{float:left;position:relative;margin-right:9px;margin-bottom:9px;width:77px;height:77px;border:1px solid #d9d9d9}.weui_uploader_input_wrp:after,.weui_uploader_input_wrp:before{content:" ";position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);background-color:#d9d9d9}.weui_uploader_input_wrp:before{width:2px;height:39.5px}.weui_uploader_input_wrp:after{width:39.5px;height:2px}.weui_uploader_input_wrp:active{border-color:#999}.weui_uploader_input_wrp:active:after,.weui_uploader_input_wrp:active:before{background-color:#999}.weui_uploader_input{position:absolute;z-index:1;top:0;left:0;width:100%;height:100%;opacity:0;-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_msg{padding-top:36px;text-align:center}.weui_msg .weui_icon_area{margin-bottom:30px}.weui_msg .weui_text_area{margin-bottom:25px;padding:0 20px}.weui_msg .weui_msg_title{margin-bottom:5px;font-weight:400;font-size:20px}.weui_msg .weui_msg_desc{font-size:14px;color:#888}.weui_msg .weui_opr_area{margin-bottom:25px}.weui_msg .weui_extra_area{margin-bottom:15px;font-size:14px;color:#888}.weui_msg .weui_extra_area a{color:#61749b}@media screen and (min-height:438px){.weui_extra_area{position:fixed;left:0;bottom:0;width:100%;text-align:center}}.weui_article{padding:20px 15px;font-size:15px}.weui_article section{margin-bottom:1.5em}.weui_article h1{font-size:17px;font-weight:400;margin-bottom:.75em}.weui_article h2{font-size:16px;font-weight:400;margin-bottom:.3em}.weui_article h3{font-weight:400;font-size:15px}.weui_article *{max-width:100%;box-sizing:border-box;word-wrap:break-word}.weui_article p{margin:10px 0}.weui_tabbar{display:-webkit-box;display:-webkit-flex;display:flex;position:absolute;z-index:500;bottom:0;width:100%;background-color:#f7f7fa}.weui_tabbar:before{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #979797;color:#979797;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_tabbar_item{display:block;-webkit-box-flex:1;-webkit-flex:1;flex:1;padding:7px 0 0;-webkit-tap-highlight-color:transparent}.weui_tabbar_item.weui_bar_item_on .weui_tabbar_label{color:#09bb07}.weui_tabbar_icon{margin:0 auto;width:24px;height:24px}.weui_tabbar_icon img{display:block;width:100%;height:100%}.weui_tabbar_icon+.weui_tabbar_label{margin-top:5px}.weui_tabbar_label{text-align:center;color:#888;font-size:12px}.weui_navbar{display:-webkit-box;display:-webkit-flex;display:flex;position:absolute;z-index:500;top:0;width:100%;background-color:#fafafa}.weui_navbar:after{content:" ";position:absolute;left:0;bottom:0;width:100%;height:1px;border-bottom:1px solid #bcbab6;color:#bcbab6;-webkit-transform-origin:0 100%;transform-origin:0 100%;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_navbar+.weui_tab_bd{padding-top:50px;padding-bottom:0}.weui_navbar_item{position:relative;display:block;-webkit-box-flex:1;-webkit-flex:1;flex:1;padding:13px 0;text-align:center;font-size:15px;-webkit-tap-highlight-color:transparent}.weui_navbar_item:active{background-color:#ededed}.weui_navbar_item.weui_bar_item_on{background-color:#eaeaea}.weui_navbar_item:after{content:" ";position:absolute;right:0;top:0;width:1px;height:100%;border-right:1px solid #ccc;color:#ccc;-webkit-transform-origin:100% 0;transform-origin:100% 0;-webkit-transform:scaleX(.5);transform:scaleX(.5)}.weui_navbar_item:last-child:after{display:none}.weui_tab{position:relative;height:100%}.weui_tab_bd{box-sizing:border-box;height:100%;padding-bottom:55px;overflow:auto;-webkit-overflow-scrolling:touch}.weui_tab_bd_item{display:none}.weui_tab_bd_item_active{display:block}.weui_progress{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center}.weui_progress_bar{background-color:#ebebeb;height:3px;-webkit-box-flex:1;-webkit-flex:1;flex:1}.weui_progress_inner_bar{width:0;height:100%;background-color:#09bb07}.weui_progress_opr{display:block;margin-left:15px;font-size:0}.weui_panel{background-color:#fff;margin-top:10px;position:relative;overflow:hidden}.weui_panel:first-child{margin-top:0}.weui_panel:before{top:0;border-top:1px solid #e5e5e5;-webkit-transform-origin:0 0;transform-origin:0 0}.weui_panel:after,.weui_panel:before{content:" ";position:absolute;left:0;width:100%;height:1px;color:#e5e5e5;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_panel:after{bottom:0;border-bottom:1px solid #e5e5e5;-webkit-transform-origin:0 100%;transform-origin:0 100%}.weui_panel_hd{padding:14px 15px 10px;color:#999;font-size:13px;position:relative}.weui_panel_hd:after{content:" ";position:absolute;left:0;bottom:0;width:100%;height:1px;border-bottom:1px solid #e5e5e5;color:#e5e5e5;-webkit-transform-origin:0 100%;transform-origin:0 100%;-webkit-transform:scaleY(.5);transform:scaleY(.5);left:15px}.weui_panel_ft{padding:10px 15px 12px;color:#999;font-size:14px;position:relative}.weui_panel_ft:before{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #e5e5e5;color:#e5e5e5;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5);left:15px}.weui_panel_access .weui_panel_ft{display:block;color:#586c94;-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_panel_access .weui_panel_ft:active{background-color:#ececec}.weui_panel_access .weui_panel_ft:after{content:" ";display:inline-block;-webkit-transform:rotate(45deg);transform:rotate(45deg);height:6px;width:6px;border-width:2px 2px 0 0;border-color:#c7c7cc;border-style:solid;position:relative;top:-2px;position:absolute;right:15px;top:50%;margin-top:-4px}.weui_media_box{padding:15px;position:relative}.weui_media_box:before{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #e5e5e5;color:#e5e5e5;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5);left:15px}.weui_media_box:first-child:before{display:none}a.weui_media_box{color:#000;-webkit-tap-highlight-color:rgba(0,0,0,0)}a.weui_media_box:active{background-color:#ececec}.weui_media_box .weui_media_title{font-weight:400;font-size:17px;width:auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;word-wrap:normal;word-wrap:break-word;word-break:break-all}.weui_media_box .weui_media_desc{color:#999;font-size:13px;line-height:1.2;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2}.weui_media_box.weui_media_text .weui_media_title{margin-bottom:8px}.weui_media_box.weui_media_text .weui_media_info{margin-top:15px;padding-bottom:5px;font-size:13px;color:#cecece;line-height:1em;list-style:none;overflow:hidden}.weui_media_box.weui_media_text .weui_media_info_meta{float:left;padding-right:1em}.weui_media_box.weui_media_text .weui_media_info_meta.weui_media_info_meta_extra{padding-left:1em;border-left:1px solid #cecece}.weui_media_box.weui_media_appmsg{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center}.weui_media_box.weui_media_appmsg .weui_media_hd{margin-right:.8em;width:60px;height:60px;line-height:60px;text-align:center}.weui_media_box.weui_media_appmsg .weui_media_appmsg_thumb{width:100%;max-height:100%;vertical-align:top}.weui_media_box.weui_media_appmsg .weui_media_bd{-webkit-box-flex:1;-webkit-flex:1;flex:1;min-width:0}.weui_media_box.weui_media_small_appmsg{padding:0}.weui_media_box.weui_media_small_appmsg .weui_cells{margin-top:0}.weui_media_box.weui_media_small_appmsg .weui_cells:before{display:none}.weui_grids{position:relative;overflow:hidden}.weui_grids:before{content:'';position:absolute;box-sizing:border-box;width:200%;height:200%;left:0;top:0;border:1px solid #d9d9d9;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scale(.5);transform:scale(.5)}.weui_grid{position:relative;float:left;padding:20px 10px;width:33.33333333%;box-sizing:border-box}.weui_grid:before{content:'';position:absolute;box-sizing:border-box;width:200%;height:200%;left:0;top:0;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scale(.5);transform:scale(.5)}.weui_grid:nth-child(3n):before{border-right-width:0}.weui_grid:active{background-color:#e4e4e4}.weui_grid_icon{width:28px;height:28px;margin:0 auto}.weui_grid_icon img{display:block;width:100%;height:100%}.weui_grid_icon+.weui_grid_label{margin-top:5px}.weui_grid_label{display:block;text-align:center;color:#000;font-size:14px}.weui_dialog{position:fixed;z-index:5000;width:85%;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);background-color:#fafafc;text-align:center;border-radius:3px;overflow:hidden}.weui_dialog_confirm .weui_dialog .weui_dialog_hd{padding:1.2em 20px .5em}.weui_dialog_confirm .weui_dialog .weui_dialog_bd{text-align:left}.weui_dialog_hd{padding:1.2em 0 .5em}.weui_dialog_title{font-weight:400;font-size:17px}.weui_dialog_bd{padding:0 20px;font-size:15px;color:#888;word-wrap:break-word;word-break:break-all}.weui_dialog_ft{position:relative;line-height:42px;margin-top:20px;font-size:17px;display:-webkit-box;display:-webkit-flex;display:flex}.weui_dialog_ft a{display:block;-webkit-box-flex:1;-webkit-flex:1;flex:1;color:#3cc51f;text-decoration:none;-webkit-tap-highlight-color:rgba(0,0,0,0)}.weui_dialog_ft a:active{background-color:#eee}.weui_dialog_ft:after{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #d5d5d6;color:#d5d5d6;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_dialog_confirm .weui_dialog_ft a{position:relative}.weui_dialog_confirm .weui_dialog_ft a:after{content:" ";position:absolute;left:0;top:0;width:1px;height:100%;border-left:1px solid #d5d5d6;color:#d5d5d6;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleX(.5);transform:scaleX(.5)}.weui_dialog_confirm .weui_dialog_ft a:first-child:after{display:none}.weui_btn_dialog.default{color:#353535}.weui_btn_dialog.primary{color:#0bb20c}@media screen and (min-width:1024px){.weui_dialog{width:35%}}.weui_toast{position:fixed;z-index:50000;width:7.6em;min-height:7.6em;top:180px;left:50%;margin-left:-3.8em;background:rgba(40,40,40,.75);text-align:center;border-radius:5px;color:#fff}.weui_icon_toast{margin:22px 0 0;display:block}.weui_icon_toast:before{content:'\EA08';color:#fff;font-size:55px}.weui_toast_content{margin:0 0 15px}.weui_loading_toast .weui_toast_content{margin-top:64%;font-size:14px}.weui_loading{position:absolute;width:0;z-index:1;left:50%;top:38%}.weui_loading_leaf{position:absolute;top:-1px;opacity:.25}.weui_loading_leaf:before{content:" ";position:absolute;width:8.14px;height:3.08px;background:#d1d1d5;box-shadow:0 0 1px rgba(0,0,0,.0980392);border-radius:1px;-webkit-transform-origin:left 50% 0;transform-origin:left 50% 0}.weui_loading_leaf_0{-webkit-animation:a 1.25s linear infinite;animation:a 1.25s linear infinite}.weui_loading_leaf_0:before{-webkit-transform:rotate(0deg) translate(7.92px);transform:rotate(0deg) translate(7.92px)}.weui_loading_leaf_1{-webkit-animation:b 1.25s linear infinite;animation:b 1.25s linear infinite}.weui_loading_leaf_1:before{-webkit-transform:rotate(30deg) translate(7.92px);transform:rotate(30deg) translate(7.92px)}.weui_loading_leaf_2{-webkit-animation:c 1.25s linear infinite;animation:c 1.25s linear infinite}.weui_loading_leaf_2:before{-webkit-transform:rotate(60deg) translate(7.92px);transform:rotate(60deg) translate(7.92px)}.weui_loading_leaf_3{-webkit-animation:d 1.25s linear infinite;animation:d 1.25s linear infinite}.weui_loading_leaf_3:before{-webkit-transform:rotate(90deg) translate(7.92px);transform:rotate(90deg) translate(7.92px)}.weui_loading_leaf_4{-webkit-animation:e 1.25s linear infinite;animation:e 1.25s linear infinite}.weui_loading_leaf_4:before{-webkit-transform:rotate(120deg) translate(7.92px);transform:rotate(120deg) translate(7.92px)}.weui_loading_leaf_5{-webkit-animation:f 1.25s linear infinite;animation:f 1.25s linear infinite}.weui_loading_leaf_5:before{-webkit-transform:rotate(150deg) translate(7.92px);transform:rotate(150deg) translate(7.92px)}.weui_loading_leaf_6{-webkit-animation:g 1.25s linear infinite;animation:g 1.25s linear infinite}.weui_loading_leaf_6:before{-webkit-transform:rotate(180deg) translate(7.92px);transform:rotate(180deg) translate(7.92px)}.weui_loading_leaf_7{-webkit-animation:h 1.25s linear infinite;animation:h 1.25s linear infinite}.weui_loading_leaf_7:before{-webkit-transform:rotate(210deg) translate(7.92px);transform:rotate(210deg) translate(7.92px)}.weui_loading_leaf_8{-webkit-animation:i 1.25s linear infinite;animation:i 1.25s linear infinite}.weui_loading_leaf_8:before{-webkit-transform:rotate(240deg) translate(7.92px);transform:rotate(240deg) translate(7.92px)}.weui_loading_leaf_9{-webkit-animation:j 1.25s linear infinite;animation:j 1.25s linear infinite}.weui_loading_leaf_9:before{-webkit-transform:rotate(270deg) translate(7.92px);transform:rotate(270deg) translate(7.92px)}.weui_loading_leaf_10{-webkit-animation:k 1.25s linear infinite;animation:k 1.25s linear infinite}.weui_loading_leaf_10:before{-webkit-transform:rotate(300deg) translate(7.92px);transform:rotate(300deg) translate(7.92px)}.weui_loading_leaf_11{-webkit-animation:l 1.25s linear infinite;animation:l 1.25s linear infinite}.weui_loading_leaf_11:before{-webkit-transform:rotate(330deg) translate(7.92px);transform:rotate(330deg) translate(7.92px)}@-webkit-keyframes a{0%,0.01%{opacity:.25}0.02%{opacity:1}60.01%,to{opacity:.25}}@-webkit-keyframes b{0%,8.34333%{opacity:.25}8.35333%{opacity:1}68.3433%,to{opacity:.25}}@-webkit-keyframes c{0%,16.6767%{opacity:.25}16.6867%{opacity:1}76.6767%,to{opacity:.25}}@-webkit-keyframes d{0%,25.01%{opacity:.25}25.02%{opacity:1}85.01%,to{opacity:.25}}@-webkit-keyframes e{0%,33.3433%{opacity:.25}33.3533%{opacity:1}93.3433%,to{opacity:.25}}@-webkit-keyframes f{0%{opacity:.270958333333333}41.6767%{opacity:.25}41.6867%{opacity:1}1.67667%{opacity:.25}to{opacity:.270958333333333}}@-webkit-keyframes g{0%{opacity:.375125}50.01%{opacity:.25}50.02%{opacity:1}10.01%{opacity:.25}to{opacity:.375125}}@-webkit-keyframes h{0%{opacity:.479291666666667}58.3433%{opacity:.25}58.3533%{opacity:1}18.3433%{opacity:.25}to{opacity:.479291666666667}}@-webkit-keyframes i{0%{opacity:.583458333333333}66.6767%{opacity:.25}66.6867%{opacity:1}26.6767%{opacity:.25}to{opacity:.583458333333333}}@-webkit-keyframes j{0%{opacity:.687625}75.01%{opacity:.25}75.02%{opacity:1}35.01%{opacity:.25}to{opacity:.687625}}@-webkit-keyframes k{0%{opacity:.791791666666667}83.3433%{opacity:.25}83.3533%{opacity:1}43.3433%{opacity:.25}to{opacity:.791791666666667}}@-webkit-keyframes l{0%{opacity:.895958333333333}91.6767%{opacity:.25}91.6867%{opacity:1}51.6767%{opacity:.25}to{opacity:.895958333333333}}.weui_mask{background:rgba(0,0,0,.6)}.weui_mask,.weui_mask_transition,.weui_mask_transparent{position:fixed;z-index:1000;width:100%;height:100%;top:0;left:0}.weui_mask_transition{display:none;background:transparent;-webkit-transition:background .3s;transition:background .3s}.weui_fade_toggle{background:rgba(0,0,0,.6)}.weui_actionsheet{position:fixed;left:0;bottom:0;-webkit-transform:translateY(100%);transform:translateY(100%);-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:5000;width:100%;background-color:#efeff4;-webkit-transition:-webkit-transform .3s;transition:-webkit-transform .3s;transition:transform .3s;transition:transform .3s,-webkit-transform .3s}.weui_actionsheet_menu{background-color:#fff}.weui_actionsheet_action{margin-top:6px;background-color:#fff}.weui_actionsheet_cell{position:relative;padding:10px 0;text-align:center;font-size:18px}.weui_actionsheet_cell:before{content:" ";position:absolute;left:0;top:0;width:100%;height:1px;border-top:1px solid #d9d9d9;color:#d9d9d9;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_actionsheet_cell:active{background-color:#ececec}.weui_actionsheet_cell:first-child:before{display:none}.weui_actionsheet_toggle{-webkit-transform:translate(0);transform:translate(0)}.weui_search_bar{position:relative;padding:8px 10px;display:-webkit-box;display:-webkit-flex;display:flex;box-sizing:border-box;background-color:#efeff4}.weui_search_bar:before{top:0;border-top:1px solid #c7c7c7;-webkit-transform-origin:0 0;transform-origin:0 0}.weui_search_bar:after,.weui_search_bar:before{content:" ";position:absolute;left:0;width:100%;height:1px;color:#c7c7c7;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui_search_bar:after{bottom:0;border-bottom:1px solid #c7c7c7;-webkit-transform-origin:0 100%;transform-origin:0 100%}.weui_search_bar.weui_search_focusing .weui_search_cancel{display:block}.weui_search_bar.weui_search_focusing .weui_search_text{display:none}.weui_search_outer{position:relative;-webkit-box-flex:1;-webkit-flex:auto;flex:auto;background-color:#efeff4}.weui_search_outer:after{content:'';position:absolute;left:0;top:0;width:200%;height:200%;-webkit-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:0 0;transform-origin:0 0;border-radius:10px;border:1px solid #e6e6ea;box-sizing:border-box;background:#fff}.weui_search_inner{position:relative;padding-left:30px;padding-right:30px;height:100%;width:100%;box-sizing:border-box;z-index:1}.weui_search_inner .weui_search_input{padding:4px 0;width:100%;height:1.42857143em;border:0;font-size:14px;line-height:1.42857143em;box-sizing:content-box;background:transparent}.weui_search_inner .weui_search_input:focus{outline:none}.weui_search_inner .weui_icon_search{position:absolute;left:10px;top:-2px;line-height:28px}.weui_search_inner .weui_icon_clear{position:absolute;top:-2px;right:0;padding:0 10px;line-height:28px}.weui_search_text{position:absolute;top:1px;right:1px;bottom:1px;left:1px;z-index:2;border-radius:3px;text-align:center;color:#9b9b9b;background:#fff}.weui_search_text span{display:inline-block;font-size:14px;vertical-align:middle}.weui_search_text .weui_icon_search{margin-right:5px}.weui_search_cancel{display:none;margin-left:10px;line-height:28px;white-space:nowrap;color:#09bb07}.weui_search_input:not(:valid)~.weui_icon_clear{display:none}input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration,input[type=search]::-webkit-search-results-button,input[type=search]::-webkit-search-results-decoration{display:none}
									.preloader{width:20px;height:20px;-webkit-transform-origin:50%;transform-origin:50%;-webkit-animation:preloader-spin 1s steps(12,end) infinite;animation:preloader-spin 1s steps(12,end) infinite}.preloader:after{display:block;width:100%;height:100%;content:"";background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-repeat:no-repeat;background-position:50%;background-size:100%}@-webkit-keyframes preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}html{font-size:20px}body{font-size:16px}@media only screen and (min-width:400px){html{font-size:21.33px!important}}@media only screen and (min-width:414px){html{font-size:22.08px!important}}@media only screen and (min-width:480px){html{font-size:25.6px!important}}.weui_navbar{z-index:10}.weui-row{display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-box-lines:multiple;-moz-box-lines:multiple;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-align:start;-ms-flex-align:start;-webkit-align-items:flex-start;align-items:flex-start}.weui-row>[class*=col-]{box-sizing:border-box}.weui-row .col-auto{width:100%}.weui-row .weui-col-100{width:100%;width:calc((100% - 15px*0)/ 1)}.weui-row.weui-no-gutter .weui-col-100{width:100%}.weui-row .weui-col-95{width:95%;width:calc((100% - 15px*.05263157894736836)/ 1.0526315789473684)}.weui-row.weui-no-gutter .weui-col-95{width:95%}.weui-row .weui-col-90{width:90%;width:calc((100% - 15px*.11111111111111116)/ 1.1111111111111112)}.weui-row.weui-no-gutter .weui-col-90{width:90%}.weui-row .weui-col-85{width:85%;width:calc((100% - 15px*.17647058823529416)/ 1.1764705882352942)}.weui-row.weui-no-gutter .weui-col-85{width:85%}.weui-row .weui-col-80{width:80%;width:calc((100% - 15px*.25)/ 1.25)}.weui-row.weui-no-gutter .weui-col-80{width:80%}.weui-row .weui-col-75{width:75%;width:calc((100% - 15px*.33333333333333326)/ 1.3333333333333333)}.weui-row.weui-no-gutter .weui-col-75{width:75%}.weui-row .weui-col-66{width:66.66666666666666%;width:calc((100% - 15px*.5000000000000002)/ 1.5000000000000002)}.weui-row.weui-no-gutter .weui-col-66{width:66.66666666666666%}.weui-row .weui-col-60{width:60%;width:calc((100% - 15px*.6666666666666667)/ 1.6666666666666667)}.weui-row.weui-no-gutter .weui-col-60{width:60%}.weui-row .weui-col-50{width:50%;width:calc((100% - 15px*1)/ 2)}.weui-row.weui-no-gutter .weui-col-50{width:50%}.weui-row .weui-col-40{width:40%;width:calc((100% - 15px*1.5)/ 2.5)}.weui-row.weui-no-gutter .weui-col-40{width:40%}.weui-row .weui-col-33{width:33.333333333333336%;width:calc((100% - 15px*2)/ 3)}.weui-row.weui-no-gutter .weui-col-33{width:33.333333333333336%}.weui-row .weui-col-25{width:25%;width:calc((100% - 15px*3)/ 4)}.weui-row.weui-no-gutter .weui-col-25{width:25%}.weui-row .weui-col-20{width:20%;width:calc((100% - 15px*4)/ 5)}.weui-row.weui-no-gutter .weui-col-20{width:20%}.weui-row .weui-col-15{width:15%;width:calc((100% - 15px*5.666666666666667)/ 6.666666666666667)}.weui-row.weui-no-gutter .weui-col-15{width:15%}.weui-row .weui-col-10{width:10%;width:calc((100% - 15px*9)/ 10)}.weui-row.weui-no-gutter .weui-col-10{width:10%}.weui-row .weui-col-5{width:5%;width:calc((100% - 15px*19)/ 20)}.weui-row.weui-no-gutter .weui-col-5{width:5%}.weui-row .weui-col-auto:nth-last-child(1),.weui-row .weui-col-auto:nth-last-child(1)~.weui-col-auto{width:100%;width:calc((100% - 15px*0)/ 1)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(1),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(1)~.weui-col-auto{width:100%}.weui-row .weui-col-auto:nth-last-child(2),.weui-row .weui-col-auto:nth-last-child(2)~.weui-col-auto{width:50%;width:calc((100% - 15px*1)/ 2)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(2),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(2)~.weui-col-auto{width:50%}.weui-row .weui-col-auto:nth-last-child(3),.weui-row .weui-col-auto:nth-last-child(3)~.weui-col-auto{width:33.33333333%;width:calc((100% - 15px*2)/ 3)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(3),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(3)~.weui-col-auto{width:33.33333333%}.weui-row .weui-col-auto:nth-last-child(4),.weui-row .weui-col-auto:nth-last-child(4)~.weui-col-auto{width:25%;width:calc((100% - 15px*3)/ 4)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(4),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(4)~.weui-col-auto{width:25%}.weui-row .weui-col-auto:nth-last-child(5),.weui-row .weui-col-auto:nth-last-child(5)~.weui-col-auto{width:20%;width:calc((100% - 15px*4)/ 5)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(5),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(5)~.weui-col-auto{width:20%}.weui-row .weui-col-auto:nth-last-child(6),.weui-row .weui-col-auto:nth-last-child(6)~.weui-col-auto{width:16.66666667%;width:calc((100% - 15px*5)/ 6)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(6),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(6)~.weui-col-auto{width:16.66666667%}.weui-row .weui-col-auto:nth-last-child(7),.weui-row .weui-col-auto:nth-last-child(7)~.weui-col-auto{width:14.28571429%;width:calc((100% - 15px*6)/ 7)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(7),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(7)~.weui-col-auto{width:14.28571429%}.weui-row .weui-col-auto:nth-last-child(8),.weui-row .weui-col-auto:nth-last-child(8)~.weui-col-auto{width:12.5%;width:calc((100% - 15px*7)/ 8)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(8),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(8)~.weui-col-auto{width:12.5%}.weui-row .weui-col-auto:nth-last-child(9),.weui-row .weui-col-auto:nth-last-child(9)~.weui-col-auto{width:11.11111111%;width:calc((100% - 15px*8)/ 9)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(9),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(9)~.weui-col-auto{width:11.11111111%}.weui-row .weui-col-auto:nth-last-child(10),.weui-row .weui-col-auto:nth-last-child(10)~.weui-col-auto{width:10%;width:calc((100% - 15px*9)/ 10)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(10),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(10)~.weui-col-auto{width:10%}.weui-row .weui-col-auto:nth-last-child(11),.weui-row .weui-col-auto:nth-last-child(11)~.weui-col-auto{width:9.09090909%;width:calc((100% - 15px*10)/ 11)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(11),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(11)~.weui-col-auto{width:9.09090909%}.weui-row .weui-col-auto:nth-last-child(12),.weui-row .weui-col-auto:nth-last-child(12)~.weui-col-auto{width:8.33333333%;width:calc((100% - 15px*11)/ 12)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(12),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(12)~.weui-col-auto{width:8.33333333%}.weui-row .weui-col-auto:nth-last-child(13),.weui-row .weui-col-auto:nth-last-child(13)~.weui-col-auto{width:7.69230769%;width:calc((100% - 15px*12)/ 13)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(13),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(13)~.weui-col-auto{width:7.69230769%}.weui-row .weui-col-auto:nth-last-child(14),.weui-row .weui-col-auto:nth-last-child(14)~.weui-col-auto{width:7.14285714%;width:calc((100% - 15px*13)/ 14)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(14),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(14)~.weui-col-auto{width:7.14285714%}.weui-row .weui-col-auto:nth-last-child(15),.weui-row .weui-col-auto:nth-last-child(15)~.weui-col-auto{width:6.66666667%;width:calc((100% - 15px*14)/ 15)}.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(15),.weui-row.weui-no-gutter .weui-col-auto:nth-last-child(15)~.weui-col-auto{width:6.66666667%}@media all and (min-width:768px){.row .tablet-100{width:100%;width:calc((100% - 15px*0)/ 1)}.row.no-gutter .tablet-100{width:100%}.row .tablet-95{width:95%;width:calc((100% - 15px*.05263157894736836)/ 1.0526315789473684)}.row.no-gutter .tablet-95{width:95%}.row .tablet-90{width:90%;width:calc((100% - 15px*.11111111111111116)/ 1.1111111111111112)}.row.no-gutter .tablet-90{width:90%}.row .tablet-85{width:85%;width:calc((100% - 15px*.17647058823529416)/ 1.1764705882352942)}.row.no-gutter .tablet-85{width:85%}.row .tablet-80{width:80%;width:calc((100% - 15px*.25)/ 1.25)}.row.no-gutter .tablet-80{width:80%}.row .tablet-75{width:75%;width:calc((100% - 15px*.33333333333333326)/ 1.3333333333333333)}.row.no-gutter .tablet-75{width:75%}.row .tablet-66{width:66.66666666666666%;width:calc((100% - 15px*.5000000000000002)/ 1.5000000000000002)}.row.no-gutter .tablet-66{width:66.66666666666666%}.row .tablet-60{width:60%;width:calc((100% - 15px*.6666666666666667)/ 1.6666666666666667)}.row.no-gutter .tablet-60{width:60%}.row .tablet-50{width:50%;width:calc((100% - 15px*1)/ 2)}.row.no-gutter .tablet-50{width:50%}.row .tablet-40{width:40%;width:calc((100% - 15px*1.5)/ 2.5)}.row.no-gutter .tablet-40{width:40%}.row .tablet-33{width:33.333333333333336%;width:calc((100% - 15px*2)/ 3)}.row.no-gutter .tablet-33{width:33.333333333333336%}.row .tablet-25{width:25%;width:calc((100% - 15px*3)/ 4)}.row.no-gutter .tablet-25{width:25%}.row .tablet-20{width:20%;width:calc((100% - 15px*4)/ 5)}.row.no-gutter .tablet-20{width:20%}.row .tablet-15{width:15%;width:calc((100% - 15px*5.666666666666667)/ 6.666666666666667)}.row.no-gutter .tablet-15{width:15%}.row .tablet-10{width:10%;width:calc((100% - 15px*9)/ 10)}.row.no-gutter .tablet-10{width:10%}.row .tablet-5{width:5%;width:calc((100% - 15px*19)/ 20)}.row.no-gutter .tablet-5{width:5%}.row .tablet-auto:nth-last-child(1),.row .tablet-auto:nth-last-child(1)~.col-auto{width:100%;width:calc((100% - 15px*0)/ 1)}.row.no-gutter .tablet-auto:nth-last-child(1),.row.no-gutter .tablet-auto:nth-last-child(1)~.tablet-auto{width:100%}.row .tablet-auto:nth-last-child(2),.row .tablet-auto:nth-last-child(2)~.col-auto{width:50%;width:calc((100% - 15px*1)/ 2)}.row.no-gutter .tablet-auto:nth-last-child(2),.row.no-gutter .tablet-auto:nth-last-child(2)~.tablet-auto{width:50%}.row .tablet-auto:nth-last-child(3),.row .tablet-auto:nth-last-child(3)~.col-auto{width:33.33333333%;width:calc((100% - 15px*2)/ 3)}.row.no-gutter .tablet-auto:nth-last-child(3),.row.no-gutter .tablet-auto:nth-last-child(3)~.tablet-auto{width:33.33333333%}.row .tablet-auto:nth-last-child(4),.row .tablet-auto:nth-last-child(4)~.col-auto{width:25%;width:calc((100% - 15px*3)/ 4)}.row.no-gutter .tablet-auto:nth-last-child(4),.row.no-gutter .tablet-auto:nth-last-child(4)~.tablet-auto{width:25%}.row .tablet-auto:nth-last-child(5),.row .tablet-auto:nth-last-child(5)~.col-auto{width:20%;width:calc((100% - 15px*4)/ 5)}.row.no-gutter .tablet-auto:nth-last-child(5),.row.no-gutter .tablet-auto:nth-last-child(5)~.tablet-auto{width:20%}.row .tablet-auto:nth-last-child(6),.row .tablet-auto:nth-last-child(6)~.col-auto{width:16.66666667%;width:calc((100% - 15px*5)/ 6)}.row.no-gutter .tablet-auto:nth-last-child(6),.row.no-gutter .tablet-auto:nth-last-child(6)~.tablet-auto{width:16.66666667%}.row .tablet-auto:nth-last-child(7),.row .tablet-auto:nth-last-child(7)~.col-auto{width:14.28571429%;width:calc((100% - 15px*6)/ 7)}.row.no-gutter .tablet-auto:nth-last-child(7),.row.no-gutter .tablet-auto:nth-last-child(7)~.tablet-auto{width:14.28571429%}.row .tablet-auto:nth-last-child(8),.row .tablet-auto:nth-last-child(8)~.col-auto{width:12.5%;width:calc((100% - 15px*7)/ 8)}.row.no-gutter .tablet-auto:nth-last-child(8),.row.no-gutter .tablet-auto:nth-last-child(8)~.tablet-auto{width:12.5%}.row .tablet-auto:nth-last-child(9),.row .tablet-auto:nth-last-child(9)~.col-auto{width:11.11111111%;width:calc((100% - 15px*8)/ 9)}.row.no-gutter .tablet-auto:nth-last-child(9),.row.no-gutter .tablet-auto:nth-last-child(9)~.tablet-auto{width:11.11111111%}.row .tablet-auto:nth-last-child(10),.row .tablet-auto:nth-last-child(10)~.col-auto{width:10%;width:calc((100% - 15px*9)/ 10)}.row.no-gutter .tablet-auto:nth-last-child(10),.row.no-gutter .tablet-auto:nth-last-child(10)~.tablet-auto{width:10%}.row .tablet-auto:nth-last-child(11),.row .tablet-auto:nth-last-child(11)~.col-auto{width:9.09090909%;width:calc((100% - 15px*10)/ 11)}.row.no-gutter .tablet-auto:nth-last-child(11),.row.no-gutter .tablet-auto:nth-last-child(11)~.tablet-auto{width:9.09090909%}.row .tablet-auto:nth-last-child(12),.row .tablet-auto:nth-last-child(12)~.col-auto{width:8.33333333%;width:calc((100% - 15px*11)/ 12)}.row.no-gutter .tablet-auto:nth-last-child(12),.row.no-gutter .tablet-auto:nth-last-child(12)~.tablet-auto{width:8.33333333%}.row .tablet-auto:nth-last-child(13),.row .tablet-auto:nth-last-child(13)~.col-auto{width:7.69230769%;width:calc((100% - 15px*12)/ 13)}.row.no-gutter .tablet-auto:nth-last-child(13),.row.no-gutter .tablet-auto:nth-last-child(13)~.tablet-auto{width:7.69230769%}.row .tablet-auto:nth-last-child(14),.row .tablet-auto:nth-last-child(14)~.col-auto{width:7.14285714%;width:calc((100% - 15px*13)/ 14)}.row.no-gutter .tablet-auto:nth-last-child(14),.row.no-gutter .tablet-auto:nth-last-child(14)~.tablet-auto{width:7.14285714%}.row .tablet-auto:nth-last-child(15),.row .tablet-auto:nth-last-child(15)~.col-auto{width:6.66666667%;width:calc((100% - 15px*14)/ 15)}.row.no-gutter .tablet-auto:nth-last-child(15),.row.no-gutter .tablet-auto:nth-last-child(15)~.tablet-auto{width:6.66666667%}}.weui_cell_hd img{display:block;margin-right:5px}.weui_dialog,.weui_toast{-webkit-transition-duration:.2s;transition-duration:.2s;opacity:0;-webkit-transform:scale(.9);transform:scale(.9);visibility:hidden;margin:0;left:7.5%;top:30%;z-index:100}.weui_dialog .weui_btn_dialog+.weui_btn_dialog,.weui_toast .weui_btn_dialog+.weui_btn_dialog{position:relative}.weui_dialog .weui_btn_dialog+.weui_btn_dialog:after,.weui_toast .weui_btn_dialog+.weui_btn_dialog:after{content:" ";position:absolute;left:0;top:0;width:1px;height:100%;border-left:1px solid #D5D5D6;color:#D5D5D6;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleX(.5);transform:scaleX(.5)}.weui_dialog.weui_dialog_visible,.weui_dialog.weui_toast_visible,.weui_toast.weui_dialog_visible,.weui_toast.weui_toast_visible{opacity:1;visibility:visible;-webkit-transform:scale(1);transform:scale(1)}@media screen and (min-width:1024px){.weui_dialog{left:32.5%}}.weui_toast{left:50%;top:35%;margin-left:-3.8em}.weui_toast_forbidden{color:#F76260}.weui_toast_cancel .weui_icon_toast:before{content:"\EA0D"}.weui_toast_forbidden .weui_icon_toast:before{content:"\EA0B";color:#F76260}.weui_toast_text{min-height:1em;width:auto;height:45px;border-radius:25px;margin-left:0;-webkit-transform:scale(.9) translate3d(-50%,0,0);transform:scale(.9) translate3d(-50%,0,0);-webkit-transform-origin:left;transform-origin:left}.weui_toast_text.weui_toast_visible{-webkit-transform:scale(1) translate3d(-50%,0,0);transform:scale(1) translate3d(-50%,0,0)}.weui_toast_text .weui_icon_toast{display:none}.weui_toast_text .weui_toast_content{margin:10px 15px}.weui_mask{z-index:100;opacity:0;-webkit-transition-duration:.3s;transition-duration:.3s;visibility:hidden}.weui_mask.weui_mask_visible{opacity:1;visibility:visible}.weui-prompt-input{padding:4px 6px;border:1px solid #ccc;box-sizing:border-box;height:2em;width:80%;margin-top:10px}.weui-pull-to-refresh{margin-top:-50px;-webkit-transition:-webkit-transform .4s;transition:-webkit-transform .4s;transition:transform .4s;transition:transform .4s,-webkit-transform .4s}.weui-pull-to-refresh.refreshing{-webkit-transform:translate3d(0,50px,0);transform:translate3d(0,50px,0)}.weui-pull-to-refresh.touching{-webkit-transition-duration:0s;transition-duration:0s}.weui-pull-to-refresh-layer{height:30px;line-height:30px;padding:10px;text-align:center}.weui-pull-to-refresh-layer .down{display:inline-block}.weui-pull-to-refresh-layer .refresh,.weui-pull-to-refresh-layer .up{display:none}.weui-pull-to-refresh-layer .pull-to-refresh-arrow{display:inline-block;z-index:10;width:20px;height:20px;margin-right:4px;vertical-align:-4px;background:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2026%2040'%3E%3Cpolygon%20points%3D'9%2C22%209%2C0%2017%2C0%2017%2C22%2026%2C22%2013.5%2C40%200%2C22'%20fill%3D'%238c8c8c'%2F%3E%3C%2Fsvg%3E") center no-repeat;background-size:13px 20px;-webkit-transition-duration:.3s;transition-duration:.3s;-webkit-transform:rotate(0) translate3d(0,0,0);transform:rotate(0) translate3d(0,0,0)}.weui-infinite-scroll .infinite-preloader:after,.weui-pull-to-refresh-layer .pull-to-refresh-preloader:after{content:"";background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-repeat:no-repeat;background-position:50%;background-size:100%}.weui-pull-to-refresh-layer .pull-to-refresh-preloader{display:none;vertical-align:-4px;margin-right:4px;width:20px;height:20px;-webkit-transform-origin:50%;transform-origin:50%;-webkit-animation:preloader-spin 1s steps(12,end) infinite;animation:preloader-spin 1s steps(12,end) infinite}.weui-pull-to-refresh-layer .pull-to-refresh-preloader:after{display:block;width:100%;height:100%}.pull-up .weui-pull-to-refresh-layer .down,.refreshing .weui-pull-to-refresh-layer .down{display:none}.pull-up .weui-pull-to-refresh-layer .pull-to-refresh-arrow{display:inline-block;-webkit-transform:rotate(180deg) translate3d(0,0,0);transform:rotate(180deg) translate3d(0,0,0)}.pull-down .weui-pull-to-refresh-layer .down,.pull-down .weui-pull-to-refresh-layer .pull-to-refresh-arrow,.pull-up .weui-pull-to-refresh-layer .up{display:inline-block}.refreshing .weui-pull-to-refresh-layer .pull-to-refresh-arrow{display:none}.refreshing .weui-pull-to-refresh-layer .pull-to-refresh-preloader,.refreshing .weui-pull-to-refresh-layer .refresh{display:inline-block}@keyframes preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.weui_tab_bd_item.weui-pull-to-refresh{position:absolute;top:50px}.weui-infinite-scroll{height:24px;line-height:24px;padding:10px;text-align:center}.weui-infinite-scroll .infinite-preloader{display:inline-block;margin-right:4px;vertical-align:-4px;width:20px;height:20px;-webkit-transform-origin:50%;transform-origin:50%;-webkit-animation:preloader-spin 1s steps(12,end) infinite;animation:preloader-spin 1s steps(12,end) infinite}.weui-infinite-scroll .infinite-preloader:after{display:block;width:100%;height:100%}.weui_tab{overflow:hidden}.weui_navbar_item{color:#888}.weui_navbar_item.weui_bar_item_on{color:#666}.toolbar,.toolbar .title{font-size:.85rem;color:#3d4145;width:100%}.weui_tab_bd .weui_tab_bd_item{display:none;height:100%;overflow:auto}.weui_tab_bd .weui_tab_bd_item.weui_tab_bd_item_active{display:block}.toolbar{position:relative;line-height:1.5;background:#f7f7f8}.toolbar:before{content:'';position:absolute;left:0;top:0;bottom:auto;right:auto;height:1px;width:100%;background-color:#d9d9d9;display:block;z-index:15;-webkit-transform-origin:50% 0;transform-origin:50% 0}.toolbar .toolbar-inner,.weui-picker-modal .picker-items{display:-webkit-box;display:-ms-flexbox;display:-webkit-flex}@media only screen and (-webkit-min-device-pixel-ratio:2){.toolbar:before{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.toolbar:before{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.toolbar .toolbar-inner{height:2.2rem;display:flex;text-align:center}.toolbar .title{position:absolute;display:block;padding:0;font-weight:400;line-height:2.2rem;text-align:center;white-space:nowrap}.toolbar .picker-button{position:absolute;right:0;box-sizing:border-box;height:2.2rem;line-height:2.2rem;color:#04BE02;z-index:1;padding:0 .5rem}.weui-picker-modal{width:100%;position:absolute;bottom:0;text-align:center;border-radius:0;opacity:.6;color:#3d4145;-webkit-transition-duration:.3s;transition-duration:.3s;height:13rem;background:#EFEFF4;-webkit-transform:translate3d(0,100%,0);transform:translate3d(0,100%,0);-webkit-transition-property:opacity,-webkit-transform;transition-property:opacity,-webkit-transform;transition-property:transform,opacity;transition-property:transform,opacity,-webkit-transform}.weui-picker-modal.picker-modal-inline{height:10.8rem;opacity:1;position:static;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.weui-picker-modal.picker-modal-inline .toolbar{display:none}.weui-picker-modal.picker-columns-single .picker-items-col{width:100%}.weui-picker-modal.weui-picker-modal-visible{opacity:1;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.weui-picker-modal .picker-modal-inner{position:relative;height:10.8rem}.weui-picker-modal .picker-columns{width:100%;height:13rem;z-index:11500}.popover .weui-picker-modal .picker-columns,.weui-picker-modal .picker-columns.picker-modal-inline{height:10rem}@media (orientation:landscape) and (max-height:415px){.weui-picker-modal .picker-columns:not(.picker-modal-inline){height:10rem}}.weui-picker-modal .popover.popover-picker-columns{width:14rem}.weui-picker-modal .picker-items{display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;width:100%;padding:0;text-align:right;font-size:1rem;font-weight:400;-webkit-mask-box-image:-webkit-linear-gradient(bottom,transparent,transparent 5%,#fff 20%,#fff 80%,transparent 95%,transparent);-webkit-mask-box-image:linear-gradient(to top,transparent,transparent 5%,#fff 20%,#fff 80%,transparent 95%,transparent)}.weui-picker-modal .bar+.picker-items{height:10.8rem}.weui-picker-modal .picker-items-col{overflow:hidden;position:relative;max-height:100%}.weui-picker-modal .picker-items-col.picker-items-col-left{text-align:left}.weui-picker-modal .picker-items-col.picker-items-col-center{text-align:center}.weui-picker-modal .picker-items-col.picker-items-col-right{text-align:right}.weui-picker-modal .picker-items-col.picker-items-col-divider{color:#3d4145;display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center}.weui-picker-modal .picker-items-col-wrapper{-webkit-transition:.3s;transition:.3s;-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}.weui-picker-modal .picker-item{height:32px;line-height:32px;padding:0 10px;white-space:nowrap;position:relative;overflow:hidden;text-overflow:ellipsis;color:#9b9b9b;left:0;top:0;width:100%;box-sizing:border-box;-webkit-transition:.3s;transition:.3s}.picker-items-col-absolute .weui-picker-modal .picker-item{position:absolute}.weui-picker-modal .picker-item.picker-item-far{pointer-events:none}.weui-picker-modal .picker-item.picker-selected{color:#3d4145;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);-webkit-transform:rotateX(0);transform:rotateX(0)}.weui-picker-modal .picker-center-highlight{height:32px;box-sizing:border-box;position:absolute;left:0;width:100%;top:50%;margin-top:-16px;pointer-events:none}.weui-picker-modal .picker-center-highlight:after,.weui-picker-modal .picker-center-highlight:before{content:'';position:absolute;right:auto;height:1px;background-color:#D9D9D9;display:block;z-index:15;left:0;width:100%}.weui-picker-modal .picker-center-highlight:before{top:0;bottom:auto;-webkit-transform-origin:50% 0;transform-origin:50% 0}@media only screen and (-webkit-min-device-pixel-ratio:2){.weui-picker-modal .picker-center-highlight:before{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.weui-picker-modal .picker-center-highlight:before{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.weui-picker-modal .picker-center-highlight:after{bottom:0;top:auto;-webkit-transform-origin:50% 100%;transform-origin:50% 100%}@media only screen and (-webkit-min-device-pixel-ratio:2){.weui-picker-modal .picker-center-highlight:after{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.weui-picker-modal .picker-center-highlight:after{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.weui-picker-modal .picker-3d .picker-items{overflow:hidden;-webkit-perspective:1200px;perspective:1200px}.weui-picker-modal .picker-3d .picker-item,.weui-picker-modal .picker-3d .picker-items-col,.weui-picker-modal .picker-3d .picker-items-col-wrapper{-webkit-transform-style:preserve-3d;transform-style:preserve-3d}.weui-picker-modal .picker-3d .picker-items-col{overflow:visible}.weui-picker-modal .picker-3d .picker-item{-webkit-transform-origin:center center -110px;transform-origin:center center -110px;-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}.weui-picker-container,.weui-picker-overlay{position:fixed;bottom:0;left:0;right:0;height:0;width:100%;z-index:100}.picker-calendar-row:after,.picker-calendar-week-days:after{content:'';z-index:15;left:0;right:auto}.city-picker .col-province{width:5rem}.city-picker .col-city{width:6rem}.city-picker .col-district{width:5rem}.weui-picker-container .weui_cells{margin:0;text-align:left}.weui-select-modal{height:auto}.weui-select-modal .weui_cells{overflow-y:auto;overflow-x:hidden;max-height:16rem}.weui-select-modal .weui_cells:after{display:none}.picker-calendar-month,.picker-calendar-week-days{display:-webkit-box;display:-ms-flexbox;display:-webkit-flex}.weui-picker-calendar{background:#fff;height:15rem;width:100%;overflow:hidden}.weui-picker-calendar .picker-modal-inner{overflow:hidden;height:12.8rem}.picker-calendar-week-days{height:.9rem;background:#f7f7f8;display:flex;font-size:11px;box-sizing:border-box;position:relative}.picker-calendar-week-days:after{position:absolute;bottom:0;top:auto;height:1px;width:100%;background-color:#c4c4c4;display:block;-webkit-transform-origin:50% 100%;transform-origin:50% 100%}@media only screen and (-webkit-min-device-pixel-ratio:2){.picker-calendar-week-days:after{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.picker-calendar-week-days:after{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.picker-calendar-week-days .picker-calendar-week-day{-ms-flex:0 1 auto;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;width:14.28571429%;width:calc(100% / 7);line-height:17px;text-align:center}.picker-calendar-week-days+.picker-calendar-months{height:11.9rem}.picker-calendar-months{width:100%;height:100%;overflow:hidden;position:relative}.picker-calendar-months-wrapper{position:relative;width:100%;height:100%;-webkit-transition:.3s;transition:.3s}.picker-calendar-month{display:flex;-webkit-box-orient:vertical;-ms-flex-direction:column;-webkit-flex-direction:column;flex-direction:column;width:100%;height:100%;position:absolute;left:0;top:0}.picker-calendar-row{height:16.66666667%;height:calc(100% / 6);display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-ms-flex:0 1 auto;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;width:100%;position:relative}.picker-calendar-row:after{position:absolute;bottom:0;top:auto;height:1px;width:100%;background-color:#ccc;display:block;-webkit-transform-origin:50% 100%;transform-origin:50% 100%}@media only screen and (-webkit-min-device-pixel-ratio:2){.picker-calendar-row:after{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.picker-calendar-row:after{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.weui-picker-modal .picker-calendar-row:last-child:after{display:none}.picker-calendar-day{-ms-flex:0 1 auto;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;box-sizing:border-box;width:14.28571429%;width:calc(100% / 7);text-align:center;color:#3d4145;font-size:15px;cursor:pointer}.picker-calendar-day.picker-calendar-day-next,.picker-calendar-day.picker-calendar-day-prev{color:#ccc}.picker-calendar-day.picker-calendar-day-disabled{color:#d4d4d4;cursor:auto}.picker-calendar-day.picker-calendar-day-today span{background:#e3e3e3}.picker-calendar-day.picker-calendar-day-selected span{background:#04BE02;color:#fff}.picker-calendar-day span{display:inline-block;border-radius:100%;width:30px;height:30px;line-height:30px}.picker-calendar-month-picker,.picker-calendar-year-picker{-webkit-box-align:center;-ms-flex-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;width:50%;max-width:200px;-ms-flex:0 10 auto;-webkit-flex-shrink:10;-ms-flex-negative:10;flex-shrink:10}.picker-calendar-month-picker span,.picker-calendar-year-picker span{-ms-flex:0 1 auto;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;position:relative;overflow:hidden;text-overflow:ellipsis}.picker-calendar.picker-modal-inline .picker-calendar-week-days,.popover .picker-calendar .picker-calendar-week-days{background:0 0}.swiper-button-next,.swiper-button-prev,i.icon{background-position:center;background-repeat:no-repeat}.picker-calendar.picker-modal-inline .picker-calendar-week-days:after,.picker-calendar.picker-modal-inline .picker-calendar-week-days:before,.picker-calendar.picker-modal-inline .toolbar:after,.picker-calendar.picker-modal-inline .toolbar:before,.popover .picker-calendar .picker-calendar-week-days:after,.popover .picker-calendar .picker-calendar-week-days:before,.popover .picker-calendar .toolbar:after,.popover .picker-calendar .toolbar:before{display:none}.picker-calendar.picker-modal-inline .picker-calendar-week-days~.picker-calendar-months:before,.picker-calendar.picker-modal-inline .toolbar~.picker-modal-inner .picker-calendar-months:before,.popover .picker-calendar .picker-calendar-week-days~.picker-calendar-months:before,.popover .picker-calendar .toolbar~.picker-modal-inner .picker-calendar-months:before{content:'';position:absolute;left:0;top:0;bottom:auto;right:auto;height:1px;width:100%;background-color:#c4c4c4;display:block;z-index:15;-webkit-transform-origin:50% 0;transform-origin:50% 0}@media only screen and (-webkit-min-device-pixel-ratio:2){.picker-calendar.picker-modal-inline .picker-calendar-week-days~.picker-calendar-months:before,.picker-calendar.picker-modal-inline .toolbar~.picker-modal-inner .picker-calendar-months:before,.popover .picker-calendar .picker-calendar-week-days~.picker-calendar-months:before,.popover .picker-calendar .toolbar~.picker-modal-inner .picker-calendar-months:before{-webkit-transform:scaleY(.5);transform:scaleY(.5)}}@media only screen and (-webkit-min-device-pixel-ratio:3){.picker-calendar.picker-modal-inline .picker-calendar-week-days~.picker-calendar-months:before,.picker-calendar.picker-modal-inline .toolbar~.picker-modal-inner .picker-calendar-months:before,.popover .picker-calendar .picker-calendar-week-days~.picker-calendar-months:before,.popover .picker-calendar .toolbar~.picker-modal-inner .picker-calendar-months:before{-webkit-transform:scaleY(.33);transform:scaleY(.33)}}.picker-calendar-month-picker,.picker-calendar-year-picker{display:block;line-height:2.2rem}.picker-calendar-month-picker a.icon-only,.picker-calendar-year-picker a.icon-only{min-width:36px;float:left;width:25%;height:2.2rem;line-height:2rem}.picker-calendar-month-picker .current-month-value,.picker-calendar-month-picker .current-year-value,.picker-calendar-year-picker .current-month-value,.picker-calendar-year-picker .current-year-value{float:left;width:50%;height:2.2rem}i.icon{display:inline-block;vertical-align:middle;background-size:100% auto;font-style:normal;position:relative}i.icon.icon-next,i.icon.icon-prev{width:.75rem;height:.75rem}.swiper-slide,.swiper-wrapper{width:100%;height:100%;position:relative}i.icon.icon-next{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2015%2015'%3E%3Cg%3E%3Cpath%20fill%3D'%2304BE02'%20d%3D'M1%2C1.6l11.8%2C5.8L1%2C13.4V1.6%20M0%2C0v15l15-7.6L0%2C0L0%2C0z'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E")}i.icon.icon-prev{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2015%2015'%3E%3Cg%3E%3Cpath%20fill%3D'%2304BE02'%20d%3D'M14%2C1.6v11.8L2.2%2C7.6L14%2C1.6%20M15%2C0L0%2C7.6L15%2C15V0L15%2C0z'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E")}.swiper-container{margin:0 auto;position:relative;overflow:hidden;z-index:1}.swiper-container-no-flexbox .swiper-slide{float:left}.swiper-container-vertical>.swiper-wrapper{-webkit-box-orient:vertical;-ms-flex-direction:column;-webkit-flex-direction:column;flex-direction:column}.swiper-wrapper{z-index:1;display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-transition-property:-webkit-transform;transition-property:-webkit-transform;transition-property:transform;transition-property:transform,-webkit-transform;box-sizing:content-box}.swiper-container-android .swiper-slide,.swiper-wrapper{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.swiper-container-multirow>.swiper-wrapper{-webkit-box-lines:multiple;-moz-box-lines:multiple;-ms-flex-wrap:wrap;-webkit-flex-wrap:wrap;flex-wrap:wrap}.swiper-container-free-mode>.swiper-wrapper{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out;margin:0 auto}.swiper-slide{-ms-flex:0 0 auto;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0}.swiper-container-autoheight,.swiper-container-autoheight .swiper-slide{height:auto}.swiper-container-autoheight .swiper-wrapper{-webkit-box-align:start;-ms-flex-align:start;-webkit-align-items:flex-start;align-items:flex-start;-webkit-transition-property:-webkit-transform,height;-webkit-transition-property:height,-webkit-transform;transition-property:height,-webkit-transform;transition-property:transform,height;transition-property:transform,height,-webkit-transform}.swiper-container .swiper-notification{position:absolute;left:0;top:0;pointer-events:none;opacity:0;z-index:-1000}.swiper-wp8-horizontal{-ms-touch-action:pan-y;touch-action:pan-y}.swiper-wp8-vertical{-ms-touch-action:pan-x;touch-action:pan-x}.swiper-button-next,.swiper-button-prev{position:absolute;top:50%;width:27px;height:44px;margin-top:-22px;z-index:10;cursor:pointer;background-size:27px 44px}.swiper-button-next.swiper-button-disabled,.swiper-button-prev.swiper-button-disabled{opacity:.35;cursor:auto;pointer-events:none}.swiper-button-prev,.swiper-container-rtl .swiper-button-next{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E");left:10px;right:auto}.swiper-button-prev.swiper-button-black,.swiper-container-rtl .swiper-button-next.swiper-button-black{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E")}.swiper-button-prev.swiper-button-white,.swiper-container-rtl .swiper-button-next.swiper-button-white{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M0%2C22L22%2C0l2.1%2C2.1L4.2%2C22l19.9%2C19.9L22%2C44L0%2C22L0%2C22L0%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E")}.swiper-button-next,.swiper-container-rtl .swiper-button-prev{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23007aff'%2F%3E%3C%2Fsvg%3E");right:10px;left:auto}.swiper-button-next.swiper-button-black,.swiper-container-rtl .swiper-button-prev.swiper-button-black{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23000000'%2F%3E%3C%2Fsvg%3E")}.swiper-button-next.swiper-button-white,.swiper-container-rtl .swiper-button-prev.swiper-button-white{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2027%2044'%3E%3Cpath%20d%3D'M27%2C22L27%2C22L5%2C44l-2.1-2.1L22.8%2C22L2.9%2C2.1L5%2C0L27%2C22L27%2C22z'%20fill%3D'%23ffffff'%2F%3E%3C%2Fsvg%3E")}.swiper-pagination{position:absolute;text-align:center;-webkit-transition:.3s;transition:.3s;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0);z-index:10}.swiper-pagination.swiper-pagination-hidden{opacity:0}.swiper-container-horizontal>.swiper-pagination-bullets,.swiper-pagination-custom,.swiper-pagination-fraction{bottom:10px;left:0;width:100%}.swiper-pagination-bullet{width:8px;height:8px;display:inline-block;border-radius:100%;background:#000;opacity:.2}button.swiper-pagination-bullet{border:none;margin:0;padding:0;box-shadow:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;appearance:none}.swiper-pagination-clickable .swiper-pagination-bullet{cursor:pointer}.swiper-pagination-white .swiper-pagination-bullet{background:#fff}.swiper-pagination-bullet-active{opacity:1;background:#04BE02}.swiper-pagination-white .swiper-pagination-bullet-active{background:#fff}.swiper-pagination-black .swiper-pagination-bullet-active{background:#000}.swiper-container-vertical>.swiper-pagination-bullets{right:10px;top:50%;-webkit-transform:translate3d(0,-50%,0);transform:translate3d(0,-50%,0)}.swiper-container-vertical>.swiper-pagination-bullets .swiper-pagination-bullet{margin:5px 0;display:block}.swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet{margin:0 5px}.swiper-pagination-progress{background:rgba(0,0,0,.25);position:absolute}.swiper-pagination-progress .swiper-pagination-progressbar{background:#007aff;position:absolute;left:0;top:0;width:100%;height:100%;-webkit-transform:scale(0);transform:scale(0);-webkit-transform-origin:left top;transform-origin:left top}.swiper-container-rtl .swiper-pagination-progress .swiper-pagination-progressbar{-webkit-transform-origin:right top;transform-origin:right top}.swiper-container-horizontal>.swiper-pagination-progress{width:100%;height:4px;left:0;top:0}.swiper-container-vertical>.swiper-pagination-progress{width:4px;height:100%;left:0;top:0}.swiper-pagination-progress.swiper-pagination-white{background:rgba(255,255,255,.5)}.swiper-pagination-progress.swiper-pagination-white .swiper-pagination-progressbar{background:#fff}.swiper-pagination-progress.swiper-pagination-black .swiper-pagination-progressbar{background:#000}.swiper-container-3d{-webkit-perspective:1200px;-o-perspective:1200px;perspective:1200px}.swiper-container-3d .swiper-cube-shadow,.swiper-container-3d .swiper-slide,.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top,.swiper-container-3d .swiper-wrapper{-webkit-transform-style:preserve-3d;transform-style:preserve-3d}.swiper-container-3d .swiper-slide-shadow-bottom,.swiper-container-3d .swiper-slide-shadow-left,.swiper-container-3d .swiper-slide-shadow-right,.swiper-container-3d .swiper-slide-shadow-top{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:10}.swiper-container-3d .swiper-slide-shadow-left{background-image:-webkit-gradient(linear,left top,right top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(right,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to left,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-right{background-image:-webkit-gradient(linear,right top,left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(left,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to right,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-top{background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(bottom,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to top,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-3d .swiper-slide-shadow-bottom{background-image:-webkit-gradient(linear,left bottom,left top,from(rgba(0,0,0,.5)),to(rgba(0,0,0,0)));background-image:-webkit-linear-gradient(top,rgba(0,0,0,.5),rgba(0,0,0,0));background-image:linear-gradient(to bottom,rgba(0,0,0,.5),rgba(0,0,0,0))}.swiper-container-coverflow .swiper-wrapper,.swiper-container-flip .swiper-wrapper{-ms-perspective:1200px}.swiper-container-cube,.swiper-container-flip{overflow:visible}.swiper-container-cube .swiper-slide,.swiper-container-flip .swiper-slide{pointer-events:none;-webkit-backface-visibility:hidden;backface-visibility:hidden;z-index:1}.swiper-container-cube .swiper-slide .swiper-slide,.swiper-container-flip .swiper-slide .swiper-slide{pointer-events:none}.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-active .swiper-slide-active,.swiper-container-flip .swiper-slide-active,.swiper-container-flip .swiper-slide-active .swiper-slide-active{pointer-events:auto}.swiper-container-cube .swiper-slide-shadow-bottom,.swiper-container-cube .swiper-slide-shadow-left,.swiper-container-cube .swiper-slide-shadow-right,.swiper-container-cube .swiper-slide-shadow-top,.swiper-container-flip .swiper-slide-shadow-bottom,.swiper-container-flip .swiper-slide-shadow-left,.swiper-container-flip .swiper-slide-shadow-right,.swiper-container-flip .swiper-slide-shadow-top{z-index:0;-webkit-backface-visibility:hidden;backface-visibility:hidden}.swiper-container-cube .swiper-slide{visibility:hidden;-webkit-transform-origin:0 0;transform-origin:0 0;width:100%;height:100%}.swiper-container-cube.swiper-container-rtl .swiper-slide{-webkit-transform-origin:100% 0;transform-origin:100% 0}.swiper-container-cube .swiper-slide-active,.swiper-container-cube .swiper-slide-next,.swiper-container-cube .swiper-slide-next+.swiper-slide,.swiper-container-cube .swiper-slide-prev{pointer-events:auto;visibility:visible}.swiper-container-cube .swiper-cube-shadow{position:absolute;left:0;bottom:0;width:100%;height:100%;background:#000;opacity:.6;-webkit-filter:blur(50px);filter:blur(50px);z-index:0}.swiper-container-fade.swiper-container-free-mode .swiper-slide{-webkit-transition-timing-function:ease-out;transition-timing-function:ease-out}.swiper-container-fade .swiper-slide{pointer-events:none;-webkit-transition-property:opacity;transition-property:opacity}.swiper-container-fade .swiper-slide .swiper-slide{pointer-events:none}.swiper-container-fade .swiper-slide-active,.swiper-container-fade .swiper-slide-active .swiper-slide-active{pointer-events:auto}.swiper-scrollbar{border-radius:10px;position:relative;-ms-touch-action:none;background:rgba(0,0,0,.1)}.swiper-container-horizontal>.swiper-scrollbar{position:absolute;left:1%;bottom:3px;z-index:50;height:5px;width:98%}.swiper-container-vertical>.swiper-scrollbar{position:absolute;right:3px;top:1%;z-index:50;width:5px;height:98%}.swiper-scrollbar-drag{height:100%;width:100%;position:relative;background:rgba(0,0,0,.5);border-radius:10px;left:0;top:0}.swiper-scrollbar-cursor-drag{cursor:move}.swiper-lazy-preloader{width:42px;height:42px;position:absolute;left:50%;top:50%;margin-left:-21px;margin-top:-21px;z-index:10;-webkit-transform-origin:50%;transform-origin:50%;-webkit-animation:swiper-preloader-spin 1s steps(12,end) infinite;animation:swiper-preloader-spin 1s steps(12,end) infinite}.swiper-lazy-preloader:after{display:block;content:"";width:100%;height:100%;background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%236c6c6c'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");background-position:50%;background-size:100%;background-repeat:no-repeat}.swiper-lazy-preloader-white:after{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg%20viewBox%3D'0%200%20120%20120'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20xmlns%3Axlink%3D'http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink'%3E%3Cdefs%3E%3Cline%20id%3D'l'%20x1%3D'60'%20x2%3D'60'%20y1%3D'7'%20y2%3D'27'%20stroke%3D'%23fff'%20stroke-width%3D'11'%20stroke-linecap%3D'round'%2F%3E%3C%2Fdefs%3E%3Cg%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(30%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(60%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(90%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(120%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.27'%20transform%3D'rotate(150%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.37'%20transform%3D'rotate(180%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.46'%20transform%3D'rotate(210%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.56'%20transform%3D'rotate(240%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.66'%20transform%3D'rotate(270%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.75'%20transform%3D'rotate(300%2060%2C60)'%2F%3E%3Cuse%20xlink%3Ahref%3D'%23l'%20opacity%3D'.85'%20transform%3D'rotate(330%2060%2C60)'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E")}@-webkit-keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg)}}@keyframes swiper-preloader-spin{100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.weui_actionsheet{z-index:100}.weui_actionsheet .weui_actionsheet_title{padding:8px 0;text-align:center;font-size:16px;color:#999;background-color:#f4f4f4;position:relative}.weui_actionsheet .weui_actionsheet_title:after{content:" ";position:absolute;left:0;bottom:0;width:100%;height:1px;border-top:1px solid #d9d9d9;color:#d9d9d9;-webkit-transform-origin:0 100%;transform-origin:0 100%;-webkit-transform:scaleY(.5);transform:scaleY(.5)}.weui-popup-container,.weui-popup-overlay{position:fixed;bottom:0;left:0;right:0;width:100%;height:100%;z-index:10}.weui-popup-overlay{background-color:rgba(0,0,0,.6);opacity:0;-webkit-transition:opacity .3s;transition:opacity .3s}.weui-popup-container{display:none}.weui-popup-container.weui-popup-container-visible{display:block}.weui-popup-container .weui_cells{margin:0;text-align:left}.weui-popup-modal{width:100%;position:absolute;z-index:100;bottom:0;border-radius:0;opacity:.6;color:#3d4145;-webkit-transition-duration:.3s;transition-duration:.3s;height:100%;background:#EFEFF4;-webkit-transform:translate3d(0,100%,0);transform:translate3d(0,100%,0);-webkit-transition-property:opacity,-webkit-transform;transition-property:opacity,-webkit-transform;transition-property:transform,opacity;transition-property:transform,opacity,-webkit-transform;overflow-x:hidden;overflow-y:auto}.popup-bottom .weui-popup-modal{height:auto}.weui-popup-modal .toolbar{position:absolute;left:0;top:0;right:0;z-index:1}.weui-popup-modal .modal-content{height:100%;padding-top:2.2rem;overflow:auto;box-sizing:border-box}.weui-popup-container-visible .weui-popup-overlay{opacity:1}.weui-popup-container-visible .weui-popup-modal{opacity:1;-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.notification{position:fixed;width:100%;min-height:3.4rem;top:-2rem;padding-top:2rem;left:0;right:0;z-index:9999;background-color:rgba(0,0,0,.85);color:#fff;font-size:.65rem;-webkit-transform:translate3d(0,-100%,0);transform:translate3d(0,-100%,0);-webkit-transition:.4s;transition:.4s}.notification.notification-in{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.notification.touching{-webkit-transition-duration:0s;transition-duration:0s}.notification .notification-inner{padding:.4rem .6rem 1rem;display:-webkit-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-box-align:start;-ms-flex-align:start;-webkit-align-items:flex-start;align-items:flex-start}.notification .notification-content{width:100%;margin:0 .4rem}.notification .notification-title{font-weight:700}.notification .notification-text{line-height:1}.notification .notification-media{height:1rem;width:1rem}.notification .notification-media img{width:100%}.notification .notification-handle-bar{position:absolute;bottom:.2rem;left:50%;-webkit-transform:translate3d(-50%,0,0);transform:translate3d(-50%,0,0);width:2rem;height:.3rem;border-radius:.15rem;background:#fff;opacity:.5}.weui-photo-browser-modal{position:fixed;top:0;left:0;right:0;bottom:0;background:#000;display:none;opacity:0;-webkit-transition:opacity .3s;transition:opacity .3s}.weui-photo-browser-modal.weui-photo-browser-modal-visible{opacity:1}.weui-photo-browser-modal .swiper-container{height:100%;-webkit-transform:scale(.2);transform:scale(.2);-webkit-transition:-webkit-transform .5s;transition:-webkit-transform .5s;transition:transform .5s;transition:transform .5s,-webkit-transform .5s}.weui-photo-browser-modal .swiper-container .swiper-pagination-bullet{background:#fff;visibility:hidden}.weui-photo-browser-modal .swiper-container.swiper-container-visible{-webkit-transform:scale(1);transform:scale(1)}.weui-photo-browser-modal .swiper-container.swiper-container-visible .swiper-pagination-bullet{visibility:visible;-webkit-transition-property:visibility;transition-property:visibility;-webkit-transition-delay:.5s;transition-delay:.5s}.weui-photo-browser-modal .swiper-container .swiper-pagination{bottom:10px;left:0;width:100%}.weui-photo-browser-modal .photo-container{height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;overflow:hidden}.weui-photo-browser-modal .photo-container img{max-width:100%;margin-top:-30px}.weui-photo-browser-modal .caption{position:absolute;bottom:40px;left:0;right:0;color:#fff;text-align:center;padding:0 12px;min-height:3rem;font-size:14px;z-index:10;-webkit-transition:opacity .3s;transition:opacity .3s;-webkit-transition-delay:.5s;transition-delay:.5s;opacity:0}.weui-photo-browser-modal .caption .caption-item{display:none;opacity:0;-webkit-transition:opacity .15s;transition:opacity .15s}.weui-photo-browser-modal .caption .caption-item.active{display:block;opacity:1}.weui-photo-browser-modal .swiper-container-visible .caption{opacity:1}.color-primary{color:#04BE02}.color-danger,.color-error{color:#f6383a}.color-warning{color:#f60}.color-success{color:#4cd964}.bg-danger,.bg-error,.bg-primary,.bg-success,.bg-warning{color:#fff}.bg-primary{background-color:#04BE02}.bg-danger,.bg-error{background-color:#f6383a}.bg-warning{background-color:#f60}.bg-success{background-color:#4cd964}.weui_toptips{z-index:100;opacity:0;-webkit-transition:opacity .3s;transition:opacity .3s}.weui_toptips.weui_toptips_visible{opacity:1}
	
		</style>
		</head>
	    <body>
		<div class="page">
		    <div class="weui_msg">
		        <div class="weui_icon_area"><i class="weui_icon_warn weui_icon_msg"></i></div>
		        <div class="weui_text_area">
		            <h2 class="weui_msg_title">登录失败</h2>
	           	 	<p class="weui_msg_desc" ><?php print $e;?></p>
		        </div>
		    </div>
		</div>
	    </body>
	</html>
	<?php 
	exit;
}

function get_weibo_authorize_uri($error_times=null){
    $params =array();
    $redirect_uri=get_uri_without_params(get_location_uri(),$params);
    if(isset($params['code'])){
        unset($params['code']);
    }
    if(isset($params['state'])){
        unset($params['state']);
    }
    if(isset($params['callback'])){
        unset($params['callback']);
    }
    if(isset($params['hash'])){
        unset($params['hash']);
    }
    if(!is_null($error_times)){
        $params['err_times']=$error_times;
    }
    if(count($params)>0){
        $redirect_uri.="?".http_build_query($params);
    }
  
    $api = new SaeTOAuthV2(XH_WEIBO_APPID,XH_WEIBO_APPSECRET);
    return $api->getAuthorizeURL($redirect_uri);
}

/**
 * PHP SDK for weibo.com (using OAuth2)
 *
 * @author Elmer Zhang <freeboy6716@gmail.com>
 */

/**
 * If the class OAuthException has not been declared, extend the Exception class.
 * This is to allow OAuth without the PECL OAuth library
 *
 * @ignore
 */
if ( ! class_exists( 'OAuthException')) {
    class OAuthException extends Exception {
        // pass
    }
}

/**
 * 新浪微博 OAuth 认证类(OAuth2)
 *
 * 授权机制说明请大家参考微博开放平台文档：{@link http://open.weibo.com/wiki/Oauth2}
 *
 * @package sae
 * @author Elmer Zhang
 * @version 1.0
 */
class SaeTOAuthV2 {
    /**
     * @ignore
     */
    public $client_id;
    /**
     * @ignore
     */
    public $client_secret;
    /**
     * @ignore
     */
    public $access_token;
    /**
     * @ignore
     */
    public $refresh_token;
    /**
     * Contains the last HTTP status code returned.
     *
     * @ignore
     */
    public $http_code;
    /**
     * Contains the last API call.
     *
     * @ignore
     */
    public $url;
    /**
     * Set up the API root URL.
     *
     * @ignore
     */
    public $host = "https://api.weibo.com/2/";
    /**
     * Set timeout default.
     *
     * @ignore
     */
    public $timeout = 30;
    /**
     * Set connect timeout.
     *
     * @ignore
     */
    public $connecttimeout = 30;
    /**
     * Verify SSL Cert.
     *
     * @ignore
     */
    public $ssl_verifypeer = FALSE;
    /**
     * Respons format.
     *
     * @ignore
     */
    public $format = 'json';
    /**
     * Decode returned json data.
     *
     * @ignore
     */
    public $decode_json = TRUE;
    /**
     * Contains the last HTTP headers returned.
     *
     * @ignore
     */
    public $http_info;
    /**
     * Set the useragnet.
     *
     * @ignore
     */
    public $useragent = 'Sae T OAuth2 v0.1';

    /**
     * print the debug info
     *
     * @ignore
     */
    public $debug = FALSE;

    /**
     * boundary of multipart
     * @ignore
     */
    public static $boundary = '';

    /**
     * Set API URLS
     */
    /**
     * @ignore
     */
    function accessTokenURL()  { return 'https://api.weibo.com/oauth2/access_token'; }
    /**
     * @ignore
     */
    function authorizeURL()    { return 'https://api.weibo.com/oauth2/authorize'; }

    /**
     * construct WeiboOAuth object
     */
    function __construct($client_id, $client_secret, $access_token = NULL, $refresh_token = NULL) {
        $this->client_id = $client_id;
        $this->client_secret = $client_secret;
        $this->access_token = $access_token;
        $this->refresh_token = $refresh_token;
    }

    /**
     * authorize接口
     *
     * 对应API：{@link http://open.weibo.com/wiki/Oauth2/authorize Oauth2/authorize}
     *
     * @param string $url 授权后的回调地址,站外应用需与回调地址一致,站内应用需要填写canvas page的地址
     * @param string $response_type 支持的值包括 code 和token 默认值为code
     * @param string $state 用于保持请求和回调的状态。在回调时,会在Query Parameter中回传该参数
     * @param string $display 授权页面类型 可选范围:
     *  - default		默认授权页面
     *  - mobile		支持html5的手机
     *  - popup			弹窗授权页
     *  - wap1.2		wap1.2页面
     *  - wap2.0		wap2.0页面
     *  - js			js-sdk 专用 授权页面是弹窗，返回结果为js-sdk回掉函数
     *  - apponweibo	站内应用专用,站内应用不传display参数,并且response_type为token时,默认使用改display.授权后不会返回access_token，只是输出js刷新站内应用父框架
     * @return array
     */
    function getAuthorizeURL( $url, $response_type = 'code', $state = NULL, $display = NULL ) {
        $params = array();
        $params['client_id'] = $this->client_id;
        $params['redirect_uri'] = $url;
        $params['response_type'] = $response_type;
        $params['state'] = $state;
        $params['display'] = $display;
        return $this->authorizeURL() . "?" . http_build_query($params);
    }

    /**
     * access_token接口
     *
     * 对应API：{@link http://open.weibo.com/wiki/OAuth2/access_token OAuth2/access_token}
     *
     * @param string $type 请求的类型,可以为:code, password, token
     * @param array $keys 其他参数：
     *  - 当$type为code时： array('code'=>..., 'redirect_uri'=>...)
     *  - 当$type为password时： array('username'=>..., 'password'=>...)
     *  - 当$type为token时： array('refresh_token'=>...)
     * @return array
     */
    function getAccessToken( $type = 'code', $keys ) {
        $params = array();
        $params['client_id'] = $this->client_id;
        $params['client_secret'] = $this->client_secret;
        if ( $type === 'token' ) {
            $params['grant_type'] = 'refresh_token';
            $params['refresh_token'] = $keys['refresh_token'];
        } elseif ( $type === 'code' ) {
            $params['grant_type'] = 'authorization_code';
            $params['code'] = $keys['code'];
            $params['redirect_uri'] = $keys['redirect_uri'];
        } elseif ( $type === 'password' ) {
            $params['grant_type'] = 'password';
            $params['username'] = $keys['username'];
            $params['password'] = $keys['password'];
        } else {
            throw new OAuthException("wrong auth type");
        }

        $response = $this->oAuthRequest($this->accessTokenURL(), 'POST', $params);
        $token = json_decode($response, true);
        if ( is_array($token) && !isset($token['error']) ) {
            $this->access_token = $token['access_token'];
        } else {
            throw new OAuthException("get access token failed." . $token['error']);
        }
        return $token;
    }

    /**
     * 解析 signed_request
     *
     * @param string $signed_request 应用框架在加载iframe时会通过向Canvas URL post的参数signed_request
     *
     * @return array
     */
    function parseSignedRequest($signed_request) {
        list($encoded_sig, $payload) = explode('.', $signed_request, 2);
        $sig = self::base64decode($encoded_sig) ;
        $data = json_decode(self::base64decode($payload), true);
        if (strtoupper($data['algorithm']) !== 'HMAC-SHA256') return '-1';
        $expected_sig = hash_hmac('sha256', $payload, $this->client_secret, true);
        return ($sig !== $expected_sig)? '-2':$data;
    }

    /**
     * @ignore
     */
    function base64decode($str) {
        return base64_decode(strtr($str.str_repeat('=', (4 - strlen($str) % 4)), '-_', '+/'));
    }

    /**
     * 读取jssdk授权信息，用于和jssdk的同步登录
     *
     * @return array 成功返回array('access_token'=>'value', 'refresh_token'=>'value'); 失败返回false
     */
    function getTokenFromJSSDK() {
        $key = "weibojs_" . $this->client_id;
        if ( isset($_COOKIE[$key]) && $cookie = $_COOKIE[$key] ) {
            parse_str($cookie, $token);
            if ( isset($token['access_token']) && isset($token['refresh_token']) ) {
                $this->access_token = $token['access_token'];
                $this->refresh_token = $token['refresh_token'];
                return $token;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 从数组中读取access_token和refresh_token
     * 常用于从Session或Cookie中读取token，或通过Session/Cookie中是否存有token判断登录状态。
     *
     * @param array $arr 存有access_token和secret_token的数组
     * @return array 成功返回array('access_token'=>'value', 'refresh_token'=>'value'); 失败返回false
     */
    function getTokenFromArray( $arr ) {
        if (isset($arr['access_token']) && $arr['access_token']) {
            $token = array();
            $this->access_token = $token['access_token'] = $arr['access_token'];
            if (isset($arr['refresh_token']) && $arr['refresh_token']) {
                $this->refresh_token = $token['refresh_token'] = $arr['refresh_token'];
            }

            return $token;
        } else {
            return false;
        }
    }

    /**
     * GET wrappwer for oAuthRequest.
     *
     * @return mixed
     */
    function get($url, $parameters = array()) {
        $response = $this->oAuthRequest($url, 'GET', $parameters);
        if ($this->format === 'json' && $this->decode_json) {
            return json_decode($response, true);
        }
        return $response;
    }

    /**
     * POST wreapper for oAuthRequest.
     *
     * @return mixed
     */
    function post($url, $parameters = array(), $multi = false) {
        $response = $this->oAuthRequest($url, 'POST', $parameters, $multi );
        if ($this->format === 'json' && $this->decode_json) {
            return json_decode($response, true);
        }
        return $response;
    }

    /**
     * DELTE wrapper for oAuthReqeust.
     *
     * @return mixed
     */
    function delete($url, $parameters = array()) {
        $response = $this->oAuthRequest($url, 'DELETE', $parameters);
        if ($this->format === 'json' && $this->decode_json) {
            return json_decode($response, true);
        }
        return $response;
    }

    /**
     * Format and sign an OAuth / API request
     *
     * @return string
     * @ignore
     */
    function oAuthRequest($url, $method, $parameters, $multi = false) {

        if (strrpos($url, 'http://') !== 0 && strrpos($url, 'https://') !== 0) {
            $url = "{$this->host}{$url}.{$this->format}";
        }

        switch ($method) {
            case 'GET':
                $url = $url . '?' . http_build_query($parameters);
                return $this->http($url, 'GET');
            default:
                $headers = array();
                if (!$multi && (is_array($parameters) || is_object($parameters)) ) {
                    $body = http_build_query($parameters);
                } else {
                    $body = self::build_http_query_multi($parameters);
                    $headers[] = "Content-Type: multipart/form-data; boundary=" . self::$boundary;
                }
                return $this->http($url, $method, $body, $headers);
        }
    }

    /**
     * Make an HTTP request
     *
     * @return string API results
     * @ignore
     */
    function http($url, $method, $postfields = NULL, $headers = array()) {
        $this->http_info = array();
        $ci = curl_init();
        /* Curl settings */
        curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ci, CURLOPT_USERAGENT, $this->useragent);
        curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, $this->connecttimeout);
        curl_setopt($ci, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ci, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ci, CURLOPT_ENCODING, "");
        curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, $this->ssl_verifypeer);
        if (version_compare(phpversion(), '5.4.0', '<')) {
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, 1);
        } else {
            curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, 2);
        }
        curl_setopt($ci, CURLOPT_HEADERFUNCTION, array($this, 'getHeader'));
        curl_setopt($ci, CURLOPT_HEADER, FALSE);

        switch ($method) {
            case 'POST':
                curl_setopt($ci, CURLOPT_POST, TRUE);
                if (!empty($postfields)) {
                    curl_setopt($ci, CURLOPT_POSTFIELDS, $postfields);
                    $this->postdata = $postfields;
                }
                break;
            case 'DELETE':
                curl_setopt($ci, CURLOPT_CUSTOMREQUEST, 'DELETE');
                if (!empty($postfields)) {
                    $url = "{$url}?{$postfields}";
                }
        }

        if ( isset($this->access_token) && $this->access_token )
            $headers[] = "Authorization: OAuth2 ".$this->access_token;

            if ( !empty($this->remote_ip) ) {
                if ( defined('SAE_ACCESSKEY') ) {
                    $headers[] = "SaeRemoteIP: " . $this->remote_ip;
                } else {
                    $headers[] = "API-RemoteIP: " . $this->remote_ip;
                }
            } else {
                if ( !defined('SAE_ACCESSKEY') ) {
                    $headers[] = "API-RemoteIP: " . $_SERVER['REMOTE_ADDR'];
                }
            }
            curl_setopt($ci, CURLOPT_URL, $url );
            curl_setopt($ci, CURLOPT_HTTPHEADER, $headers );
            curl_setopt($ci, CURLINFO_HEADER_OUT, TRUE );

            $response = curl_exec($ci);
            $this->http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);
            $this->http_info = array_merge($this->http_info, curl_getinfo($ci));
            $this->url = $url;

            if ($this->debug) {
                echo "=====post data======\r\n";
                var_dump($postfields);

                echo "=====headers======\r\n";
                print_r($headers);

                echo '=====request info====='."\r\n";
                print_r( curl_getinfo($ci) );

                echo '=====response====='."\r\n";
                print_r( $response );
            }
            curl_close ($ci);
            return $response;
    }

    /**
     * Get the header info to store.
     *
     * @return int
     * @ignore
     */
    function getHeader($ch, $header) {
        $i = strpos($header, ':');
        if (!empty($i)) {
            $key = str_replace('-', '_', strtolower(substr($header, 0, $i)));
            $value = trim(substr($header, $i + 2));
            $this->http_header[$key] = $value;
        }
        return strlen($header);
    }

    /**
     * @ignore
     */
    public static function build_http_query_multi($params) {
        if (!$params) return '';

        uksort($params, 'strcmp');

        $pairs = array();

        self::$boundary = $boundary = uniqid('------------------');
        $MPboundary = '--'.$boundary;
        $endMPboundary = $MPboundary. '--';
        $multipartbody = '';

        foreach ($params as $parameter => $value) {

            if( in_array($parameter, array('pic', 'image')) && $value{0} == '@' ) {
                $url = ltrim( $value, '@' );
                $content = file_get_contents( $url );
                $array = explode( '?', basename( $url ) );
                $filename = $array[0];

                $multipartbody .= $MPboundary . "\r\n";
                $multipartbody .= 'Content-Disposition: form-data; name="' . $parameter . '"; filename="' . $filename . '"'. "\r\n";
                $multipartbody .= "Content-Type: image/unknown\r\n\r\n";
                $multipartbody .= $content. "\r\n";
            } else {
                $multipartbody .= $MPboundary . "\r\n";
                $multipartbody .= 'content-disposition: form-data; name="' . $parameter . "\"\r\n\r\n";
                $multipartbody .= $value."\r\n";
            }

        }

        $multipartbody .= $endMPboundary;
        return $multipartbody;
    }
}


/**
 * 新浪微博操作类V2
 *
 * 使用前需要先手工调用saetv2.ex.class.php <br />
 *
 * @package sae
 * @author Easy Chen, Elmer Zhang,Lazypeople
 * @version 1.0
 */
class SaeTClientV2
{
    /**
     * 构造函数
     *
     * @access public
     * @param mixed $akey 微博开放平台应用APP KEY
     * @param mixed $skey 微博开放平台应用APP SECRET
     * @param mixed $access_token OAuth认证返回的token
     * @param mixed $refresh_token OAuth认证返回的token secret
     * @return void
     */
    function __construct( $akey, $skey, $access_token, $refresh_token = NULL)
    {
        $this->oauth = new SaeTOAuthV2( $akey, $skey, $access_token, $refresh_token );
    }

    /**
     * 开启调试信息
     *
     * 开启调试信息后，SDK会将每次请求微博API所发送的POST Data、Headers以及请求信息、返回内容输出出来。
     *
     * @access public
     * @param bool $enable 是否开启调试信息
     * @return void
     */
    function set_debug( $enable )
    {
        $this->oauth->debug = $enable;
    }

    /**
     * 设置用户IP
     *
     * SDK默认将会通过$_SERVER['REMOTE_ADDR']获取用户IP，在请求微博API时将用户IP附加到Request Header中。但某些情况下$_SERVER['REMOTE_ADDR']取到的IP并非用户IP，而是一个固定的IP（例如使用SAE的Cron或TaskQueue服务时），此时就有可能会造成该固定IP达到微博API调用频率限额，导致API调用失败。此时可使用本方法设置用户IP，以避免此问题。
     *
     * @access public
     * @param string $ip 用户IP
     * @return bool IP为非法IP字符串时，返回false，否则返回true
     */
    function set_remote_ip( $ip )
    {
        if ( ip2long($ip) !== false ) {
            $this->oauth->remote_ip = $ip;
            return true;
        } else {
            return false;
        }
    }

    /**
     * 获取最新的公共微博消息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/public_timeline statuses/public_timeline}
     *
     * @access public
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @return array
     */
    function public_timeline( $page = 1, $count = 50, $base_app = 0 )
    {
        $params = array();
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['base_app'] = intval($base_app);
        return $this->oauth->get('statuses/public_timeline', $params);//可能是接口的bug不能补全
    }

    /**
     * 获取当前登录用户及其所关注用户的最新微博消息。
     *
     * 获取当前登录用户及其所关注用户的最新微博消息。和用户登录 http://weibo.com 后在“我的首页”中看到的内容相同。同friends_timeline()
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/home_timeline statuses/home_timeline}
     *
     * @access public
     * @param int $page 指定返回结果的页码。根据当前登录用户所关注的用户数及这些被关注用户发表的微博数，翻页功能最多能查看的总记录数会有所不同，通常最多能查看1000条左右。默认值1。可选。
     * @param int $count 每次返回的记录数。缺省值50，最大值200。可选。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的微博消息（即比since_id发表时间晚的微博消息）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的微博消息。可选。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @param int $feature 过滤类型ID，0：全部、1：原创、2：图片、3：视频、4：音乐，默认为0。
     * @return array
     */
    function home_timeline( $page = 1, $count = 50, $since_id = 0, $max_id = 0, $base_app = 0, $feature = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['base_app'] = intval($base_app);
        $params['feature'] = intval($feature);

        return $this->oauth->get('statuses/home_timeline', $params);
    }

    /**
     * 获取当前登录用户及其所关注用户的最新微博消息。
     *
     * 获取当前登录用户及其所关注用户的最新微博消息。和用户登录 http://weibo.com 后在“我的首页”中看到的内容相同。同home_timeline()
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/friends_timeline statuses/friends_timeline}
     *
     * @access public
     * @param int $page 指定返回结果的页码。根据当前登录用户所关注的用户数及这些被关注用户发表的微博数，翻页功能最多能查看的总记录数会有所不同，通常最多能查看1000条左右。默认值1。可选。
     * @param int $count 每次返回的记录数。缺省值50，最大值200。可选。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的微博消息（即比since_id发表时间晚的微博消息）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的微博消息。可选。
     * @param int $base_app 是否基于当前应用来获取数据。1为限制本应用微博，0为不做限制。默认为0。可选。
     * @param int $feature 微博类型，0全部，1原创，2图片，3视频，4音乐. 返回指定类型的微博信息内容。转为为0。可选。
     * @return array
     */
    function friends_timeline( $page = 1, $count = 50, $since_id = 0, $max_id = 0, $base_app = 0, $feature = 0 )
    {
        return $this->home_timeline( $since_id, $max_id, $count, $page, $base_app, $feature);
    }

    /**
     * 获取用户发布的微博信息列表
     *
     * 返回用户的发布的最近n条信息，和用户微博页面返回内容是一致的。此接口也可以请求其他用户的最新发表微博。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/user_timeline statuses/user_timeline}
     *
     * @access public
     * @param int $page 页码
     * @param int $count 每次返回的最大记录数，最多返回200条，默认50。
     * @param mixed $uid 指定用户UID或微博昵称
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的微博消息（即比since_id发表时间晚的微博消息）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的提到当前登录用户微博消息。可选。
     * @param int $base_app 是否基于当前应用来获取数据。1为限制本应用微博，0为不做限制。默认为0。
     * @param int $feature 过滤类型ID，0：全部、1：原创、2：图片、3：视频、4：音乐，默认为0。
     * @param int $trim_user 返回值中user信息开关，0：返回完整的user信息、1：user字段仅返回uid，默认为0。
     * @return array
     */
    function user_timeline_by_id( $uid = NULL , $page = 1 , $count = 50 , $since_id = 0, $max_id = 0, $feature = 0, $trim_user = 0, $base_app = 0)
    {
        $params = array();
        $params['uid']=$uid;
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['base_app'] = intval($base_app);
        $params['feature'] = intval($feature);
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['trim_user'] = intval($trim_user);

        return $this->oauth->get( 'statuses/user_timeline', $params );
    }


    /**
     * 获取用户发布的微博信息列表
     *
     * 返回用户的发布的最近n条信息，和用户微博页面返回内容是一致的。此接口也可以请求其他用户的最新发表微博。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/user_timeline statuses/user_timeline}
     *
     * @access public
     * @param string $screen_name 微博昵称，主要是用来区分用户UID跟微博昵称，当二者一样而产生歧义的时候，建议使用该参数
     * @param int $page 页码
     * @param int $count 每次返回的最大记录数，最多返回200条，默认50。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的微博消息（即比since_id发表时间晚的微博消息）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的提到当前登录用户微博消息。可选。
     * @param int $feature 过滤类型ID，0：全部、1：原创、2：图片、3：视频、4：音乐，默认为0。
     * @param int $trim_user 返回值中user信息开关，0：返回完整的user信息、1：user字段仅返回uid，默认为0。
     * @param int $base_app 是否基于当前应用来获取数据。1为限制本应用微博，0为不做限制。默认为0。
     * @return array
     */
    function user_timeline_by_name( $screen_name = NULL , $page = 1 , $count = 50 , $since_id = 0, $max_id = 0, $feature = 0, $trim_user = 0, $base_app = 0 )
    {
        $params = array();
        $params['screen_name'] = $screen_name;
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['base_app'] = intval($base_app);
        $params['feature'] = intval($feature);
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['trim_user'] = intval($trim_user);

        return $this->oauth->get( 'statuses/user_timeline', $params );
    }



    /**
     * 批量获取指定的一批用户的timeline
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/timeline_batch statuses/timeline_batch}
     *
     * @param string $screen_name  需要查询的用户昵称，用半角逗号分隔，一次最多20个
     * @param int    $count        单页返回的记录条数，默认为50。
     * @param int    $page  返回结果的页码，默认为1。
     * @param int    $base_app  是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @param int    $feature   过滤类型ID，0：全部、1：原创、2：图片、3：视频、4：音乐，默认为0。
     * @return array
     */
    function timeline_batch_by_name( $screen_name, $page = 1, $count = 50, $feature = 0, $base_app = 0)
    {
        $params = array();
        if (is_array($screen_name) && !empty($screen_name)) {
            $params['screen_name'] = join(',', $screen_name);
        } else {
            $params['screen_name'] = $screen_name;
        }
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['base_app'] = intval($base_app);
        $params['feature'] = intval($feature);
        return $this->oauth->get('statuses/timeline_batch', $params);
    }

    /**
     * 批量获取指定的一批用户的timeline
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/timeline_batch statuses/timeline_batch}
     *
     * @param string $uids  需要查询的用户ID，用半角逗号分隔，一次最多20个。
     * @param int    $count        单页返回的记录条数，默认为50。
     * @param int    $page  返回结果的页码，默认为1。
     * @param int    $base_app  是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @param int    $feature   过滤类型ID，0：全部、1：原创、2：图片、3：视频、4：音乐，默认为0。
     * @return array
     */
    function timeline_batch_by_id( $uids, $page = 1, $count = 50, $feature = 0, $base_app = 0)
    {
        $params = array();
        if (is_array($uids) && !empty($uids)) {
            foreach($uids as $k => $v) {
                $this->id_format($uids[$k]);
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }
        $params['count'] = intval($count);
        $params['page'] = intval($page);
        $params['base_app'] = intval($base_app);
        $params['feature'] = intval($feature);
        return $this->oauth->get('statuses/timeline_batch', $params);
    }


    /**
     * 返回一条原创微博消息的最新n条转发微博消息。本接口无法对非原创微博进行查询。
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/repost_timeline statuses/repost_timeline}
     *
     * @access public
     * @param int $sid 要获取转发微博列表的原创微博ID。
     * @param int $page 返回结果的页码。
     * @param int $count 单页返回的最大记录数，最多返回200条，默认50。可选。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的记录（比since_id发表时间晚）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的记录。可选。
     * @param int $filter_by_author 作者筛选类型，0：全部、1：我关注的人、2：陌生人，默认为0。
     * @return array
     */
    function repost_timeline( $sid, $page = 1, $count = 50, $since_id = 0, $max_id = 0, $filter_by_author = 0 )
    {
        $this->id_format($sid);

        $params = array();
        $params['id'] = $sid;
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['filter_by_author'] = intval($filter_by_author);

        return $this->request_with_pager( 'statuses/repost_timeline', $page, $count, $params );
    }

    /**
     * 获取当前用户最新转发的n条微博消息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/repost_by_me statuses/repost_by_me}
     *
     * @access public
     * @param int $page 返回结果的页码。
     * @param int $count  每次返回的最大记录数，最多返回200条，默认50。可选。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的记录（比since_id发表时间晚）。可选。
     * @param int $max_id  若指定此参数，则返回ID小于或等于max_id的记录。可选。
     * @return array
     */
    function repost_by_me( $page = 1, $count = 50, $since_id = 0, $max_id = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }

        return $this->request_with_pager('statuses/repost_by_me', $page, $count, $params );
    }

    /**
     * 获取@当前用户的微博列表
     *
     * 返回最新n条提到登录用户的微博消息（即包含@username的微博消息）
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/mentions statuses/mentions}
     *
     * @access public
     * @param int $page 返回结果的页序号。
     * @param int $count 每次返回的最大记录数（即页面大小），不大于200，默认为50。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的微博消息（即比since_id发表时间晚的微博消息）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的提到当前登录用户微博消息。可选。
     * @param int $filter_by_author 作者筛选类型，0：全部、1：我关注的人、2：陌生人，默认为0。
     * @param int $filter_by_source 来源筛选类型，0：全部、1：来自微博、2：来自微群，默认为0。
     * @param int $filter_by_type 原创筛选类型，0：全部微博、1：原创的微博，默认为0。
     * @return array
     */
    function mentions( $page = 1, $count = 50, $since_id = 0, $max_id = 0, $filter_by_author = 0, $filter_by_source = 0, $filter_by_type = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['filter_by_author'] = $filter_by_author;
        $params['filter_by_source'] = $filter_by_source;
        $params['filter_by_type'] = $filter_by_type;

        return $this->request_with_pager( 'statuses/mentions', $page, $count, $params );
    }


    /**
     * 根据ID获取单条微博信息内容
     *
     * 获取单条ID的微博信息，作者信息将同时返回。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/show statuses/show}
     *
     * @access public
     * @param int $id 要获取已发表的微博ID, 如ID不存在返回空
     * @return array
     */
    function show_status( $id )
    {
        $this->id_format($id);
        $params = array();
        $params['id'] = $id;
        return $this->oauth->get('statuses/show', $params);
    }

    /**
     * 根据微博id号获取微博的信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/show_batch statuses/show_batch}
     *
     * @param string $ids 需要查询的微博ID，用半角逗号分隔，最多不超过50个。
     * @return array
     */
    function show_batch( $ids )
    {
        $params=array();
        if (is_array($ids) && !empty($ids)) {
            foreach($ids as $k => $v) {
                $this->id_format($ids[$k]);
            }
            $params['ids'] = join(',', $ids);
        } else {
            $params['ids'] = $ids;
        }
        return $this->oauth->get('statuses/show_batch', $params);
    }

    /**
     * 通过微博（评论、私信）ID获取其MID
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/querymid statuses/querymid}
     *
     * @param int|string $id  需要查询的微博（评论、私信）ID，批量模式下，用半角逗号分隔，最多不超过20个。
     * @param int $type  获取类型，1：微博、2：评论、3：私信，默认为1。
     * @param int $is_batch 是否使用批量模式，0：否、1：是，默认为0。
     * @return array
     */
    function querymid( $id, $type = 1, $is_batch = 0 )
    {
        $params = array();
        $params['id'] = $id;
        $params['type'] = intval($type);
        $params['is_batch'] = intval($is_batch);
        return $this->oauth->get( 'statuses/querymid',  $params);
    }

    /**
     * 通过微博（评论、私信）MID获取其ID
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/queryid statuses/queryid}
     *
     * @param int|string $mid  需要查询的微博（评论、私信）MID，批量模式下，用半角逗号分隔，最多不超过20个。
     * @param int $type  获取类型，1：微博、2：评论、3：私信，默认为1。
     * @param int $is_batch 是否使用批量模式，0：否、1：是，默认为0。
     * @param int $inbox  仅对私信有效，当MID类型为私信时用此参数，0：发件箱、1：收件箱，默认为0 。
     * @param int $isBase62 MID是否是base62编码，0：否、1：是，默认为0。
     * @return array
     */
    function queryid( $mid, $type = 1, $is_batch = 0, $inbox = 0, $isBase62 = 0)
    {
        $params = array();
        $params['mid'] = $mid;
        $params['type'] = intval($type);
        $params['is_batch'] = intval($is_batch);
        $params['inbox'] = intval($inbox);
        $params['isBase62'] = intval($isBase62);
        return $this->oauth->get('statuses/queryid', $params);
    }

    /**
     * 按天返回热门微博转发榜的微博列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/hot/repost_daily statuses/hot/repost_daily}
     *
     * @param int $count 返回的记录条数，最大不超过50，默认为20。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @return array
     */
    function repost_daily( $count = 20, $base_app = 0)
    {
        $params = array();
        $params['count'] = intval($count);
        $params['base_app'] = intval($base_app);
        return $this->oauth->get('statuses/hot/repost_daily',  $params);
    }

    /**
     * 按周返回热门微博转发榜的微博列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/hot/repost_weekly statuses/hot/repost_weekly}
     *
     * @param int $count 返回的记录条数，最大不超过50，默认为20。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @return array
     */
    function repost_weekly( $count = 20,  $base_app = 0)
    {
        $params = array();
        $params['count'] = intval($count);
        $params['base_app'] = intval($base_app);
        return $this->oauth->get( 'statuses/hot/repost_weekly',  $params);
    }

    /**
     * 按天返回热门微博评论榜的微博列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/hot/comments_daily statuses/hot/comments_daily}
     *
     * @param int $count 返回的记录条数，最大不超过50，默认为20。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @return array
     */
    function comments_daily( $count = 20,  $base_app = 0)
    {
        $params =  array();
        $params['count'] = intval($count);
        $params['base_app'] = intval($base_app);
        return $this->oauth->get( 'statuses/hot/comments_daily',  $params);
    }

    /**
     * 按周返回热门微博评论榜的微博列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/hot/comments_weekly statuses/hot/comments_weekly}
     *
     * @param int $count 返回的记录条数，最大不超过50，默认为20。
     * @param int $base_app 是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * @return array
     */
    function comments_weekly( $count = 20, $base_app = 0)
    {
        $params =  array();
        $params['count'] = intval($count);
        $params['base_app'] = intval($base_app);
        return $this->oauth->get( 'statuses/hot/comments_weekly', $params);
    }


    /**
     * 转发一条微博信息。
     *
     * 可加评论。为防止重复，发布的信息与最新信息一样话，将会被忽略。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/repost statuses/repost}
     *
     * @access public
     * @param int $sid 转发的微博ID
     * @param string $text 添加的评论信息。可选。
     * @param int $is_comment 是否在转发的同时发表评论，0：否、1：评论给当前微博、2：评论给原微博、3：都评论，默认为0。
     * @return array
     */
    function repost( $sid, $text = NULL, $is_comment = 0 )
    {
        $this->id_format($sid);

        $params = array();
        $params['id'] = $sid;
        $params['is_comment'] = $is_comment;
        if( $text ) $params['status'] = $text;

        return $this->oauth->post( 'statuses/repost', $params  );
    }

    /**
     * 删除一条微博
     *
     * 根据ID删除微博消息。注意：只能删除自己发布的信息。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/destroy statuses/destroy}
     *
     * @access public
     * @param int $id 要删除的微博ID
     * @return array
     */
    function delete( $id )
    {
        return $this->destroy( $id );
    }

    /**
     * 删除一条微博
     *
     * 删除微博。注意：只能删除自己发布的信息。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/destroy statuses/destroy}
     *
     * @access public
     * @param int $id 要删除的微博ID
     * @return array
     */
    function destroy( $id )
    {
        $this->id_format($id);
        $params = array();
        $params['id'] = $id;
        return $this->oauth->post( 'statuses/destroy',  $params );
    }


    /**
     * 发表微博
     *
     * 发布一条微博信息。
     * <br />注意：lat和long参数需配合使用，用于标记发表微博消息时所在的地理位置，只有用户设置中geo_enabled=true时候地理位置信息才有效。
     * <br />注意：为防止重复提交，当用户发布的微博消息与上次成功发布的微博消息内容一样时，将返回400错误，给出错误提示：“40025:Error: repeated weibo text!“。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/update statuses/update}
     *
     * @access public
     * @param string $status 要更新的微博信息。信息内容不超过140个汉字, 为空返回400错误。
     * @param float $lat 纬度，发表当前微博所在的地理位置，有效范围 -90.0到+90.0, +表示北纬。可选。
     * @param float $long 经度。有效范围-180.0到+180.0, +表示东经。可选。
     * @param mixed $annotations 可选参数。元数据，主要是为了方便第三方应用记录一些适合于自己使用的信息。每条微博可以包含一个或者多个元数据。请以json字串的形式提交，字串长度不超过512个字符，或者数组方式，要求json_encode后字串长度不超过512个字符。具体内容可以自定。例如：'[{"type2":123}, {"a":"b", "c":"d"}]'或array(array("type2"=>123), array("a"=>"b", "c"=>"d"))。
     * @param int $visible    微博的可见性，0：所有人能看，1：仅自己可见，2：密友可见，3：指定分组可见，默认为0
     * @return array
     */
    function update( $status, $lat = NULL, $long = NULL, $annotations = NULL, $visible=0 )
    {
        $params = array();
        $params['status'] = $status;
        $params['visible'] = $visible;
        if ($lat) {
            $params['lat'] = floatval($lat);
        }
        if ($long) {
            $params['long'] = floatval($long);
        }
        if (is_string($annotations)) {
            $params['annotations'] = $annotations;
        } elseif (is_array($annotations)) {
            $params['annotations'] = json_encode($annotations);
        }

        return $this->oauth->post( 'statuses/update', $params );
    }

    /**
     * 发表图片微博
     *
     * 发表图片微博消息。目前上传图片大小限制为<5M。
     * <br />注意：lat和long参数需配合使用，用于标记发表微博消息时所在的地理位置，只有用户设置中geo_enabled=true时候地理位置信息才有效。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/upload statuses/upload}
     *
     * @access public
     * @param string $status 要更新的微博信息。信息内容不超过140个汉字, 为空返回400错误。
     * @param string $pic_path 要发布的图片路径, 支持url。[只支持png/jpg/gif三种格式, 增加格式请修改get_image_mime方法]
     * @param float $lat 纬度，发表当前微博所在的地理位置，有效范围 -90.0到+90.0, +表示北纬。可选。
     * @param float $long 可选参数，经度。有效范围-180.0到+180.0, +表示东经。可选。
     * @param int $visible    微博的可见性，0：所有人能看，1：仅自己可见，2：密友可见，3：指定分组可见，默认为0
     * @return array
     */
    function upload( $status, $pic_path, $lat = NULL, $long = NULL, $visible=0 )
    {
        $params = array();
        $params['status'] = $status;
        $params['pic'] = '@'.$pic_path;
        $params['visible'] = $visible;
        if ($lat) {
            $params['lat'] = floatval($lat);
        }
        if ($long) {
            $params['long'] = floatval($long);
        }

        return $this->oauth->post( 'statuses/upload', $params, true );
    }

    /**
     * 指定一个图片URL地址抓取后上传并同时发布一条新微博
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/statuses/upload_url_text statuses/upload_url_text}
     *
     * @param string $status  要发布的微博文本内容，内容不超过140个汉字。
     * @param int $visible    微博的可见性，0：所有人能看，1：仅自己可见，2：密友可见，3：指定分组可见，默认为0
     * @param string $list_id 微博的保护投递指定分组ID，只有当visible参数为3时生效且必选。
     * @param string $pic_id 已经上传的图片pid，多个时使用英文半角逗号符分隔，最多不超过9个。
     * @param float $lat 纬度，有效范围：-90.0到+90.0，+表示北纬，默认为0.0。
     * @param float $long 经度，有效范围：-180.0到+180.0，+表示东经，默认为0.0。
     * @param string $annotations 元数据，主要是为了方便第三方应用记录一些适合于自己使用的信息，每条微博可以包含一个或者多个元数据，
     *                            必须以json字串的形式提交，字串长度不超过512个字符，具体内容可以自定。
     * @param string $url    图片的URL地址，必须以http开头。
     * @return array
     */
    function upload_url_text( $status,  $url , $visible=0, $list_id=NULL, $pic_id=NULL, $lat = NULL, $long=NULL, $annotations=NULL)
    {
        $params = array();
        $params['status'] = $status;
        $params['url'] = $url;
        $params['visible'] = $visible;
        if (!is_null($list_id)) {
            $params['list_id'] = $list_id;
        }
        if (!is_null($pic_id)) {
            $params['pic_id'] = $pic_id;
        }
        if (!is_null($lat)) {
            $params['lat'] = $lat;
        }
        if (!is_null($long)) {
            $params['long'] = $long;
        }
        if (!is_null($annotations)) {
            $params['annotations'] = $annotations;
        }
        return $this->oauth->post( 'statuses/upload_url_text', $params, true );
    }


    /**
     * 获取表情列表
     *
     * 返回新浪微博官方所有表情、魔法表情的相关信息。包括短语、表情类型、表情分类，是否热门等。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/emotions emotions}
     *
     * @access public
     * @param string $type 表情类别。"face":普通表情，"ani"：魔法表情，"cartoon"：动漫表情。默认为"face"。可选。
     * @param string $language 语言类别，"cnname"简体，"twname"繁体。默认为"cnname"。可选
     * @return array
     */
    function emotions( $type = "face", $language = "cnname" )
    {
        $params = array();
        $params['type'] = $type;
        $params['language'] = $language;
        return $this->oauth->get( 'emotions', $params );
    }


    /**
     * 根据微博ID返回某条微博的评论列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/show comments/show}
     *
     * @param int $sid 需要查询的微博ID。
     * @param int $page 返回结果的页码，默认为1。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $since_id 若指定此参数，则返回ID比since_id大的评论（即比since_id时间晚的评论），默认为0。
     * @param int $max_id  若指定此参数，则返回ID小于或等于max_id的评论，默认为0。
     * @param int $filter_by_author 作者筛选类型，0：全部、1：我关注的人、2：陌生人，默认为0。
     * @return array
     */
    function get_comments_by_sid( $sid, $page = 1, $count = 50, $since_id = 0, $max_id = 0, $filter_by_author = 0 )
    {
        $params = array();
        $this->id_format($sid);
        $params['id'] = $sid;
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['count'] = $count;
        $params['page'] = $page;
        $params['filter_by_author'] = $filter_by_author;
        return $this->oauth->get( 'comments/show',  $params );
    }


    /**
     * 获取当前登录用户所发出的评论列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/by_me comments/by_me}
     *
     * @param int $since_id 若指定此参数，则返回ID比since_id大的评论（即比since_id时间晚的评论），默认为0。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的评论，默认为0。
     * @param int $count  单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @param int $filter_by_source 来源筛选类型，0：全部、1：来自微博的评论、2：来自微群的评论，默认为0。
     * @return array
     */
    function comments_by_me( $page = 1 , $count = 50, $since_id = 0, $max_id = 0,  $filter_by_source = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['count'] = $count;
        $params['page'] = $page;
        $params['filter_by_source'] = $filter_by_source;
        return $this->oauth->get( 'comments/by_me', $params );
    }

    /**
     * 获取当前登录用户所接收到的评论列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/to_me comments/to_me}
     *
     * @param int $since_id 若指定此参数，则返回ID比since_id大的评论（即比since_id时间晚的评论），默认为0。
     * @param int $max_id  若指定此参数，则返回ID小于或等于max_id的评论，默认为0。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @param int $filter_by_author 作者筛选类型，0：全部、1：我关注的人、2：陌生人，默认为0。
     * @param int $filter_by_source 来源筛选类型，0：全部、1：来自微博的评论、2：来自微群的评论，默认为0。
     * @return array
     */
    function comments_to_me( $page = 1 , $count = 50, $since_id = 0, $max_id = 0, $filter_by_author = 0, $filter_by_source = 0)
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['count'] = $count;
        $params['page'] = $page;
        $params['filter_by_author'] = $filter_by_author;
        $params['filter_by_source'] = $filter_by_source;
        return $this->oauth->get( 'comments/to_me', $params );
    }

    /**
     * 最新评论(按时间)
     *
     * 返回最新n条发送及收到的评论。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/comments/timeline comments/timeline}
     *
     * @access public
     * @param int $page 页码
     * @param int $count 每次返回的最大记录数，最多返回200条，默认50。
     * @param int $since_id 若指定此参数，则只返回ID比since_id大的评论（比since_id发表时间晚）。可选。
     * @param int $max_id 若指定此参数，则返回ID小于或等于max_id的评论。可选。
     * @return array
     */
    function comments_timeline( $page = 1, $count = 50, $since_id = 0, $max_id = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }

        return $this->request_with_pager( 'comments/timeline', $page, $count, $params );
    }


    /**
     * 获取最新的提到当前登录用户的评论，即@我的评论
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/mentions comments/mentions}
     *
     * @param int $since_id 若指定此参数，则返回ID比since_id大的评论（即比since_id时间晚的评论），默认为0。
     * @param int $max_id  若指定此参数，则返回ID小于或等于max_id的评论，默认为0。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @param int $filter_by_author  作者筛选类型，0：全部、1：我关注的人、2：陌生人，默认为0。
     * @param int $filter_by_source 来源筛选类型，0：全部、1：来自微博的评论、2：来自微群的评论，默认为0。
     * @return array
     */
    function comments_mentions( $page = 1, $count = 50, $since_id = 0, $max_id = 0, $filter_by_author = 0, $filter_by_source = 0)
    {
        $params = array();
        $params['since_id'] = $since_id;
        $params['max_id'] = $max_id;
        $params['count'] = $count;
        $params['page'] = $page;
        $params['filter_by_author'] = $filter_by_author;
        $params['filter_by_source'] = $filter_by_source;
        return $this->oauth->get( 'comments/mentions', $params );
    }


    /**
     * 根据评论ID批量返回评论信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/show_batch comments/show_batch}
     *
     * @param string $cids 需要查询的批量评论ID，用半角逗号分隔，最大50
     * @return array
     */
    function comments_show_batch( $cids )
    {
        $params = array();
        if (is_array( $cids) && !empty( $cids)) {
            foreach($cids as $k => $v) {
                $this->id_format($cids[$k]);
            }
            $params['cids'] = join(',', $cids);
        } else {
            $params['cids'] = $cids;
        }
        return $this->oauth->get( 'comments/show_batch', $params );
    }


    /**
     * 对一条微博进行评论
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/comments/create comments/create}
     *
     * @param string $comment 评论内容，内容不超过140个汉字。
     * @param int $id 需要评论的微博ID。
     * @param int $comment_ori 当评论转发微博时，是否评论给原微博，0：否、1：是，默认为0。
     * @return array
     */
    function send_comment( $id , $comment , $comment_ori = 0)
    {
        $params = array();
        $params['comment'] = $comment;
        $this->id_format($id);
        $params['id'] = $id;
        $params['comment_ori'] = $comment_ori;
        return $this->oauth->post( 'comments/create', $params );
    }

    /**
     * 删除当前用户的微博评论信息。
     *
     * 注意：只能删除自己发布的评论，发布微博的用户不可以删除其他人的评论。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/statuses/comment_destroy statuses/comment_destroy}
     *
     * @access public
     * @param int $cid 要删除的评论id
     * @return array
     */
    function comment_destroy( $cid )
    {
        $params = array();
        $params['cid'] = $cid;
        return $this->oauth->post( 'comments/destroy', $params);
    }


    /**
     * 根据评论ID批量删除评论
     *
     * 注意：只能删除自己发布的评论，发部微博的用户不可以删除其他人的评论。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/comments/destroy_batch comments/destroy_batch}
     *
     * @access public
     * @param string $ids 需要删除的评论ID，用半角逗号隔开，最多20个。
     * @return array
     */
    function comment_destroy_batch( $ids )
    {
        $params = array();
        if (is_array($ids) && !empty($ids)) {
            foreach($ids as $k => $v) {
                $this->id_format($ids[$k]);
            }
            $params['cids'] = join(',', $ids);
        } else {
            $params['cids'] = $ids;
        }
        return $this->oauth->post( 'comments/destroy_batch', $params);
    }


    /**
     * 回复一条评论
     *
     * 为防止重复，发布的信息与最后一条评论/回复信息一样话，将会被忽略。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/comments/reply comments/reply}
     *
     * @access public
     * @param int $sid 微博id
     * @param string $text 评论内容。
     * @param int $cid 评论id
     * @param int $without_mention 1：回复中不自动加入“回复@用户名”，0：回复中自动加入“回复@用户名”.默认为0.
     * @param int $comment_ori	  当评论转发微博时，是否评论给原微博，0：否、1：是，默认为0。
     * @return array
     */
    function reply( $sid, $text, $cid, $without_mention = 0, $comment_ori = 0 )
    {
        $this->id_format( $sid );
        $this->id_format( $cid );
        $params = array();
        $params['id'] = $sid;
        $params['comment'] = $text;
        $params['cid'] = $cid;
        $params['without_mention'] = $without_mention;
        $params['comment_ori'] = $comment_ori;

        return $this->oauth->post( 'comments/reply', $params );

    }

    /**
     * 根据用户UID或昵称获取用户资料
     *
     * 按用户UID或昵称返回用户资料，同时也将返回用户的最新发布的微博。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/users/show users/show}
     *
     * @access public
     * @param int  $uid 用户UID。
     * @return array
     */
    function show_user_by_id( $uid )
    {
        $params=array();
        if ( $uid !== NULL ) {
            $this->id_format($uid);
            $params['uid'] = $uid;
        }

        return $this->oauth->get('users/show', $params );
    }

    /**
     * 根据用户UID或昵称获取用户资料
     *
     * 按用户UID或昵称返回用户资料，同时也将返回用户的最新发布的微博。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/users/show users/show}
     *
     * @access public
     * @param string  $screen_name 用户UID。
     * @return array
     */
    function show_user_by_name( $screen_name )
    {
        $params = array();
        $params['screen_name'] = $screen_name;

        return $this->oauth->get( 'users/show', $params );
    }

    /**
     * 通过个性化域名获取用户资料以及用户最新的一条微博
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/users/domain_show users/domain_show}
     *
     * @access public
     * @param mixed $domain 用户个性域名。例如：lazypeople，而不是http://weibo.com/lazypeople
     * @return array
     */
    function domain_show( $domain )
    {
        $params = array();
        $params['domain'] = $domain;
        return $this->oauth->get( 'users/domain_show', $params );
    }

    /**
     * 批量获取用户信息按uids
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/users/show_batch users/show_batch}
     *
     * @param string $uids 需要查询的用户ID，用半角逗号分隔，一次最多20个。
     * @return array
     */
    function users_show_batch_by_id( $uids )
    {
        $params = array();
        if (is_array( $uids ) && !empty( $uids )) {
            foreach( $uids as $k => $v ) {
                $this->id_format( $uids[$k] );
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }
        return $this->oauth->get( 'users/show_batch', $params );
    }

    /**
     * 批量获取用户信息按screen_name
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/users/show_batch users/show_batch}
     *
     * @param string  $screen_name 需要查询的用户昵称，用半角逗号分隔，一次最多20个。
     * @return array
     */
    function users_show_batch_by_name( $screen_name )
    {
        $params = array();
        if (is_array( $screen_name ) && !empty( $screen_name )) {
            $params['screen_name'] = join(',', $screen_name);
        } else {
            $params['screen_name'] = $screen_name;
        }
        return $this->oauth->get( 'users/show_batch', $params );
    }


    /**
     * 获取用户的关注列表
     *
     * 如果没有提供cursor参数，将只返回最前面的5000个关注id
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/friends friendships/friends}
     *
     * @access public
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @param int $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param int $uid  要获取的用户的ID。
     * @return array
     */
    function friends_by_id( $uid, $cursor = 0, $count = 50 )
    {
        $params = array();
        $params['cursor'] = $cursor;
        $params['count'] = $count;
        $params['uid'] = $uid;

        return $this->oauth->get( 'friendships/friends', $params );
    }


    /**
     * 获取用户的关注列表
     *
     * 如果没有提供cursor参数，将只返回最前面的5000个关注id
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/friends friendships/friends}
     *
     * @access public
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @param int $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param string $screen_name  要获取的用户的 screen_name
     * @return array
     */
    function friends_by_name( $screen_name, $cursor = 0, $count = 50 )
    {
        $params = array();
        $params['cursor'] = $cursor;
        $params['count'] = $count;
        $params['screen_name'] = $screen_name;
        return $this->oauth->get( 'friendships/friends', $params );
    }


    /**
     * 获取两个用户之间的共同关注人列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/in_common friendships/friends/in_common}
     *
     * @param int $uid  需要获取共同关注关系的用户UID
     * @param int $suid  需要获取共同关注关系的用户UID，默认为当前登录用户。
     * @param int $count  单页返回的记录条数，默认为50。
     * @param int $page  返回结果的页码，默认为1。
     * @return array
     */
    function friends_in_common( $uid, $suid = NULL, $page = 1, $count = 50 )
    {
        $params = array();
        $params['uid'] = $uid;
        $params['suid'] = $suid;
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'friendships/friends/in_common', $params  );
    }

    /**
     * 获取用户的双向关注列表，即互粉列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/bilateral friendships/friends/bilateral}
     *
     * @param int $uid  需要获取双向关注列表的用户UID。
     * @param int $count  单页返回的记录条数，默认为50。
     * @param int $page  返回结果的页码，默认为1。
     * @param int $sort  排序类型，0：按关注时间最近排序，默认为0。
     * @return array
     **/
    function bilateral( $uid, $page = 1, $count = 50, $sort = 0 )
    {
        $params = array();
        $params['uid'] = $uid;
        $params['count'] = $count;
        $params['page'] = $page;
        $params['sort'] = $sort;
        return $this->oauth->get( 'friendships/friends/bilateral', $params  );
    }

    /**
     * 获取用户的双向关注uid列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/bilateral/ids friendships/friends/bilateral/ids}
     *
     * @param int $uid  需要获取双向关注列表的用户UID。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page  返回结果的页码，默认为1。
     * @param int $sort  排序类型，0：按关注时间最近排序，默认为0。
     * @return array
     **/
    function bilateral_ids( $uid, $page = 1, $count = 50, $sort = 0)
    {
        $params = array();
        $params['uid'] = $uid;
        $params['count'] = $count;
        $params['page'] = $page;
        $params['sort'] = $sort;
        return $this->oauth->get( 'friendships/friends/bilateral/ids',  $params  );
    }

    /**
     * 获取用户的关注列表uid
     *
     * 如果没有提供cursor参数，将只返回最前面的5000个关注id
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/ids friendships/friends/ids}
     *
     * @access public
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @param int $count 每次返回的最大记录数（即页面大小），不大于5000, 默认返回500。
     * @param int $uid 要获取的用户 UID，默认为当前用户
     * @return array
     */
    function friends_ids_by_id( $uid, $cursor = 0, $count = 500 )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        $params['cursor'] = $cursor;
        $params['count'] = $count;
        return $this->oauth->get( 'friendships/friends/ids', $params );
    }

    /**
     * 获取用户的关注列表uid
     *
     * 如果没有提供cursor参数，将只返回最前面的5000个关注id
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/ids friendships/friends/ids}
     *
     * @access public
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @param int $count 每次返回的最大记录数（即页面大小），不大于5000, 默认返回500。
     * @param string $screen_name 要获取的用户的 screen_name，默认为当前用户
     * @return array
     */
    function friends_ids_by_name( $screen_name, $cursor = 0, $count = 500 )
    {
        $params = array();
        $params['cursor'] = $cursor;
        $params['count'] = $count;
        $params['screen_name'] = $screen_name;
        return $this->oauth->get( 'friendships/friends/ids', $params );
    }


    /**
     * 批量获取当前登录用户的关注人的备注信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/friends/remark_batch friendships/friends/remark_batch}
     *
     * @param string $uids  需要获取备注的用户UID，用半角逗号分隔，最多不超过50个。
     * @return array
     **/
    function friends_remark_batch( $uids )
    {
        $params = array();
        if (is_array( $uids ) && !empty( $uids )) {
            foreach( $uids as $k => $v) {
                $this->id_format( $uids[$k] );
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }
        return $this->oauth->get( 'friendships/friends/remark_batch', $params  );
    }

    /**
     * 获取用户的粉丝列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/followers friendships/followers}
     *
     * @param int $uid  需要查询的用户UID
     * @param int $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param int $cursor false 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @return array
     **/
    function followers_by_id( $uid , $cursor = 0 , $count = 50)
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        $params['count'] = $count;
        $params['cursor'] = $cursor;
        return $this->oauth->get( 'friendships/followers', $params  );
    }

    /**
     * 获取用户的粉丝列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/followers friendships/followers}
     *
     * @param string $screen_name  需要查询的用户的昵称
     * @param int  $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param int  $cursor false 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @return array
     **/
    function followers_by_name( $screen_name, $cursor = 0 , $count = 50 )
    {
        $params = array();
        $params['screen_name'] = $screen_name;
        $params['count'] = $count;
        $params['cursor'] = $cursor;
        return $this->oauth->get( 'friendships/followers', $params  );
    }

    /**
     * 获取用户的粉丝列表uid
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/followers friendships/followers}
     *
     * @param int $uid 需要查询的用户UID
     * @param int $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @return array
     **/
    function followers_ids_by_id( $uid, $cursor = 0 , $count = 50 )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        $params['count'] = $count;
        $params['cursor'] = $cursor;
        return $this->oauth->get( 'friendships/followers/ids', $params  );
    }

    /**
     * 获取用户的粉丝列表uid
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/followers friendships/followers}
     *
     * @param string $screen_name 需要查询的用户screen_name
     * @param int $count 单页返回的记录条数，默认为50，最大不超过200。
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @return array
     **/
    function followers_ids_by_name( $screen_name, $cursor = 0 , $count = 50 )
    {
        $params = array();
        $params['screen_name'] = $screen_name;
        $params['count'] = $count;
        $params['cursor'] = $cursor;
        return $this->oauth->get( 'friendships/followers/ids', $params  );
    }

    /**
     * 获取优质粉丝
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/followers/active friendships/followers/active}
     *
     * @param int $uid 需要查询的用户UID。
     * @param int $count 返回的记录条数，默认为20，最大不超过200。
     * @return array
     **/
    function followers_active( $uid,  $count = 20)
    {
        $param = array();
        $this->id_format($uid);
        $param['uid'] = $uid;
        $param['count'] = $count;
        return $this->oauth->get( 'friendships/followers/active', $param);
    }


    /**
     * 获取当前登录用户的关注人中又关注了指定用户的用户列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/friends_chain/followers friendships/friends_chain/followers}
     *
     * @param int $uid 指定的关注目标用户UID。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @return array
     **/
    function friends_chain_followers( $uid, $page = 1, $count = 50 )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'friendships/friends_chain/followers',  $params );
    }

    /**
     * 返回两个用户关系的详细情况
     *
     * 如果源用户或目的用户不存在，将返回http的400错误
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/show friendships/show}
     *
     * @access public
     * @param mixed $target_id 目标用户UID
     * @param mixed $source_id 源用户UID，可选，默认为当前的用户
     * @return array
     */
    function is_followed_by_id( $target_id, $source_id = NULL )
    {
        $params = array();
        $this->id_format($target_id);
        $params['target_id'] = $target_id;

        if ( $source_id != NULL ) {
            $this->id_format($source_id);
            $params['source_id'] = $source_id;
        }

        return $this->oauth->get( 'friendships/show', $params );
    }

    /**
     * 返回两个用户关系的详细情况
     *
     * 如果源用户或目的用户不存在，将返回http的400错误
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/show friendships/show}
     *
     * @access public
     * @param mixed $target_name 目标用户的微博昵称
     * @param mixed $source_name 源用户的微博昵称，可选，默认为当前的用户
     * @return array
     */
    function is_followed_by_name( $target_name, $source_name = NULL )
    {
        $params = array();
        $params['target_screen_name'] = $target_name;

        if ( $source_name != NULL ) {
            $params['source_screen_name'] = $source_name;
        }

        return $this->oauth->get( 'friendships/show', $params );
    }

    /**
     * 关注一个用户。
     *
     * 成功则返回关注人的资料，目前最多关注2000人，失败则返回一条字符串的说明。如果已经关注了此人，则返回http 403的状态。关注不存在的ID将返回400。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/create friendships/create}
     *
     * @access public
     * @param int $uid 要关注的用户UID
     * @return array
     */
    function follow_by_id( $uid )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        return $this->oauth->post( 'friendships/create', $params );
    }

    /**
     * 关注一个用户。
     *
     * 成功则返回关注人的资料，目前的最多关注2000人，失败则返回一条字符串的说明。如果已经关注了此人，则返回http 403的状态。关注不存在的ID将返回400。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/create friendships/create}
     *
     * @access public
     * @param string $screen_name 要关注的用户昵称
     * @return array
     */
    function follow_by_name( $screen_name )
    {
        $params = array();
        $params['screen_name'] = $screen_name;
        return $this->oauth->post( 'friendships/create', $params);
    }


    /**
     * 根据用户UID批量关注用户
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/friendships/create_batch friendships/create_batch}
     *
     * @param string $uids 要关注的用户UID，用半角逗号分隔，最多不超过20个。
     * @return array
     */
    function follow_create_batch( $uids )
    {
        $params = array();
        if (is_array($uids) && !empty($uids)) {
            foreach($uids as $k => $v) {
                $this->id_format($uids[$k]);
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }
        return $this->oauth->post( 'friendships/create_batch', $params);
    }

    /**
     * 取消关注某用户
     *
     * 取消关注某用户。成功则返回被取消关注人的资料，失败则返回一条字符串的说明。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/destroy friendships/destroy}
     *
     * @access public
     * @param int $uid 要取消关注的用户UID
     * @return array
     */
    function unfollow_by_id( $uid )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        return $this->oauth->post( 'friendships/destroy', $params);
    }

    /**
     * 取消关注某用户
     *
     * 取消关注某用户。成功则返回被取消关注人的资料，失败则返回一条字符串的说明。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/destroy friendships/destroy}
     *
     * @access public
     * @param string $screen_name 要取消关注的用户昵称
     * @return array
     */
    function unfollow_by_name( $screen_name )
    {
        $params = array();
        $params['screen_name'] = $screen_name;
        return $this->oauth->post( 'friendships/destroy', $params);
    }

    /**
     * 更新当前登录用户所关注的某个好友的备注信息
     *
     * 只能修改当前登录用户所关注的用户的备注信息。否则将给出400错误。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/friendships/remark/update friendships/remark/update}
     *
     * @access public
     * @param int $uid 需要修改备注信息的用户ID。
     * @param string $remark 备注信息。
     * @return array
     */
    function update_remark( $uid, $remark )
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        $params['remark'] = $remark;
        return $this->oauth->post( 'friendships/remark/update', $params);
    }

    /**
     * 获取当前用户最新私信列表
     *
     * 返回用户的最新n条私信，并包含发送者和接受者的详细资料。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages direct_messages}
     *
     * @access public
     * @param int $page 页码
     * @param int $count 每次返回的最大记录数，最多返回200条，默认50。
     * @param int64 $since_id 返回ID比数值since_id大（比since_id时间晚的）的私信。可选。
     * @param int64 $max_id 返回ID不大于max_id(时间不晚于max_id)的私信。可选。
     * @return array
     */
    function list_dm( $page = 1, $count = 50, $since_id = 0, $max_id = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }

        return $this->request_with_pager( 'direct_messages', $page, $count, $params );
    }

    /**
     * 获取当前用户发送的最新私信列表
     *
     * 返回登录用户已发送最新50条私信。包括发送者和接受者的详细资料。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages/sent direct_messages/sent}
     *
     * @access public
     * @param int $page 页码
     * @param int $count 每次返回的最大记录数，最多返回200条，默认50。
     * @param int64 $since_id 返回ID比数值since_id大（比since_id时间晚的）的私信。可选。
     * @param int64 $max_id 返回ID不大于max_id(时间不晚于max_id)的私信。可选。
     * @return array
     */
    function list_dm_sent( $page = 1, $count = 50, $since_id = 0, $max_id = 0 )
    {
        $params = array();
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }

        return $this->request_with_pager( 'direct_messages/sent', $page, $count, $params );
    }


    /**
     * 获取与当前登录用户有私信往来的用户列表，与该用户往来的最新私信
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/direct_messages/user_list direct_messages/user_list}
     *
     * @param int $count  单页返回的记录条数，默认为20。
     * @param int $cursor 返回结果的游标，下一页用返回值里的next_cursor，上一页用previous_cursor，默认为0。
     * @return array
     */
    function dm_user_list( $count = 20, $cursor = 0)
    {
        $params = array();
        $params['count'] = $count;
        $params['cursor'] = $cursor;
        return $this->oauth->get( 'direct_messages/user_list', $params );
    }

    /**
     * 获取与指定用户的往来私信列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/direct_messages/conversation direct_messages/conversation}
     *
     * @param int $uid 需要查询的用户的UID。
     * @param int $since_id 若指定此参数，则返回ID比since_id大的私信（即比since_id时间晚的私信），默认为0。
     * @param int $max_id  若指定此参数，则返回ID小于或等于max_id的私信，默认为0。
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page  返回结果的页码，默认为1。
     * @return array
     */
    function dm_conversation( $uid, $page = 1, $count = 50, $since_id = 0, $max_id = 0)
    {
        $params = array();
        $this->id_format($uid);
        $params['uid'] = $uid;
        if ($since_id) {
            $this->id_format($since_id);
            $params['since_id'] = $since_id;
        }
        if ($max_id) {
            $this->id_format($max_id);
            $params['max_id'] = $max_id;
        }
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'direct_messages/conversation', $params );
    }

    /**
     * 根据私信ID批量获取私信内容
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/direct_messages/show_batch direct_messages/show_batch}
     *
     * @param string  $dmids 需要查询的私信ID，用半角逗号分隔，一次最多50个
     * @return array
     */
    function dm_show_batch( $dmids )
    {
        $params = array();
        if (is_array($dmids) && !empty($dmids)) {
            foreach($dmids as $k => $v) {
                $this->id_format($dmids[$k]);
            }
            $params['dmids'] = join(',', $dmids);
        } else {
            $params['dmids'] = $dmids;
        }
        return $this->oauth->get( 'direct_messages/show_batch',  $params );
    }

    /**
     * 发送私信
     *
     * 发送一条私信。成功将返回完整的发送消息。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages/new direct_messages/new}
     *
     * @access public
     * @param int $uid 用户UID
     * @param string $text 要发生的消息内容，文本大小必须小于300个汉字。
     * @param int $id 需要发送的微博ID。
     * @return array
     */
    function send_dm_by_id( $uid, $text, $id = NULL )
    {
        $params = array();
        $this->id_format( $uid );
        $params['text'] = $text;
        $params['uid'] = $uid;
        if ($id) {
            $this->id_format( $id );
            $params['id'] = $id;
        }
        return $this->oauth->post( 'direct_messages/new', $params );
    }

    /**
     * 发送私信
     *
     * 发送一条私信。成功将返回完整的发送消息。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages/new direct_messages/new}
     *
     * @access public
     * @param string $screen_name 用户昵称
     * @param string $text 要发生的消息内容，文本大小必须小于300个汉字。
     * @param int $id 需要发送的微博ID。
     * @return array
     */
    function send_dm_by_name( $screen_name, $text, $id = NULL )
    {
        $params = array();
        $params['text'] = $text;
        $params['screen_name'] = $screen_name;
        if ($id) {
            $this->id_format( $id );
            $params['id'] = $id;
        }
        return $this->oauth->post( 'direct_messages/new', $params);
    }

    /**
     * 删除一条私信
     *
     * 按ID删除私信。操作用户必须为私信的接收人。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages/destroy direct_messages/destroy}
     *
     * @access public
     * @param int $did 要删除的私信主键ID
     * @return array
     */
    function delete_dm( $did )
    {
        $this->id_format($did);
        $params = array();
        $params['id'] = $did;
        return $this->oauth->post('direct_messages/destroy', $params);
    }

    /**
     * 批量删除私信
     *
     * 批量删除当前登录用户的私信。出现异常时，返回400错误。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/direct_messages/destroy_batch direct_messages/destroy_batch}
     *
     * @access public
     * @param mixed $dids 欲删除的一组私信ID，用半角逗号隔开，或者由一组评论ID组成的数组。最多20个。例如："4976494627, 4976262053"或array(4976494627,4976262053);
     * @return array
     */
    function delete_dms( $dids )
    {
        $params = array();
        if (is_array($dids) && !empty($dids)) {
            foreach($dids as $k => $v) {
                $this->id_format($dids[$k]);
            }
            $params['ids'] = join(',', $dids);
        } else {
            $params['ids'] = $dids;
        }

        return $this->oauth->post( 'direct_messages/destroy_batch', $params);
    }



    /**
     * 获取用户基本信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/basic account/profile/basic}
     *
     * @param int $uid  需要获取基本信息的用户UID，默认为当前登录用户。
     * @return array
     */
    function account_profile_basic( $uid = NULL  )
    {
        $params = array();
        if ($uid) {
            $this->id_format($uid);
            $params['uid'] = $uid;
        }
        return $this->oauth->get( 'account/profile/basic', $params );
    }

    /**
     * 获取用户的教育信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/education account/profile/education}
     *
     * @param int $uid  需要获取教育信息的用户UID，默认为当前登录用户。
     * @return array
     */
    function account_education( $uid = NULL )
    {
        $params = array();
        if ($uid) {
            $this->id_format($uid);
            $params['uid'] = $uid;
        }
        return $this->oauth->get( 'account/profile/education', $params );
    }

    /**
     * 批量获取用户的教育信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/education_batch account/profile/education_batch}
     *
     * @param string $uids 需要获取教育信息的用户UID，用半角逗号分隔，最多不超过20。
     * @return array
     */
    function account_education_batch( $uids  )
    {
        $params = array();
        if (is_array($uids) && !empty($uids)) {
            foreach($uids as $k => $v) {
                $this->id_format($uids[$k]);
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }

        return $this->oauth->get( 'account/profile/education_batch', $params );
    }


    /**
     * 获取用户的职业信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/career account/profile/career}
     *
     * @param int $uid  需要获取教育信息的用户UID，默认为当前登录用户。
     * @return array
     */
    function account_career( $uid = NULL )
    {
        $params = array();
        if ($uid) {
            $this->id_format($uid);
            $params['uid'] = $uid;
        }
        return $this->oauth->get( 'account/profile/career', $params );
    }

    /**
     * 批量获取用户的职业信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/career_batch account/profile/career_batch}
     *
     * @param string $uids 需要获取教育信息的用户UID，用半角逗号分隔，最多不超过20。
     * @return array
     */
    function account_career_batch( $uids )
    {
        $params = array();
        if (is_array($uids) && !empty($uids)) {
            foreach($uids as $k => $v) {
                $this->id_format($uids[$k]);
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }

        return $this->oauth->get( 'account/profile/career_batch', $params );
    }

    /**
     * 获取隐私信息设置情况
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/get_privacy account/get_privacy}
     *
     * @access public
     * @return array
     */
    function get_privacy()
    {
        return $this->oauth->get('account/get_privacy');
    }

    /**
     * 获取所有的学校列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/school_list account/profile/school_list}
     *
     * @param array $query 搜索选项。格式：array('key0'=>'value0', 'key1'=>'value1', ....)。支持的key:
     *  - province	int		省份范围，省份ID。
     *  - city		int		城市范围，城市ID。
     *  - area		int		区域范围，区ID。
     *  - type		int		学校类型，1：大学、2：高中、3：中专技校、4：初中、5：小学，默认为1。
     *  - capital	string	学校首字母，默认为A。
     *  - keyword	string	学校名称关键字。
     *  - count		int		返回的记录条数，默认为10。
     * 参数keyword与capital二者必选其一，且只能选其一。按首字母capital查询时，必须提供province参数。
     * @access public
     * @return array
     */
    function school_list( $query )
    {
        $params = $query;

        return $this->oauth->get( 'account/profile/school_list', $params );
    }

    /**
     * 获取当前登录用户的API访问频率限制情况
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/rate_limit_status account/rate_limit_status}
     *
     * @access public
     * @return array
     */
    function rate_limit_status()
    {
        return $this->oauth->get( 'account/rate_limit_status' );
    }

    /**
     * OAuth授权之后，获取授权用户的UID
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/get_uid account/get_uid}
     *
     * @access public
     * @return array
     */
    function get_uid()
    {
        return $this->oauth->get( 'account/get_uid' );
    }


    /**
     * 更改用户资料
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/basic_update account/profile/basic_update}
     *
     * @access public
     * @param array $profile 要修改的资料。格式：array('key1'=>'value1', 'key2'=>'value2', .....)。
     * 支持修改的项：
     *  - screen_name		string	用户昵称，不可为空。
     *  - gender	i		string	用户性别，m：男、f：女，不可为空。
     *  - real_name			string	用户真实姓名。
     *  - real_name_visible	int		真实姓名可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - province	true	int		省份代码ID，不可为空。
     *  - city	true		int		城市代码ID，不可为空。
     *  - birthday			string	用户生日，格式：yyyy-mm-dd。
     *  - birthday_visible	int		生日可见范围，0：保密、1：只显示月日、2：只显示星座、3：所有人可见。
     *  - qq				string	用户QQ号码。
     *  - qq_visible		int		用户QQ可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - msn				string	用户MSN。
     *  - msn_visible		int		用户MSN可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - url				string	用户博客地址。
     *  - url_visible		int		用户博客地址可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - credentials_type	int		证件类型，1：身份证、2：学生证、3：军官证、4：护照。
     *  - credentials_num	string	证件号码。
     *  - email				string	用户常用邮箱地址。
     *  - email_visible		int		用户常用邮箱地址可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - lang				string	语言版本，zh_cn：简体中文、zh_tw：繁体中文。
     *  - description		string	用户描述，最长不超过70个汉字。
     * 填写birthday参数时，做如下约定：
     *  - 只填年份时，采用1986-00-00格式；
     *  - 只填月份时，采用0000-08-00格式；
     *  - 只填某日时，采用0000-00-28格式。
     * @return array
     */
    function update_profile( $profile )
    {
        return $this->oauth->post( 'account/profile/basic_update',  $profile);
    }


    /**
     * 设置教育信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/edu_update account/profile/edu_update}
     *
     * @access public
     * @param array $edu_update 要修改的学校信息。格式：array('key1'=>'value1', 'key2'=>'value2', .....)。
     * 支持设置的项：
     *  - type			int		学校类型，1：大学、2：高中、3：中专技校、4：初中、5：小学，默认为1。必填参数
     *  - school_id	`	int		学校代码，必填参数
     *  - id			string	需要修改的教育信息ID，不传则为新建，传则为更新。
     *  - year			int		入学年份，最小为1900，最大不超过当前年份
     *  - department	string	院系或者班别。
     *  - visible		int		开放等级，0：仅自己可见、1：关注的人可见、2：所有人可见。
     * @return array
     */
    function edu_update( $edu_update )
    {
        return $this->oauth->post( 'account/profile/edu_update',  $edu_update);
    }

    /**
     * 根据学校ID删除用户的教育信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/edu_destroy account/profile/edu_destroy}
     *
     * @param int $id 教育信息里的学校ID。
     * @return array
     */
    function edu_destroy( $id )
    {
        $this->id_format( $id );
        $params = array();
        $params['id'] = $id;
        return $this->oauth->post( 'account/profile/edu_destroy', $params);
    }

    /**
     * 设置职业信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/car_update account/profile/car_update}
     *
     * @param array $car_update 要修改的职业信息。格式：array('key1'=>'value1', 'key2'=>'value2', .....)。
     * 支持设置的项：
     *  - id			string	需要更新的职业信息ID。
     *  - start			int		进入公司年份，最小为1900，最大为当年年份。
     *  - end			int		离开公司年份，至今填0。
     *  - department	string	工作部门。
     *  - visible		int		可见范围，0：自己可见、1：关注人可见、2：所有人可见。
     *  - province		int		省份代码ID，不可为空值。
     *  - city			int		城市代码ID，不可为空值。
     *  - company		string	公司名称，不可为空值。
     * 参数province与city二者必选其一<br />
     * 参数id为空，则为新建职业信息，参数company变为必填项，参数id非空，则为更新，参数company可选
     * @return array
     */
    function car_update( $car_update )
    {
        return $this->oauth->post( 'account/profile/car_update', $car_update);
    }

    /**
     * 根据公司ID删除用户的职业信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/profile/car_destroy account/profile/car_destroy}
     *
     * @access public
     * @param int $id  职业信息里的公司ID
     * @return array
     */
    function car_destroy( $id )
    {
        $this->id_format($id);
        $params = array();
        $params['id'] = $id;
        return $this->oauth->post( 'account/profile/car_destroy', $params);
    }

    /**
     * 更改头像
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/avatar/upload account/avatar/upload}
     *
     * @param string $image_path 要上传的头像路径, 支持url。[只支持png/jpg/gif三种格式, 增加格式请修改get_image_mime方法] 必须为小于700K的有效的GIF, JPG图片. 如果图片大于500像素将按比例缩放。
     * @return array
     */
    function update_profile_image( $image_path )
    {
        $params = array();
        $params['image'] = "@{$image_path}";

        return $this->oauth->post('account/avatar/upload', $params, true);
    }

    /**
     * 设置隐私信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/account/update_privacy account/update_privacy}
     *
     * @param array $privacy_settings 要修改的隐私设置。格式：array('key1'=>'value1', 'key2'=>'value2', .....)。
     * 支持设置的项：
     *  - comment	int	是否可以评论我的微博，0：所有人、1：关注的人，默认为0。
     *  - geo		int	是否开启地理信息，0：不开启、1：开启，默认为1。
     *  - message	int	是否可以给我发私信，0：所有人、1：关注的人，默认为0。
     *  - realname	int	是否可以通过真名搜索到我，0：不可以、1：可以，默认为0。
     *  - badge		int	勋章是否可见，0：不可见、1：可见，默认为1。
     *  - mobile	int	是否可以通过手机号码搜索到我，0：不可以、1：可以，默认为0。
     * 以上参数全部选填
     * @return array
     */
    function update_privacy( $privacy_settings )
    {
        return $this->oauth->post( 'account/update_privacy', $privacy_settings);
    }


    /**
     * 获取当前用户的收藏列表
     *
     * 返回用户的发布的最近20条收藏信息，和用户收藏页面返回内容是一致的。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/favorites favorites}
     *
     * @access public
     * @param  int $page 返回结果的页码，默认为1。
     * @param  int $count 单页返回的记录条数，默认为50。
     * @return array
     */
    function get_favorites( $page = 1, $count = 50 )
    {
        $params = array();
        $params['page'] = intval($page);
        $params['count'] = intval($count);

        return $this->oauth->get( 'favorites', $params );
    }


    /**
     * 根据收藏ID获取指定的收藏信息
     *
     * 根据收藏ID获取指定的收藏信息。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/favorites/show favorites/show}
     *
     * @access public
     * @param int $id 需要查询的收藏ID。
     * @return array
     */
    function favorites_show( $id )
    {
        $params = array();
        $this->id_format($id);
        $params['id'] = $id;
        return $this->oauth->get( 'favorites/show', $params );
    }


    /**
     * 根据标签获取当前登录用户该标签下的收藏列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/by_tags favorites/by_tags}
     *
     *
     * @param int $tid  需要查询的标签ID。'
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @return array
     */
    function favorites_by_tags( $tid, $page = 1, $count = 50)
    {
        $params = array();
        $params['tid'] = $tid;
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'favorites/by_tags', $params );
    }


    /**
     * 获取当前登录用户的收藏标签列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/tags favorites/tags}
     *
     * @access public
     * @param int $count 单页返回的记录条数，默认为50。
     * @param int $page 返回结果的页码，默认为1。
     * @return array
     */
    function favorites_tags( $page = 1, $count = 50)
    {
        $params = array();
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'favorites/tags', $params );
    }


    /**
     * 收藏一条微博信息
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/create favorites/create}
     *
     * @access public
     * @param int $sid 收藏的微博id
     * @return array
     */
    function add_to_favorites( $sid )
    {
        $this->id_format($sid);
        $params = array();
        $params['id'] = $sid;

        return $this->oauth->post( 'favorites/create', $params );
    }

    /**
     * 删除微博收藏。
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/destroy favorites/destroy}
     *
     * @access public
     * @param int $id 要删除的收藏微博信息ID.
     * @return array
     */
    function remove_from_favorites( $id )
    {
        $this->id_format($id);
        $params = array();
        $params['id'] = $id;
        return $this->oauth->post( 'favorites/destroy', $params);
    }


    /**
     * 批量删除微博收藏。
     *
     * 批量删除当前登录用户的收藏。出现异常时，返回HTTP400错误。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/favorites/destroy_batch favorites/destroy_batch}
     *
     * @access public
     * @param mixed $fids 欲删除的一组私信ID，用半角逗号隔开，或者由一组评论ID组成的数组。最多20个。例如："231101027525486630,201100826122315375"或array(231101027525486630,201100826122315375);
     * @return array
     */
    function remove_from_favorites_batch( $fids )
    {
        $params = array();
        if (is_array($fids) && !empty($fids)) {
            foreach ($fids as $k => $v) {
                $this->id_format($fids[$k]);
            }
            $params['ids'] = join(',', $fids);
        } else {
            $params['ids'] = $fids;
        }

        return $this->oauth->post( 'favorites/destroy_batch', $params);
    }


    /**
     * 更新一条收藏的收藏标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/tags/update favorites/tags/update}
     *
     * @access public
     * @param int $id 需要更新的收藏ID。
     * @param string $tags 需要更新的标签内容，用半角逗号分隔，最多不超过2条。
     * @return array
     */
    function favorites_tags_update( $id,  $tags )
    {
        $params = array();
        $params['id'] = $id;
        if (is_array($tags) && !empty($tags)) {
            foreach ($tags as $k => $v) {
                $this->id_format($tags[$k]);
            }
            $params['tags'] = join(',', $tags);
        } else {
            $params['tags'] = $tags;
        }
        return $this->oauth->post( 'favorites/tags/update', $params );
    }

    /**
     * 更新当前登录用户所有收藏下的指定标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/favorites/tags/update_batch favorites/tags/update_batch}
     *
     * @param int $tid  需要更新的标签ID。必填
     * @param string $tag  需要更新的标签内容。必填
     * @return array
     */
    function favorites_update_batch( $tid, $tag )
    {
        $params = array();
        $params['tid'] = $tid;
        $params['tag'] = $tag;
        return $this->oauth->post( 'favorites/tags/update_batch', $params);
    }

    /**
     * 删除当前登录用户所有收藏下的指定标签
     *
     * 删除标签后，该用户所有收藏中，添加了该标签的收藏均解除与该标签的关联关系
     * <br />对应API：{@link http://open.weibo.com/wiki/2/favorites/tags/destroy_batch favorites/tags/destroy_batch}
     *
     * @param int $tid  需要更新的标签ID。必填
     * @return array
     */
    function favorites_tags_destroy_batch( $tid )
    {
        $params = array();
        $params['tid'] = $tid;
        return $this->oauth->post( 'favorites/tags/destroy_batch', $params);
    }

    /**
     * 获取某用户的话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends trends}
     *
     * @param int $uid 查询用户的ID。默认为当前用户。可选。
     * @param int $page 指定返回结果的页码。可选。
     * @param int $count 单页大小。缺省值10。可选。
     * @return array
     */
    function get_trends( $uid = NULL, $page = 1, $count = 10 )
    {
        $params = array();
        if ($uid) {
            $params['uid'] = $uid;
        } else {
            $user_info = $this->get_uid();
            $params['uid'] = $user_info['uid'];
        }
        $this->id_format( $params['uid'] );
        $params['page'] = $page;
        $params['count'] = $count;
        return $this->oauth->get( 'trends', $params );
    }


    /**
     * 判断当前用户是否关注某话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/is_follow trends/is_follow}
     *
     * @access public
     * @param string $trend_name 话题关键字。
     * @return array
     */
    function trends_is_follow( $trend_name )
    {
        $params = array();
        $params['trend_name'] = $trend_name;
        return $this->oauth->get( 'trends/is_follow', $params );
    }

    /**
     * 返回最近一小时内的热门话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/hourly trends/hourly}
     *
     * @param  int $base_app 是否基于当前应用来获取数据。1表示基于当前应用来获取数据，默认为0。可选。
     * @return array
     */
    function hourly_trends( $base_app = 0 )
    {
        $params = array();
        $params['base_app'] = $base_app;

        return $this->oauth->get( 'trends/hourly', $params );
    }

    /**
     * 返回最近一天内的热门话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/daily trends/daily}
     *
     * @param int $base_app 是否基于当前应用来获取数据。1表示基于当前应用来获取数据，默认为0。可选。
     * @return array
     */
    function daily_trends( $base_app = 0 )
    {
        $params = array();
        $params['base_app'] = $base_app;

        return $this->oauth->get( 'trends/daily', $params );
    }

    /**
     * 返回最近一周内的热门话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/weekly trends/weekly}
     *
     * @access public
     * @param int $base_app 是否基于当前应用来获取数据。1表示基于当前应用来获取数据，默认为0。可选。
     * @return array
     */
    function weekly_trends( $base_app = 0 )
    {
        $params = array();
        $params['base_app'] = $base_app;

        return $this->oauth->get( 'trends/weekly', $params );
    }

    /**
     * 关注某话题
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/follow trends/follow}
     *
     * @access public
     * @param string $trend_name 要关注的话题关键词。
     * @return array
     */
    function follow_trends( $trend_name )
    {
        $params = array();
        $params['trend_name'] = $trend_name;
        return $this->oauth->post( 'trends/follow', $params );
    }

    /**
     * 取消对某话题的关注
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/trends/destroy trends/destroy}
     *
     * @access public
     * @param int $tid 要取消关注的话题ID。
     * @return array
     */
    function unfollow_trends( $tid )
    {
        $this->id_format($tid);

        $params = array();
        $params['trend_id'] = $tid;

        return $this->oauth->post( 'trends/destroy', $params );
    }

    /**
     * 返回指定用户的标签列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags tags}
     *
     * @param int $uid 查询用户的ID。默认为当前用户。可选。
     * @param int $page 指定返回结果的页码。可选。
     * @param int $count 单页大小。缺省值20，最大值200。可选。
     * @return array
     */
    function get_tags( $uid = NULL, $page = 1, $count = 20 )
    {
        $params = array();
        if ( $uid ) {
            $params['uid'] = $uid;
        } else {
            $user_info = $this->get_uid();
            $params['uid'] = $user_info['uid'];
        }
        $this->id_format( $params['uid'] );
        $params['page'] = $page;
        $params['count'] = $count;
        return $this->oauth->get( 'tags', $params );
    }

    /**
     * 批量获取用户的标签列表
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags/tags_batch tags/tags_batch}
     *
     * @param  string $uids 要获取标签的用户ID。最大20，逗号分隔。必填
     * @return array
     */
    function get_tags_batch( $uids )
    {
        $params = array();
        if (is_array( $uids ) && !empty( $uids )) {
            foreach ($uids as $k => $v) {
                $this->id_format( $uids[$k] );
            }
            $params['uids'] = join(',', $uids);
        } else {
            $params['uids'] = $uids;
        }
        return $this->oauth->get( 'tags/tags_batch', $params );
    }

    /**
     * 返回用户感兴趣的标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags/suggestions tags/suggestions}
     *
     * @access public
     * @param int $count 单页大小。缺省值10，最大值10。可选。
     * @return array
     */
    function get_suggest_tags( $count = 10)
    {
        $params = array();
        $params['count'] = intval($count);
        return $this->oauth->get( 'tags/suggestions', $params );
    }

    /**
     * 为当前登录用户添加新的用户标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags/create tags/create}
     *
     * @access public
     * @param mixed $tags 要创建的一组标签，每个标签的长度不可超过7个汉字，14个半角字符。多个标签之间用逗号间隔，或由多个标签构成的数组。如："abc,drf,efgh,tt"或array("abc", "drf", "efgh", "tt")
     * @return array
     */
    function add_tags( $tags )
    {
        $params = array();
        if (is_array($tags) && !empty($tags)) {
            $params['tags'] = join(',', $tags);
        } else {
            $params['tags'] = $tags;
        }
        return $this->oauth->post( 'tags/create', $params);
    }

    /**
     * 删除标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags/destroy tags/destroy}
     *
     * @access public
     * @param int $tag_id 标签ID，必填参数
     * @return array
     */
    function delete_tag( $tag_id )
    {
        $params = array();
        $params['tag_id'] = $tag_id;
        return $this->oauth->post( 'tags/destroy', $params );
    }

    /**
     * 批量删除标签
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/tags/destroy_batch tags/destroy_batch}
     *
     * @access public
     * @param mixed $ids 必选参数，要删除的tag id，多个id用半角逗号分割，最多10个。或由多个tag id构成的数组。如：“553,554,555"或array(553, 554, 555)
     * @return array
     */
    function delete_tags( $ids )
    {
        $params = array();
        if (is_array($ids) && !empty($ids)) {
            $params['ids'] = join(',', $ids);
        } else {
            $params['ids'] = $ids;
        }
        return $this->oauth->post( 'tags/destroy_batch', $params );
    }


    /**
     * 验证昵称是否可用，并给予建议昵称
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/register/verify_nickname register/verify_nickname}
     *
     * @param string $nickname 需要验证的昵称。4-20个字符，支持中英文、数字、"_"或减号。必填
     * @return array
     */
    function verify_nickname( $nickname )
    {
        $params = array();
        $params['nickname'] = $nickname;
        return $this->oauth->get( 'register/verify_nickname', $params );
    }



    /**
     * 搜索用户时的联想搜索建议
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/suggestions/users search/suggestions/users}
     *
     * @param string $q 搜索的关键字，必须做URLencoding。必填,中间最好不要出现空格
     * @param int $count 返回的记录条数，默认为10。
     * @return array
     */
    function search_users( $q,  $count = 10 )
    {
        $params = array();
        $params['q'] = $q;
        $params['count'] = $count;
        return $this->oauth->get( 'search/suggestions/users',  $params );
    }


    /**
     * 搜索微博时的联想搜索建议
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/suggestions/statuses search/suggestions/statuses}
     *
     * @param string $q 搜索的关键字，必须做URLencoding。必填
     * @param int $count 返回的记录条数，默认为10。
     * @return array
     */
    function search_statuses( $q,  $count = 10)
    {
        $params = array();
        $params['q'] = $q;
        $params['count'] = $count;
        return $this->oauth->get( 'search/suggestions/statuses', $params );
    }


    /**
     * 搜索学校时的联想搜索建议
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/suggestions/schools search/suggestions/schools}
     *
     * @param string $q 搜索的关键字，必须做URLencoding。必填
     * @param int $count 返回的记录条数，默认为10。
     * @param int type 学校类型，0：全部、1：大学、2：高中、3：中专技校、4：初中、5：小学，默认为0。选填
     * @return array
     */
    function search_schools( $q,  $count = 10,  $type = 1)
    {
        $params = array();
        $params['q'] = $q;
        $params['count'] = $count;
        $params['type'] = $type;
        return $this->oauth->get( 'search/suggestions/schools', $params );
    }

    /**
     * 搜索公司时的联想搜索建议
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/suggestions/companies search/suggestions/companies}
     *
     * @param string $q 搜索的关键字，必须做URLencoding。必填
     * @param int $count 返回的记录条数，默认为10。
     * @return array
     */
    function search_companies( $q, $count = 10)
    {
        $params = array();
        $params['q'] = $q;
        $params['count'] = $count;
        return $this->oauth->get( 'search/suggestions/companies', $params );
    }


    /**
     * ＠用户时的联想建议
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/suggestions/at_users search/suggestions/at_users}
     *
     * @param string $q 搜索的关键字，必须做URLencoding。必填
     * @param int $count 返回的记录条数，默认为10。
     * @param int $type 联想类型，0：关注、1：粉丝。必填
     * @param int $range 联想范围，0：只联想关注人、1：只联想关注人的备注、2：全部，默认为2。选填
     * @return array
     */
    function search_at_users( $q, $count = 10, $type=0, $range = 2)
    {
        $params = array();
        $params['q'] = $q;
        $params['count'] = $count;
        $params['type'] = $type;
        $params['range'] = $range;
        return $this->oauth->get( 'search/suggestions/at_users', $params );
    }





    /**
     * 搜索与指定的一个或多个条件相匹配的微博
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/statuses search/statuses}
     *
     * @param array $query 搜索选项。格式：array('key0'=>'value0', 'key1'=>'value1', ....)。支持的key:
     *  - q				string	搜索的关键字，必须进行URLencode。
     *  - filter_ori	int		过滤器，是否为原创，0：全部、1：原创、2：转发，默认为0。
     *  - filter_pic	int		过滤器。是否包含图片，0：全部、1：包含、2：不包含，默认为0。
     *  - fuid			int		搜索的微博作者的用户UID。
     *  - province		int		搜索的省份范围，省份ID。
     *  - city			int		搜索的城市范围，城市ID。
     *  - starttime		int		开始时间，Unix时间戳。
     *  - endtime		int		结束时间，Unix时间戳。
     *  - count			int		单页返回的记录条数，默认为10。
     *  - page			int		返回结果的页码，默认为1。
     *  - needcount		boolean	返回结果中是否包含返回记录数，true：返回、false：不返回，默认为false。
     *  - base_app		int		是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * needcount参数不同，会导致相应的返回值结构不同
     * 以上参数全部选填
     * @return array
     */
    function search_statuses_high( $query )
    {
        return $this->oauth->get( 'search/statuses', $query );
    }



    /**
     * 通过关键词搜索用户
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/search/users search/users}
     *
     * @param array $query 搜索选项。格式：array('key0'=>'value0', 'key1'=>'value1', ....)。支持的key:
     *  - q			string	搜索的关键字，必须进行URLencode。
     *  - snick		int		搜索范围是否包含昵称，0：不包含、1：包含。
     *  - sdomain	int		搜索范围是否包含个性域名，0：不包含、1：包含。
     *  - sintro	int		搜索范围是否包含简介，0：不包含、1：包含。
     *  - stag		int		搜索范围是否包含标签，0：不包含、1：包含。
     *  - province	int		搜索的省份范围，省份ID。
     *  - city		int		搜索的城市范围，城市ID。
     *  - gender	string	搜索的性别范围，m：男、f：女。
     *  - comorsch	string	搜索的公司学校名称。
     *  - sort		int		排序方式，1：按更新时间、2：按粉丝数，默认为1。
     *  - count		int		单页返回的记录条数，默认为10。
     *  - page		int		返回结果的页码，默认为1。
     *  - base_app	int		是否只获取当前应用的数据。0为否（所有数据），1为是（仅当前应用），默认为0。
     * 以上所有参数全部选填
     * @return array
     */
    function search_users_keywords( $query )
    {
        return $this->oauth->get( 'search/users', $query );
    }



    /**
     * 获取系统推荐用户
     *
     * 返回系统推荐的用户列表。
     * <br />对应API：{@link http://open.weibo.com/wiki/2/suggestions/users/hot suggestions/users/hot}
     *
     * @access public
     * @param string $category 分类，可选参数，返回某一类别的推荐用户，默认为 default。如果不在以下分类中，返回空列表：<br />
     *  - default:人气关注
     *  - ent:影视名星
     *  - hk_famous:港台名人
     *  - model:模特
     *  - cooking:美食&健康
     *  - sport:体育名人
     *  - finance:商界名人
     *  - tech:IT互联网
     *  - singer:歌手
     *  - writer：作家
     *  - moderator:主持人
     *  - medium:媒体总编
     *  - stockplayer:炒股高手
     * @return array
     */
    function hot_users( $category = "default" )
    {
        $params = array();
        $params['category'] = $category;

        return $this->oauth->get( 'suggestions/users/hot', $params );
    }

    /**
     * 获取用户可能感兴趣的人
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/suggestions/users/may_interested suggestions/users/may_interested}
     *
     * @access public
     * @param int $page 返回结果的页码，默认为1。
     * @param int $count 单页返回的记录条数，默认为10。
     * @return array
     * @ignore
     */
    function suggestions_may_interested( $page = 1, $count = 10 )
    {
        $params = array();
        $params['page'] = $page;
        $params['count'] = $count;
        return $this->oauth->get( 'suggestions/users/may_interested', $params);
    }

    /**
     * 根据一段微博正文推荐相关微博用户。
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/suggestions/users/by_status suggestions/users/by_status}
     *
     * @access public
     * @param string $content 微博正文内容。
     * @param int $num 返回结果数目，默认为10。
     * @return array
     */
    function suggestions_users_by_status( $content, $num = 10 )
    {
        $params = array();
        $params['content'] = $content;
        $params['num'] = $num;
        return $this->oauth->get( 'suggestions/users/by_status', $params);
    }

    /**
     * 热门收藏
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/suggestions/favorites/hot suggestions/favorites/hot}
     *
     * @param int $count 每页返回结果数，默认20。选填
     * @param int $page 返回页码，默认1。选填
     * @return array
     */
    function hot_favorites( $page = 1, $count = 20 )
    {
        $params = array();
        $params['count'] = $count;
        $params['page'] = $page;
        return $this->oauth->get( 'suggestions/favorites/hot', $params);
    }

    /**
     * 把某人标识为不感兴趣的人
     *
     * 对应API：{@link http://open.weibo.com/wiki/2/suggestions/users/not_interested suggestions/users/not_interested}
     *
     * @param int $uid 不感兴趣的用户的UID。
     * @return array
     */
    function put_users_not_interested( $uid )
    {
        $params = array();
        $params['uid'] = $uid;
        return $this->oauth->post( 'suggestions/users/not_interested', $params);
    }



    // =========================================

    /**
     * @ignore
     */
    protected function request_with_pager( $url, $page = false, $count = false, $params = array() )
    {
        if( $page ) $params['page'] = $page;
        if( $count ) $params['count'] = $count;

        return $this->oauth->get($url, $params );
    }

    /**
     * @ignore
     */
    protected function request_with_uid( $url, $uid_or_name, $page = false, $count = false, $cursor = false, $post = false, $params = array())
    {
        if( $page ) $params['page'] = $page;
        if( $count ) $params['count'] = $count;
        if( $cursor )$params['cursor'] =  $cursor;

        if( $post ) $method = 'post';
        else $method = 'get';

        if ( $uid_or_name !== NULL ) {
            $this->id_format($uid_or_name);
            $params['id'] = $uid_or_name;
        }

        return $this->oauth->$method($url, $params );

    }

    /**
     * @ignore
     */
    protected function id_format(&$id) {
        if ( is_float($id) ) {
            $id = number_format($id, 0, '', '');
        } elseif ( is_string($id) ) {
            $id = trim($id);
        }
    }

}

function process_weibo_authorize($code){
    $login_location_uri = wsocial_session_get('xh_social_callback');
    if(empty($login_location_uri)){
        $login_location_uri = isset($_GET['callback'])?urldecode($_GET['callback']):'';
    }
    
    if(empty($login_location_uri)){
        echo 'Ops!Something is wrong.';
        exit;
    }
    
    $params=array();
    $redirect_uri = get_uri_without_params(get_location_uri(),$params);
    if(isset($params['code'])) unset($params['code']);
    if(isset($params['state'])) unset($params['state']);
    $redirect_uri.="?".http_build_query($params);
    
    try {
        //获取accesstoken
        $appid =XH_WEIBO_APPID;
        $appsecret = XH_WEIBO_APPSECRET;
        
        $api = new SaeTOAuthV2($appid,$appsecret);
        $token = $api->getAccessToken( 'code', array(
            'code'=>$code,
            'redirect_uri'=>$redirect_uri
        )) ;
        
        if(!$token||isset($token['error'])){
            throw new Exception(isset($token['error'])?$token['error']:'Inner system error',isset($token['error_code'])?$token['error_code']:0);
        }
        
        $uapi = new SaeTClientV2( $appid , $appsecret ,$token['access_token']);
        $uid_get = $uapi->get_uid();
        if(!$uid_get||isset($uid_get['error'])){
            throw new Exception(isset($uid_get['error'])?$uid_get['error']:'Inner system error',isset($uid_get['error_code'])?$uid_get['error_code']:0);
        }
        
        $uid = $uid_get['uid'];
        $obj = $uapi->show_user_by_id( $uid);
        if(!$obj||isset($obj['error'])){
            throw new Exception(isset($obj['error'])?$obj['error']:'Inner system error',isset($obj['error_code'])?$obj['error_code']:0);
        }
        
        $userdata = array(
            'uid'=>$uid,
            'nickname'=>remove_emoji($obj['name']),
            'location'=>$obj['location'],
            'description'=>remove_emoji($obj['description']),
            'city'=>$obj['city'],
            'province'=>$obj['province'],
            'description'=>$obj['description'],
            'img'=>str_replace('http://', '//', isset($obj['avatar_large'])&&!empty($obj['avatar_large'])?$obj['avatar_large']:(isset($obj['profile_image_url'])?$obj['profile_image_url']:'')),
            'gender'=>$obj['gender'],
            'profile_url'=>$obj['profile_url']
        );
        
        xh_weibo_user_sync_to_remote($userdata,$login_location_uri);
        exit;
    } catch (Exception $e) {
        $err_times = isset($_GET['err_times'])?intval($_GET['err_times']):3;
         
        if($err_times>0){
            $err_times--;
            $uri =get_weibo_authorize_uri($err_times);
            header("Location: $uri", true, 302);
            exit;
        }
        
        xh_weibo_authorize_failed($e);
        exit;
    }

    //最终登录失败
    header("Location: $login_location_uri", true, 302);
    exit;
}

if(isset($_GET['code'])){
    process_weibo_authorize($_GET['code']);
}

if(isset($_GET['callback'])){
    $hash = isset($_GET['hash'])?$_GET['hash']:'';
    $login_location_uri = isset($_GET['callback'])?urldecode($_GET['callback']):'';
    $request =array(
        'callback'=>$login_location_uri,
    );
    
    if($hash!= generate_hash($request,XH_WEIBO_APPSECRET)){
        echo 'Invalid sign!';
        exit;
    }
    
    wsocial_session_set('xh_social_callback',$login_location_uri);
    
    $redirect_to = get_weibo_authorize_uri();
    header("Location: $redirect_to", true, 302);
    exit;
}

$callback = wsocial_session_get('xh_social_callback');
if(!empty($callback)){
    header("Location: {$callback}", true, 302);
    exit;
}
echo 'Ops!Something is wrong.';
exit;
?>