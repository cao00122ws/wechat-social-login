<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$request = XH_Social_Temp_Helper::get('atts','templete');
$shop = $request['shop'];
$shop_domain = $shop->shop;
$shop_url = 'https://'. $shop_domain;
global $wp_scripts;
if ( ! $guessurl = site_url() ){
    $guessurl = wp_guess_url();
}

$shop_config = $shop?maybe_unserialize($shop->config):null;
?>
<!doctype html>
<html>
<head>
	<title><?php echo esc_html($request['title'])?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />   
    <script type='text/javascript'>
        // If the current window is the 'parent', change the URL by setting location.href
        if (window.top == window.self) {
        	window.top.location.href = "<?php echo esc_url_raw("{$shop_domain}/admin/apps/wechat-social-login")?>";
        }
	</script>
	
	<script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
	<link rel="stylesheet" href="<?php echo esc_attr($request['domain_url'].'/assets/bootstrap/css/bootstrap.min.css')?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo esc_attr($request['domain_url'].'/assets/fontawesome/css/font-awesome.min.css')?>" type="text/css"/>
	<script src="<?php echo esc_attr($request['domain_url'].'/assets/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
	<script type="text/javascript">
        ShopifyApp.init({
            apiKey: '<?php echo esc_attr($request['appkey'])?>',
            shopOrigin: '<?php echo esc_url_raw($shop_url)?>'
        });
  </script>

  <script type="text/javascript">
        ShopifyApp.ready(function(){
            ShopifyApp.Bar.initialize({
                  icon: '<?php echo esc_url_raw($request['logo'])?>',
                  title: 'Configuration'
            });

            ShopifyApp.Bar.loadingOff();

            (function($){
				$('#btn-form-save,#btn-form-save2').click(function(){
					var $this = $(this);
					if($this.attr('data-loading')){return;}
					$this.attr('data-loading',1);
					ShopifyApp.Bar.loadingOn();

					$.ajax({
			            type: "POST",
			            url: '<?php echo XH_Social::instance()->ajax_url(array('action'=>"wsocial_{$request['id']}",'tab'=>'config','shop'=>$shop->shop),true);?>',
			            timeout:6000,
			            cache:false,
			            data:{
			            	multipass_login_secret:$.trim($('#multipass_login_secret').val()),
			            	
					        wechat_op_appid:$.trim($('#wechat_op_appid').val()),
					        wechat_op_appsecret:$.trim($('#wechat_op_appsecret').val()),

					        qq_appid:$.trim($('#qq_appid').val()),
					        qq_appsecret:$.trim($('#qq_appsecret').val()),

					        weibo_appid:$.trim($('#weibo_appid').val()),
					        weibo_appsecret:$.trim($('#weibo_appsecret').val())
				        },
			            dataType:'json',
			            success:function(data){
			            	$this.removeAttr('data-loading');
			            	ShopifyApp.Bar.loadingOff();
			                if (data.errcode!=0) {
			                	ShopifyApp.flashError( data.errmsg);
			                    return;
			                }
			                
			                ShopifyApp.flashNotice("Configuration was saved successfully.");
			            },
			            error:function(){
			            	$this.removeAttr('data-loading');
			            	ShopifyApp.flashError('<?php echo XH_Social_Error::err_code(500)->errmsg;?>');
			            	ShopifyApp.Bar.loadingOff();
			            }
			        });
				});
				$('#btn-get-test-account').click(function(){
					ShopifyApp.Modal.confirm("All social accounts would be reset,continue?", function(result){
    					  if(!result){
    					    return;
    					  }
					    <?php if(class_exists('XH_Social_Settings_WP_Open_Default')){ ?>
					        $('#wechat_op_appid').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_ID_WECHAT_OP?>');
					        $('#wechat_op_appsecret').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_SECRET_WECHAT_OP?>');

					        $('#qq_appid').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_ID_QQ?>');
					        $('#qq_appsecret').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_SECRET_QQ?>');

					        $('#weibo_appid').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_ID_WEIBO?>');
					        $('#weibo_appsecret').val('<?php echo XH_Social_Settings_WP_Open_Default::APP_SECRET_WEIBO?>');

					        $('#btn-form-save').click();
					    <?php }?>
					});
				});
            })(jQuery);
        });
  </script>
  <script>
    jQuery(document).ready(
            function ($) {
                $('.showTooltip').tooltip({ html: true });
                $('.showPopover').popover({ trigger: 'hover', html: true });
            }
        );
  </script>
</head>
<body>
	<div class="container">
       <div class="row">
       
       <!-- <div style="border:1px solid #eee;padding:25px;padding-top:0;margin-top:80px;" >
	 	<h3 class="page-header">Step 1:Multipass login secret</h3>
	 	<p>Log in to your shop admin and go to the Settings &gt; Checkout page. Scroll down to the <strong>Customer Accounts</strong> section and ensure that you have either <strong>Accounts are optional</strong> selected or <strong>Accounts are required</strong>.</p>
	 	<p><img src='https://www.weixinsocial.com/shopify/shopify-help1.jpg' style="width: 730px;"></p>
	 	 <div class="form-horizontal">
        	<div class="form-group">
                <label class="col-md-2" for="multipass_login_secret">Multipass login secret(optional):</label>
                <div class="col-md-7">
                   	<input type="text" class="form-control" placeholder="optional" id="multipass_login_secret" value="<?php echo isset($shop_config['multipass_login_secret'])?$shop_config['multipass_login_secret']:null?>" />
                </div>
            </div>
            <button type="button" class="btn btn-primary" id="btn-form-save2">Save Changes</button>
        </div>
	 	</div> --> 
	 	
        <div style="border:1px solid #eee;padding:25px;margin-top:50px;padding-top:0" >
        <h3 class="page-header">Step 1:Configure the app</h3>
        <ul class="nav nav-tabs">
<!--               <li><a href="#wechat-mp" data-toggle="tab">Wechat(In wechat app)</a></li> -->
              <li class="active"><a href="#wechat-op" data-toggle="tab">Wechat(PC)</a></li>
              <li><a href="#qq" data-toggle="tab">QQ</a></li>
              <li><a href="#weibo" data-toggle="tab">Weibo</a></li>
        </ul>
        
        <!-- Tab panes -->
        <div class="tab-content">
          	<!-- <div class="tab-pane" id="wechat-mp">
          		<h5>微信公众平台</h5>
                <div class="form-horizontal">
                	<div class="form-group">
                        <label class="col-md-2" for="wechat_mp_enabled">Enable</label>
                        <div class="col-md-7">
                           	<input type="checkbox" id="wechat_mp_enabled" value="yes" <?php echo isset($shop_config['wechat_mp_enabled'])&&$shop_config['wechat_mp_enabled']=='yes'?'checked':null?> />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-2" for="wechat_mp_appid">App ID <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="wechat_mp_appid" value="<?php echo isset($shop_config['wechat_mp_appid'])?esc_attr($shop_config['wechat_mp_appid']):null?>" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2" for="wechat_mp_appsecret">App Secret <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="wechat_mp_appsecret" value="<?php echo isset($shop_config['wechat_mp_appsecret'])?esc_attr($shop_config['wechat_mp_appsecret']):null?>" />
                        </div>
                    </div>
                </div>
			</div> -->
			<div class="tab-pane  active" id="wechat-op">
				<h5>WeChat open platform <a href="https://open.weixin.qq.com" target="_blank">click here</a> to get new account</h5>
                <div class="form-horizontal">
                    <div class="form-group">
                        <label class="col-md-2" for="wechat_op_appid">App ID <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="wechat_op_appid" value="<?php echo isset($shop_config['wechat_op_appid'])?esc_attr($shop_config['wechat_op_appid']):null?>" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2" for="wechat_op_appsecret">App Secret <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="wechat_op_appsecret" value="<?php echo isset($shop_config['wechat_op_appsecret'])?esc_attr($shop_config['wechat_op_appsecret']):null?>" />
                        </div>
                    </div>
                </div>
			</div>
			
			<div class="tab-pane" id="qq">
				<h5>QQ connect <a href="https://connect.qq.com/" target="_blank">click here</a> to get new account</h5>
                <div class="form-horizontal">
                    <div class="form-group">
                        <label class="col-md-2" for="qq_appid">App ID <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="qq_appid" value="<?php echo isset($shop_config['qq_appid'])?esc_attr($shop_config['qq_appid']):null?>" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2" for="qq_appsecret">App Key <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="qq_appsecret" value="<?php echo isset($shop_config['qq_appsecret'])?esc_attr($shop_config['qq_appsecret']):null?>" />
                        </div>
                    </div>
                </div>
			</div>
			
			<div class="tab-pane" id="weibo">
				<h5>Weibo Open platform <a href="http://open.weibo.com/" target="_blank">click here</a> to get new account</h5>
                <div class="form-horizontal">
                    <div class="form-group">
                        <label class="col-md-2" for="weibo_appid">App ID <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="weibo_appid" value="<?php echo isset($shop_config['weibo_appid'])?esc_attr($shop_config['weibo_appid']):null?>" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-2" for="weibo_appsecret">App Secret <span class="required">*</span></label>
                        <div class="col-md-7">
                            <input type="text" class="form-control" id="weibo_appsecret" value="<?php echo isset($shop_config['weibo_appsecret'])?esc_attr($shop_config['weibo_appsecret']):null?>" />
                        </div>
                    </div>
                </div>
			</div>
			
        </div>
        
         <button type="button" class="btn btn-primary" id="btn-form-save">Save Changes</button>
         <p><?php if(class_exists('XH_Social_Settings_WP_Open_Default')){?>
            <span>If your have not social accounts? <a href="javascript:void(0)" id="btn-get-test-account">click here</a> to  get agent accounts,agent login account can be long-term use</span>
         <?php }?></p>
         </div>

         <div style="border:1px solid #eee;padding:25px;margin-top:50px;padding-top:0">
             
        
        <div class="new-paragraph"></div>
 <h3 class="page-header" >Step 2:Integrate with your Shopify store</h3>

        <h4>Add wechat social login button on the login page</h4>
        <ol>
            <li>Click <b>Online Store</b> from the side panel then select <b>Themes</b>.
            </li>
            <li>Click the <b>Actions</b> button. 
            </li>
            <li>Click the "Edit code" icon next to the theme name on the left side of the page, then select <b>Edit code</b>
            <br>
            <img src='https://www.weixinsocial.com/shopify/shopify-help2.jpg' alt="wechat login for shoipfy" style="width: 730px;">
                
            </li>
            <li>Modify the template or add a new template if this doesn't exist.customers/login.liquid <br>
            <img src="https://www.weixinsocial.com/shopify/shopify-help3.jpg" alt="wechat login for shoipfy" style="width: 730px;">
            </li>

            <li>Copy and paste the snippet below into the template. Adjust the template until you get satisfactory
                results. <br> 
                <textarea readonly="readonly" class="html-code-snippet" style="min-width:730px;min-height:180px;">                   
                 <?php echo esc_textarea('<a href="#wechat-op" class="wsocial-bar" style=""><img src="https://www.weixinsocial.com/wp-content/plugins/wechat-social-login/assets/image/weixin-icon.png" title="wechat"/></a>
                                          <a href="#qq" class="wsocial-bar" style=""><img src="https://www.weixinsocial.com/wp-content/plugins/wechat-social-login/assets/image/qq-icon.png" title="QQ"/></a>
                                          <a href="#weibo" class="wsocial-bar" style=""><img src="https://www.weixinsocial.com/wp-content/plugins/wechat-social-login/assets/image/weibo-icon.png" title="weibo"/></a>')?>
                </textarea> 
                <br> <b>TIP</b>: We recommend pasting the snippet directly underneath this line of code:
                <br>
                &lt;input type="submit" class="btn" value="{{'customer.login.sign_in' | t }}"&gt;
                <br>
                For more guidance, please send email to flora@xunhuweb.com,mobile:+8615723560093
            </li>

            <li>Click on <b>Save</b> at the top when finished.
            </li>
            
            <li>Click <b>Preview</b> in the upper, right corner to see your changes and test out the Login with Wechat button.
            </li>
        </ol>
        
        <h4>Add an Wechat login button on your registration page</h4>
        
        <ol>
            <li>Modify the customers/register.liquid template or add a new template if this doesn't exist.
            </li>
            <li>Paste the same snippet from step 3.5 (above) into the template. Adjust the template until you get
                satisfactory results.<br> <b>TIP</b>: We recommend pasting the snippet directly underneath this line of code:<br><br>
                &lt;h1 class="text-center"&gt; {{ 'customer.register.title' | t }}&lt;/h1&gt;<br><br>
                
                You can also use HTML to center the button, and add clarifying test. 
                For more guidance, please send email to flora@xunhuweb.com | mobile:+8615723560093
            </li>
            <li>Click on <b>Save</b> at the top when finished.
            </li>
            <li>Click <b>Preview</b> in the upper, right corner to see your changes and test out the Login with Wechat button.
            </li>
        </ol>
       
              

        <h3 class="page-header">Support</h3>
        <p>
            More FAQs and information on the Login with Wechat app for Shopify,Please let us know if you have any questions or if we can help in any way.<br> Our email: <a target="_top" href="mailto:flora@xunhuweb.com">flora@xunhuweb.com</a> | mobile:+8615723560093
            
        
        </p>
        </div>
    </div>
    </div>
</body>
</html>