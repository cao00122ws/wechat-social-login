<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$request = XH_Social_Temp_Helper::get('atts','templete');
$shop = $request['shop'];
$shop_domain = $shop->shop;
$shop_url = 'https://'. $shop_domain;

global $wp_scripts;
if ( ! $guessurl = site_url() ){
    $guessurl = wp_guess_url();
}
?>
<!doctype html>
<html>
<head>
	<title><?php echo esc_html($request['title'])?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />   
  
	<script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
	<link rel="stylesheet" href="<?php echo esc_attr($request['domain_url'].'/assets/bootstrap/css/bootstrap.min.css')?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo esc_attr($request['domain_url'].'/assets/fontawesome/css/font-awesome.min.css')?>" type="text/css"/>
	<script src="<?php echo esc_attr($request['domain_url'].'/assets/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="https://cdn.shopify.com/s/assets/external/app.js"></script>

</head>
<body><div class="container">
   <div class="row">
     <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12">
       
       <h3 class="page-header">You canceled the order</h3>

        <p>You have just canceled the Shopify Wechat social login payment of $<?php echo XH_Social_Add_On_Social_Shopify::instance()->get_option('amount')?> / month, you can <a  target="_blank" href="https://www.weixinsocial.com/shopify/install?shop=<?php echo $shop_domain?>" target="_blank">click here</a> to buy it again</p>
        <p><a target="_blank" href="https://apps.shopify.com/wechat-social-login" class="btn btn-success">Back to Shopify</a></p>
     </div>
 <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4">
   <address>
  <strong>Xunhu,Ltd.</strong><br>
  Olympic Sports Road on the 1st 1-21-16, High – tech Zone<br>
  Chongqing, China<br>
  <abbr title="Phone">P:</abbr> (86) 81370275
</address>

<address>
<strong>Website:</strong><br>
  <a target="_blank" href="https://www.weixinsocial.com">www.weixinsocial.com</a><br>
  <strong>Email:</strong><br>
  <a target="_top" href="mailto:flora@xunhuweb.com">flora@xunhuweb.com</a>
</address>
 </div>
 <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4">
   <p>Don't forget! Our friendly and helpful staff are happy to answer any
of your questions.Please quote your order number to help us answer them really fast!</p>
 </div>
 <div class="col-lg-4 col-xs-12 col-sm-12 col-md-4">
   
<p>Chongqing Xunhu Network Co., Ltd begin In 2014,We specialize in App, WeChat custom development, and provide professional payment interface, WordPress, WooCommerce, Easy Digital Downloads, Magento , EcShop, OpenCart, zencart and other WeChat, Alipay payment interface development integration, themes and plugins custom services.</p>
 </div>
   </div>

 </div> 
 </body>
</html>