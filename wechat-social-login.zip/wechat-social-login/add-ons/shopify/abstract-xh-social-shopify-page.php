<?php

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
require_once 'abstract-xh-social-shopify-api.php';
abstract class XH_Social_Shopify_Page extends XH_Social_Shopify_Api{
	 protected function shopify_js(){
		 $shop = isset($_GET['shop'])?$_GET['shop']:null;
		 if(empty($shop)){
			 return;
		 }
		 header('Content-type: text/javascript');

		 ?>
		 /**
		 * handle social login portal
		 * @param api_shopify
		 * @param api_theme
		 * @param api_analytics
		 */
		(function(api_shopify ){
			"use strict";

			if(!api_shopify){
				return;
			}
			var s = location.search;
			//get login bars
			var login_bars = document.getElementsByClassName('wsocial-bar');
			if(!login_bars||login_bars.length==0){
				return;
			}

			for(var index=0;index<login_bars.length;index++){
				var login_bar = login_bars[index];

				login_bar.onclick=function(event){
					if(typeof this.href=='undefined'){
						return false;
					}

					var indexof_ = this.href.lastIndexOf('#');
					if(indexof_<0){return false;}

					var social = this.href.substr(indexof_+1);
					event.preventDefault();

					var reg = new RegExp("(^|&)checkout_url=([^&]*)(&|$)");
					var match = window.location.search.substr(1).match(reg);
					var redirect_to =match? decodeURIComponent(match[2]):'';
					//get location
					location.href='https://www.weixinsocial.com/shopify/redirect?scope='+social+'&shop='+encodeURIComponent('<?php echo esc_js($shop)?>')+'&location='+encodeURIComponent(location.href.toString())+'&redirect_to='+encodeURIComponent(redirect_to);
					return false;
				}
			}
		})(Shopify);
		 <?php
		 exit;
	 }
    protected function shopify_install(){
        $appkey =$this->get_option('appid');
        $appsecret =$this->get_option('appsecret');

        if(isset($_REQUEST['hmac'])&&isset($_REQUEST['shop'])){
            if($this->generate_hmac_sign($_REQUEST)!=$_REQUEST['hmac']){
                XH_Social::instance()->WP->wp_die('HMAC validation failed!');
            }

            global $wpdb;
            $shop = $wpdb->get_row($wpdb->prepare(
                "select *
                 from {$wpdb->prefix}xh_social_shopify
                 where shop=%s
                limit 1;", $_REQUEST['shop']));
            if($shop){
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "X-Shopify-Access-Token:{$shop->access_token}"
                ));
                try {
                    $response = XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/recurring_application_charges/{$shop->charge_id}.json",false,$ch);
                    $charge_info = $response?json_decode($response,true):array();
                    $status = isset($charge_info['recurring_application_charge']['status'])?$charge_info['recurring_application_charge']['status']:'';
                    XH_Social_Temp_Helper::set('atts', array(
                        'id'=>$this->id,
                        'shop'=>$shop,
                        'appkey'=>$appkey,
                        'appsecret'=>$appsecret,
                        'title'=>$this->get_option('title'),
                        'logo'=>$this->get_option('logo'),
                        'domain_url'=>$this->url
                    ),'templete');
                    if($status=='active'){
                        require XH_Social::instance()->WP->get_template($this->dir, 'shopify/configuration.php');
                        exit;
                    }else{
                        require XH_Social::instance()->WP->get_template($this->dir, 'shopify/payment-canceled.php');
                        exit;
                    }
                } catch (Exception $e) {
                    if(!in_array($e->getCode(),array(401,404))){
                        XH_Social::instance()->WP->wp_die($e->getMessage());
                    }
                }

            }
        }

        $request = shortcode_atts(array(
            'shop'=>null
        ), stripslashes_deep($_REQUEST));

        if(empty($request['shop'])){
            XH_Social::instance()->WP->wp_die('Missing shop parameter. Please add ?shop=your-development-shop.myshopify.com to your request!');
        }

        $params = array(
            'client_id'=>$appkey,
            'scope'=>'read_customers,write_customers,read_script_tags,write_script_tags',
            'state'=> str_shuffle(time()),
            'redirect_uri'=>home_url('/shopify/install/callback')
        );

        wp_redirect("https://{$request['shop']}/admin/oauth/authorize?".http_build_query($params));
        exit;
    }

    protected function shopify_install_callback(){
        $appkey =$this->get_option('appid');
        $appsecret =$this->get_option('appsecret');

        $request =stripslashes_deep($_REQUEST);
        if(!isset($request['shop'])||!isset($request['hmac'])){
            XH_Social::instance()->WP->wp_die('Required parameters missing!');
        }

        if($this->generate_hmac_sign($request)!=$request['hmac']){
            XH_Social::instance()->WP->wp_die('HMAC validation failed!');
        }

        //过滤掉201状态的http
        add_filter('xunhu_http_post_errcode', function($false,$code,$ch){
            if($code==201){
                return false;
            }

            return $false;
        },10,3);
        $code = isset($_GET['code'])?$_GET['code']:null;
        //获取access_token
        try {
            $access_token = $this->get_access_token($request['shop'],$code);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            XH_Social::instance()->WP->wp_die(sprintf('Get access token failed,please <a href="%s">click here</a> try again!',home_url("shopify/install")."?shop={$request['shop']}"));
        }

        try {
            $shop = $this->get_shop_by_access_token($access_token,$request['shop']);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            XH_Social::instance()->WP->wp_die(sprintf('Get shop info failed,please <a href="%s">click here</a> try again!',home_url("shopify/install")."?shop={$request['shop']}"));
        }

        try {
           $this->refresh_script_tag($shop);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            XH_Social::instance()->WP->wp_die(sprintf('Refresh script tags failed,please <a href="%s">click here</a> try again!',home_url("shopify/install")."?shop={$request['shop']}"));
        }

        try {
            $this->refresh_recurring_application_charges($shop);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            XH_Social::instance()->WP->wp_die(sprintf('Refresh recurring application charges failed,please <a href="%s">click here</a> try again!',home_url("shopify/install")."?shop={$request['shop']}"));
        }

        XH_Social_Temp_Helper::set('atts', array(
            'id'=>$this->id,
            'shop'=>$shop,
            'appkey'=>$appkey,
            'appsecret'=>$appsecret,
            'title'=>$this->get_option('title'),
            'logo'=>$this->get_option('logo'),
            'domain_url'=>$this->url
        ),'templete');

        require XH_Social::instance()->WP->get_template($this->dir, 'shopify/configuration.php');
        exit;
    }

    protected function shopify_social_notify(){
        $request = stripslashes_deep($_GET);

        if($this->generate_proxies_sign($request)!=$request['signature']||!isset($request['scope'])){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(404)->errmsg);
            exit;
        }

        if(!isset($_SERVER['HTTP_X_FORWARDED_PROTO'])||!isset($_SERVER['HTTP_X_FORWARDED_HOST'])){
            XH_Social_Log::error('请求输入http异常：'.print_r($_SERVER,true));
            $request_domain = "https://{$request['shop']}";
        }else{
            $request_domain = "{$_SERVER['HTTP_X_FORWARDED_PROTO']}://{$_SERVER['HTTP_X_FORWARDED_HOST']}";
        }

        global $wpdb,$shop;
        $shop = $wpdb->get_row(
            $wpdb->prepare(
                "select *
                from {$wpdb->prefix}xh_social_shopify
                where shop=%s
                limit 1;", $request['shop']));
        if(!$shop){
            XH_Social::instance()->WP->wp_die('Sorry,We can not found your shop info,please reinstall current app and try again.');
            exit;
        }

//         $login_location_uri = isset($request['_redirect_to'])?base64_decode($request['_redirect_to']):null;
//         if(!$login_location_uri){
//             $login_location_uri = $request_domain;
//         }

        $api = XH_Social_Shopify_Social::get_scope($request['scope'], $shop);
        if(!$api){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(404)->errmsg);
            exit;
        }

        try {
            $api->notify($request_domain);
        } catch (Exception $e) {
            XH_Social::instance()->WP->wp_die($e->getMessage());
            exit;
        }
        exit;
    }

    protected function shopify_redirect(){
        global $wpdb;
        $request = shortcode_atts(array(
            'scope'=>null,
            'shop'=>null,
            'location'=>null,
            //'redirect_to'=>null
        ), stripslashes_deep($_REQUEST));

        $shop = $wpdb->get_row(
            $wpdb->prepare(
                "select *
                from {$wpdb->prefix}xh_social_shopify
                where shop=%s
                limit 1;", $request['shop']));
        if(!$shop){
            XH_Social_Log::error("shop not found,details:".print_r($_REQUEST,true));
            XH_Social::instance()->WP->wp_die('Sorry,We can not found your shop info,please reinstall current app and try again.')->to_json();
            exit;
        }

        if(!preg_match('/^https?:\/\//', strtolower($request['location']))){
            XH_Social::instance()->WP->wp_die("Invalid location: {$request['location']}");
            exit;
        }

        $domains = explode('/', $request['location']);
        $domain ="{$domains[0]}//{$domains[2]}";

//         if(empty($request['redirect_to'])){
//             $request['redirect_to'] = $domain;
//         }

		if($shop->domain!=$domain){
			$wpdb->query($wpdb->prepare("update {$wpdb->prefix}xh_social_shopify set domain=%s where shop=%s;",$domain,$request['shop']));
		}

        $api = XH_Social_Shopify_Social::get_scope($request['scope'], $shop);
        if(!$api){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(404)->errmsg);
            exit;
        }
		
        $api->redirect("{$domain}/community/social-notify?scope={$request['scope']}");
        exit;
    }

    protected function shopify_recurring_application_charges_confirm(){
        $charge_id = isset($_REQUEST['charge_id'])?$_REQUEST['charge_id']:null;

        $request = shortcode_atts(array(
            'shop'=>null,
            'hash'=>null,
            'notice_str'=>null
        ), stripslashes_deep($_REQUEST));

        if(!XH_Social::instance()->WP->ajax_validate($request, $request['hash'])){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(701)->errmsg);
            exit;
        }

        global $wpdb;
        $shop = $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify
            where shop=%s
            limit 1;", $request['shop']));

        if(!$shop){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(701)->errmsg);
            exit;
        }

        $_request = array(
            'shop'=>$request['shop'],
            'notice_str'=>str_shuffle(time())
        );

        $_request['hash'] = XH_Social_Helper::generate_hash($_request, XH_Social::instance()->get_hash_key());

        $canceled =home_url('/shopify/payment/canceled').'?'.http_build_query($_request);

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-Shopify-Access-Token:{$shop->access_token}"
            ));
            $response = XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/recurring_application_charges/{$charge_id}.json",false,$ch);
            $charge_info = $response?json_decode($response,true):array();
            $status = isset($charge_info['recurring_application_charge']['status'])?$charge_info['recurring_application_charge']['status']:'';
            if($status!='accepted'&&$status!='active'){
                wp_redirect($canceled);
                exit;
            }

            $return_url ="https://{$shop->shop}/admin/apps/wechat-social-login";
            if($charge_info['recurring_application_charge']['status']=='active'){
                wp_redirect($return_url);
                exit;
            }

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-Shopify-Access-Token:{$shop->access_token}"
            ));

            $response = XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/recurring_application_charges/{$charge_id}/activate.json",array(
                'recurring_application_charge'=>$charge_info
            ),false,$ch);

            $response = json_decode($response,true);
             $is_active = $response['recurring_application_charge']['status']=='active'?1:0;

            global $wpdb;
            $wpdb->update("{$wpdb->prefix}xh_social_shopify", array(
                'charge_id'=>$response['recurring_application_charge']['id'],
            ),array(
                'shop'=>$shop->shop
            ));

            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error);
            }

            if(!$is_active){
                wp_redirect($canceled);
                exit;
            }else{
                wp_redirect($return_url);
                exit;
            }

        } catch (Exception $e) {
            XH_Social_Log::error($e);
            XH_Social::instance()->WP->wp_die($e);
            exit;
        }
    }


    protected function shopify_confirm(){
        $request = shortcode_atts(array(
            'uid'=>null,
            'notice_str'=>null,
            'domain'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
        $domain = $request['domain'];
        if(!XH_Social::instance()->WP->ajax_validate($request, $request['hash'],false)){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(600));
            exit;
        }

        global $wpdb;
        $user = $wpdb->get_row($wpdb->prepare(
            "select *
            from {$wpdb->prefix}xh_social_shopify_user u
            where u.id=%s
            limit 1;", $request['uid']));

        if(!$user){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(600));
            exit;
        }

        $shop = $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify
            where shop=%s
            limit 1;", $user->shop));
        if(!$shop){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(600));
            exit;
        }

        $wp_error = new WP_Error();
        if(isset($_POST['register'])){

            $request = shortcode_atts(array(
                'email'=>null,
                'password'=>null,
                'repassword'=>null
            ), stripslashes_deep($_POST));

            try {
                if(empty($request['email'])){
                    throw new Exception('请输入登录邮箱！');
                }

                if(!is_email($request['email'])){
                    throw new Exception('请输入正确的登录邮箱！');
                }

                if(empty($request['password'])){
                    throw new Exception('请输入密码！');
                }

                if($request['password']!=$request['repassword']){
                    throw new Exception('两次密码输入不一致！');
                }

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "X-Shopify-Access-Token:{$shop->access_token}"
                ));
                //过滤掉201状态的http
                add_filter('xunhu_http_post_errcode', function($false,$code,$ch){
                    if($code==201){
                        return false;
                    }
                    return $false;
                },10,3);


                $email = urlencode($request['email']);
                $response =  XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/customers/search.json?query=email:{$email}&limit=1",false,$ch);
                $response = $response?json_decode($response,true):array();
                if(isset($response['customers'])&&count($response['customers'])>0){
                    throw new Exception('邮箱已被他人注册！');
                }

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    "X-Shopify-Access-Token:{$shop->access_token}"
                ));

                $user_info = json_decode($user->info,true);
                if(!$user_info||!is_array($user_info)){$user_info=array();}

                $user_info['email']=$request['email'];
                $user_info['password']=$request['password'];
                $user_info['password_confirmation']=$request['password'];
                $user_info['send_email_welcome']=true;
                $user_info['verified_email']=true;

                $response =  XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/customers.json",array(
                    'customer'=>$user_info
                ),false,$ch);

                $response = $response?json_decode($response,true):array();

                if(isset($response['customer']['id'])){
                    $customer_id=$response['customer']['id'];
                    $wpdb->update("{$wpdb->prefix}xh_social_shopify_user", array(
                        'email'=>$request['email'],
                        'password'=>$request['password'],
                        'shopify_user_id'=>$customer_id
                    ), array(
                        'id'=>$user->id
                    ));

                    if(!empty($wpdb->last_error)){
                        XH_Social_Log::error($wpdb->last_error);
                        $wp_error->add('validation', XH_Social_Error::err_code(500)->errmsg);
                        exit;
                    }

                    $request = array(
                        'uid'=>$user->id,
                        'domain'=>$domain,
                        'notice_str'=>str_shuffle(time())
                    );
                    $request['hash'] = XH_Social_Helper::generate_hash($request, XH_Social::instance()->get_hash_key());
                    wp_redirect(home_url('/shopify/login').'?'.http_build_query($request));
                    exit;
                }else if(isset($response['errors']['base'][0])){
                    throw new Exception($response['errors']['base'][0]);
                }else{
                    throw new Exception('系统错误，请重试！');
                }
            } catch (Exception $e) {
                $wp_error->add('validation', $e->getMessage());
            }
        }

        if(isset($_POST['login'])){

            $request = shortcode_atts(array(
                'email'=>null,
                'password'=>null
            ), stripslashes_deep($_POST));

            try {
                if(empty($request['email'])){
                    throw new Exception('请输入登录邮箱！');
                }

                if(!is_email($request['email'])){
                    throw new Exception('请输入正确的登录邮箱！');
                }

                if(empty($request['password'])){
                    throw new Exception('请输入密码！');
                }

                if($request['password']!=$request['repassword']){
                    throw new Exception('两次密码输入不一致！');
                }

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        "X-Shopify-Access-Token:{$shop->access_token}"
                    ));
                    //过滤掉201状态的http
                    add_filter('xunhu_http_post_errcode', function($false,$code,$ch){
                        if($code==201){
                            return false;
                        }
                        return $false;
                    },10,3);


                    $email = urlencode($request['email']);
                    $response =  XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/customers/search.json?query=email:{$email}&limit=1",false,$ch);
                    $response = $response?json_decode($response,true):array();
                    if(isset($response['customers'])&&count($response['customers'])>0){
                        throw new Exception('邮箱已被他人注册！');
                    }

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        "X-Shopify-Access-Token:{$shop->access_token}"
                    ));

                    $user_info = json_decode($user->info,true);
                    if(!$user_info||!is_array($user_info)){$user_info=array();}

                    $user_info['email']=$request['email'];
                    $user_info['password']=$request['password'];
                    $user_info['password_confirmation']=$request['password'];
                    $user_info['send_email_welcome']=true;
                    $user_info['verified_email']=true;

                    $response =  XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/customers.json",array(
                        'customer'=>$user_info
                    ),false,$ch);

                    $response = $response?json_decode($response,true):array();

                    if(isset($response['customer']['id'])){
                        $customer_id=$response['customer']['id'];
                        $wpdb->update("{$wpdb->prefix}xh_social_shopify_user", array(
                            'email'=>$request['email'],
                            'password'=>$request['password'],
                            'shopify_user_id'=>$customer_id
                        ), array(
                            'id'=>$user->id
                        ));

                        if(!empty($wpdb->last_error)){
                            XH_Social_Log::error($wpdb->last_error);
                            $wp_error->add('validation', XH_Social_Error::err_code(500)->errmsg);
                            exit;
                        }

                        $request = array(
                            'uid'=>$user->id,
                            'domain'=>$domain,
                            'notice_str'=>str_shuffle(time())
                        );
                        $request['hash'] = XH_Social_Helper::generate_hash($request, XH_Social::instance()->get_hash_key());
                        wp_redirect(home_url('/shopify/login').'?'.http_build_query($request));
                        exit;
                    }else if(isset($response['errors']['base'][0])){
                        throw new Exception($response['errors']['base'][0]);
                    }else{
                        throw new Exception('系统错误，请重试！');
                    }
            } catch (Exception $e) {
                $wp_error->add('validation', $e->getMessage());
            }
        }

        $tab = isset($_REQUEST['tab'])?$_REQUEST['tab']:null;
        switch($tab){
            default:
                ?>
                <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                    <meta name="keywords" content="">
                    <meta name="description" content="">
                    <title>完善资料</title>
                </head>
                <body>
            	<h1 class="text-center">完善资料</h1>
            	<?php if($wp_error->get_error_code()){
            	    ?>
            	    <div class="errors">
            	    <ul>
            	    <?php foreach ($wp_error->get_error_messages() as $msg){
            	        ?>  <li><?php echo $msg;?></li><?php
            	    }?>

            	    </ul></div>
            	    <?php
            	}

            	$channel = XH_Social::instance()->channel->get_social_channel($user->channel_id);
            	if($channel){
            	    ?>您正在使用“<?php echo $channel->title?>”登录：<?php
            	}
            	?>
        		<form method="post" action=""  accept-charset="UTF-8">
                   <label>登录邮箱</label>
                   <?php
                   $email = isset($_POST['email'])?$_POST['email']:$user->email;
                   $password = isset($_POST['password'])?$_POST['password']:$user->password;
                   $repassword = isset($_POST['repassword'])?$_POST['repassword']:null;
                   ?>
                   <input type="email" name="email" autocorrect="off" autocapitalize="off" autofocus="autofocus" value="<?php echo esc_attr($email)?>"/>

                   <label>密码</label>
                   <input type="password" name="password" autocorrect="off" autocapitalize="off" value="<?php echo esc_attr($password)?>"/>

                   <label>确认密码</label>
                   <input type="password" name="repassword" autocorrect="off" autocapitalize="off"  value="<?php echo esc_attr($repassword)?>"/>

                   <div class="text-center">
                   		<a href="<?php echo XH_Social_Helper_Uri::get_new_uri(XH_Social_Helper_Uri::get_location_uri(),array('tab'=>'login'))?>" >绑定现有账户</a>
                   		或
                   		<input type="submit" name="register" class="btn" value="确认注册" />
                   </div>
                </form>
            </body>
            </html>
            <?php
            exit;
            case 'login':
                ?>
                <html>
                <head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                    <meta name="keywords" content="">
                    <meta name="description" content="">
                    <title>绑定用户</title>
                </head>
                <body>

                	<h1 class="text-center">绑定用户</h1>
                	<?php if($wp_error->get_error_code()){
                	    ?>
                	    <div class="errors">
                	    <ul>
                	    <?php foreach ($wp_error->get_error_messages() as $msg){
                	        ?>  <li><?php echo $msg;?></li><?php
                	    }?>

                	    </ul></div>
                	    <?php
                	}

                	$channel = XH_Social::instance()->channel->get_social_channel($user->channel_id);
                	if($channel){
                	    ?>您正在绑定“<?php echo $channel->title?>”登录：<?php
                	}

                   $email = isset($_POST['email'])?$_POST['email']:$user->email;
                   $password = isset($_POST['password'])?$_POST['password']:$user->password;
                   $repassword = isset($_POST['repassword'])?$_POST['repassword']:null;
                   ?>
            		<form method="post" action=""  accept-charset="UTF-8">
                       <label>登录邮箱</label>
                       <input type="email" name="email" autocorrect="off" autocapitalize="off" autofocus="autofocus" value="<?php echo esc_attr($email)?>"/>

                       <label>密码</label>
                       <input type="password" name="password" autocorrect="off" autocapitalize="off" value="<?php echo esc_attr($password)?>" />

                       <div class="text-center">
                       		<a href="<?php echo XH_Social_Helper_Uri::get_new_uri(XH_Social_Helper_Uri::get_location_uri(),array('tab'=>'register'))?>">注册新用户</a>
                       		或
                       		<input type="submit" class="btn" name="login" value="确认绑定" />
                       </div>
                    </form>
                </body>
                </html>
                <?php
                exit;
        }
    }

    protected function shopify_login(){
        $request = shortcode_atts(array(
            'uid'=>null,
            'notice_str'=>null,
            'domain'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));

        if(!XH_Social::instance()->WP->ajax_validate($request, $request['hash'],false)){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(600));
            exit;
        }
        $doamin = $request['domain'];
        global $wpdb;
        $user = $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify_user u
            where u.id=%s
            limit 1;", $request['uid']));

        if(!$user){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(600));
            exit;
        }

        $email = $user->email;
        $password = $user->password;
        ?>
            <html>
            <head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                <meta name="keywords" content="">
                <meta name="description" content="">
                <title>登录中，请稍候... </title>
            </head>
            <body>
           <p style="margin:50px 0 0 0;text-align:center;"><img src="data:image/gif;base64,R0lGODlhEAAQAPQAAP///2R1cfb397jAvuzu7o+bmK63tWR1cZqlonqJhs3S0djc23GAfcPKyGd4dIWTkKSuq2R1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cSH5BAkKAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOw=="  width="16" height="16" alt=""/> 登录中，请稍候... </p>
            <form method="post" action="<?php echo $doamin;?>/account/login" id="customer_login" accept-charset="UTF-8">
                <input type="hidden" name="form_type" value="customer_login" />
                <input type="hidden" name="utf8" value="✓" />
            	<div class="oxi_login"><script src="//social-login.oxiapps.com/api/init?shop=xunhu.myshopify.com&type=static"></script></div>

            	<script src='//open-signin.okasconcepts.com/customer/script?shop=xunhu.myshopify.com'></script>
                      <input type="hidden" name="customer[email]" value="<?php echo esc_attr($email)?>"/>
                      <input type="hidden" name="customer[password]"  value="<?php echo esc_attr($password)?>"/>

                    </form>
             		<script type="text/javascript">
             			document.getElementById('customer_login').submit();
                	</script>
            </body>
            </html>
            <?php
            exit;
    }

    protected function shopify_payment_canceled(){
        $request = shortcode_atts(array(
            'shop'=>null,
            'hash'=>null,
            'notice_str'=>null
        ), stripslashes_deep($_REQUEST));

        if(!XH_Social::instance()->WP->ajax_validate($request, $request['hash'])){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(701)->errmsg);
            exit;
        }

        global $wpdb;
        $shop = $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify
            where shop=%s
            limit 1;", $request['shop']));

        if(!$shop){
            XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(701)->errmsg);
            exit;
        }
        XH_Social_Temp_Helper::set('atts', array(
            'id'=>$this->id,
            'title'=>'Payment canceled!',
            'logo'=>$this->get_option('logo'),
            'price'=>$this->get_option('amount'),
            'domain_url'=>$this->url,
            'shop'=>$shop
        ),'templete');

        require XH_Social::instance()->WP->get_template($this->dir, 'shopify/payment-canceled.php');
        exit;
    }

}
