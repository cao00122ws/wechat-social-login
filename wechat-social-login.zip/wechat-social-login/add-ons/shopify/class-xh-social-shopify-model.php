<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Shopify_Model extends Abstract_XH_Social_Schema{
    
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Social_Schema::init()
     */
    public function init(){
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
       "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}xh_social_shopify` (
        	`shop` VARCHAR(128) NOT NULL,
        	`access_token` VARCHAR(128) NOT NULL,
        	`config` TEXT NULL,
			`domain` VARCHAR(128) NULL DEFAULT NULL,
        	`charge_id` VARCHAR(128) NULL DEFAULT NULL,
        	PRIMARY KEY (`shop`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }

    }
}
?>