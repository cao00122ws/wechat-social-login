<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once 'social/abstract-xh-social-shopify-social.php';

abstract class XH_Social_Shopify_Api extends Abstract_XH_Social_Add_Ons{

    public function generate_hmac_sign(array $request){
        $appkey =$this->get_option('appid');
        $appsecret =$this->get_option('appsecret');
    
        ksort($request);
        reset($request);
    
        $string = '';
        $index=0;
        foreach ($request as $key=>$val){
            if($key=='hmac'||$key=='signature'){
                continue;
            }
    
            if($index++!=0){$string.="&";}
            $string.="{$key}={$val}";
        }
    
        return hash_hmac('sha256', $string, $appsecret,false);
    }
    
    public function generate_proxies_sign(array $request){
        $appkey =$this->get_option('appid');
        $appsecret =$this->get_option('appsecret');
    
        ksort($request);
        reset($request);
    
        $string = '';
        $index=0;
        foreach ($request as $key=>$val){
            if($key=='hmac'||$key=='signature'){
                continue;
            }
    
            //if($index++!=0){$string.="&";}
            $string.="{$key}={$val}";
        }
    
        return hash_hmac('sha256', $string, $appsecret,false);
    }
    
    public function get_shop_by_access_token($access_token,$shop_name){
        global $wpdb;
        $shop = $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify
            where shop=%s
            limit 1;", $shop_name));
        
        if(!$shop){
            $wpdb->insert("{$wpdb->prefix}xh_social_shopify", array(
                'shop'=>$shop_name,
                'access_token'=>$access_token
            ));
            
            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error);
            }
        } else{
            $wpdb->update("{$wpdb->prefix}xh_social_shopify", array(
                'access_token'=>$access_token
            ),array(
                'shop'=>$shop_name,
            ));
            
            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error);
            }
        }
        
        return $wpdb->get_row($wpdb->prepare(
           "select *
            from {$wpdb->prefix}xh_social_shopify
            where shop=%s
            limit 1;", $shop_name));
    }
    
    public function get_access_token($shop_name,$code){
        $token = XH_Social::instance()->session->get("shoppify_{$shop_name}");
        if($token
            && is_array($token)
            &&isset($token['code'])
            &&$token['code']==$code
            &&isset($token['expired'])
            && $token['expired']>time()){
            return $token['access_token'];
        }
        
        $appkey =$this->get_option('appid');
        $appsecret =$this->get_option('appsecret');
        
         try {
            $content = XH_Social_Helper_Http::http_post("https://{$shop_name}/admin/oauth/access_token",(array(
                'client_id'=>$appkey,
                'client_secret'=>$appsecret,
                'code'=>$code
            )));
        } catch (Exception $e) {
            throw new Exception("Get access token failed,detail errors:errcode:{$e->getCode()},errmsg:{$e->getMessage()}",$e->getCode());
        }
         
        $response = $content?json_decode($content,true):null;
        if(!$response||!isset($response['access_token'])){
            throw new Exception($content);
        }
        
        XH_Social::instance()->session->set("shoppify_{$shop_name}",array(
            'code'=>$code,
            'expired'=>time()+7200,
            'access_token'=>$response['access_token']
        ));
        return $response['access_token'];
    }
    
    public function refresh_script_tag($shop){
        $js = home_url("/shopify/js");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "X-Shopify-Access-Token:{$shop->access_token}"
        ));
        
        try {
            XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/script_tags.json",array(
                'script_tag'=>array(
                    'event'=>'onload',
                    'src'=>$js,
                    'display_scope'=>'all'
                )
            ),false,$ch);
        
        } catch (Exception $e) {
            if($e->getCode()!=201){
                throw new Exception("Add script tag failed,detail errors:errcode:{$e->getCode()},errmsg:{$e->getMessage()}",$e->getCode());
            }
        }
    }
    
    public function refresh_recurring_application_charges($shop){ 
        if(!empty($shop->charge_id)){
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-Shopify-Access-Token:{$shop->access_token}"
            ));
            
            $response = XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/recurring_application_charges/{$shop->charge_id}.json",false,$ch);
            $charge_info = $response?json_decode($response,true):array();
            if(isset($charge_info['recurring_application_charge']['status'])&&$charge_info['recurring_application_charge']['status']=='active'){
                return;
            }
        }
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "X-Shopify-Access-Token:{$shop->access_token}"
        ));
        
        $request = array(
            'shop'=>$shop->shop,
            'notice_str'=>str_shuffle(time())
        );
        
        $request['hash'] = XH_Social_Helper::generate_hash($request, xh_sOCIAL::instance()->get_hash_key());
        
        try {
            $amount = round($this->get_option('amount'),2);
            if($amount<1){$amount=1;}
            $response = XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/recurring_application_charges.json",array(
                'recurring_application_charge'=>array(
                    'name'=> 'Super Duper Plan',
                    'price'=> $amount,
                    'return_url'=>home_url('shopify/recurring_application_charges/confirm').'?'.http_build_query($request),
                    //'test'=>true,
                    'trial_days'=>intval($this->get_option('free_days',0))
                )
            ),false,$ch);
            
            $response = json_decode($response,true);
            wp_redirect($response['recurring_application_charge']['confirmation_url']);
            exit;
        } catch (Exception $e) {
            if($e->getCode()!=201){
                throw new Exception("Add script tag failed,detail errors:errcode:{$e->getCode()},errmsg:{$e->getMessage()}",$e->getCode());
            }
        }
    }
}