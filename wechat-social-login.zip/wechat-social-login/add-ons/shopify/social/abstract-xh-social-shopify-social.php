<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

abstract class XH_Social_Shopify_Social{
    public $config;
    public $shop;
    
    public function __construct($shop){
        $this->shop = $shop;
        $this->config = $shop->config?maybe_unserialize( $shop->config):array();
    }
    
    /**
     * @return Abstract_XH_Social_Settings_Channel
     */
    abstract function get_channel();
    
    public static function get_scope($scope,$shop){
        switch ($scope){
            case 'wechat-op':
                require_once 'class-xh-social-shopify-social-wechat-op.php';
                return new XH_Social_Shopify_Social_Wechat_OP($shop);
            case 'qq':
                require_once 'class-xh-social-shopify-social-qq.php';
                return new XH_Social_Shopify_Social_QQ($shop);
            case 'weibo':
                require_once 'class-xh-social-shopify-social-weibo.php';
                return new XH_Social_Shopify_Social_Weibo($shop);
            default:
                return null;
        }
    }
    
    abstract function redirect($redirect_uri);
    
    abstract function notify($domain);
    
    public function create_shopify_user($domain,$uid,$customer_data){
        $shop = $this->shop;
        $config = $shop->config?maybe_unserialize( $shop->config):array();
        //$multipass_login_secret = isset($config['multipass_login_secret'])?$config['multipass_login_secret']:null;
    
        //if(empty($multipass_login_secret)){
            $this->create_shopify_user_new($domain, $uid, $customer_data);
            exit;
        //}
        
//         $customer_data['email'] = "{$uid}@{$customer_data['tag_string']}.com";
//         require_once 'class-xh-social-shopify-multipass.php';
    
//         date_default_timezone_set("UTC");
    
//         $multipass = new XH_Social_ShopifyMultipass($multipass_login_secret);
//         $token = $multipass->generate_token($customer_data);
        
//         wp_redirect("https://{$shop->shop}/account/login/multipass/$token");
//         exit;
    }
    
    private function get_shopify_user($user){
        $shop = $this->shop;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "X-Shopify-Access-Token:{$shop->access_token}"
        ));
       
        try {
            $response =  XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/customers/{$user->shopify_user_id}.json",false,$ch);
            $response = $response?json_decode($response,true):array();
            $customer_id = 0;
            if(isset($response['customer']['id'])&&$response['customer']['id']==$user->shopify_user_id){
                if(!empty($response['customer']['email'])&& $response['customer']['email']!=$user->email){
                    global $wpdb;
                    $wpdb->update("{$wpdb->prefix}xh_social_shopify_user", array(
                        'email'=>$response['customer']['email']
                    )  , array(
                        'id'=>$user->id
                    ));
                }
                return $response['customer'];
            }
            
            return null;
        } catch (Exception $e) {
            throw new Exception("Get user info failed when login,detail errors:errcode:{$e->getCode()},errmsg:{$e->getMessage()}",$e->getCode());
        }
    }
    
    protected function shopify_login($domain,$user){
        global $wpdb;
        
        $email = $user->email;
        $password = $user->password;
        ?>
            <html>
            <head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                <meta name="keywords" content="">
                <meta name="description" content="">   
                <title>登录中，请稍候... </title>
            </head>
            <body>
           <p style="margin:50px 0 0 0;text-align:center;"><img src="data:image/gif;base64,R0lGODlhEAAQAPQAAP///2R1cfb397jAvuzu7o+bmK63tWR1cZqlonqJhs3S0djc23GAfcPKyGd4dIWTkKSuq2R1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cWR1cSH5BAkKAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOw=="  width="16" height="16" alt=""/> 登录中，请稍候... </p>
            <form method="post" action="<?php echo $domain;?>/account/login" id="customer_login" accept-charset="UTF-8">
                <input type="hidden" name="form_type" value="customer_login" />
                <input type="hidden" name="utf8" value="✓" />
            	<div class="oxi_login"><script src="//social-login.oxiapps.com/api/init?shop=xunhu.myshopify.com&type=static"></script></div>
            
            	<script src='//open-signin.okasconcepts.com/customer/script?shop=xunhu.myshopify.com'></script>
                      <input type="hidden" name="customer[email]" value="<?php echo esc_attr($email)?>"/>
                      <input type="hidden" name="customer[password]"  value="<?php echo esc_attr($password)?>"/>
                      
                    </form>
             		<script type="text/javascript">
             			document.getElementById('customer_login').submit();
                	</script>
            </body>
            </html>
            <?php 
            exit;
    }
    
    private function create_shopify_user_new($domain,$uid,$info){
        $channel_id = $this->get_channel()->id;
        $shop = $this->shop;
        $id = md5("{$channel_id}-{$shop->shop}-{$uid}");
        
        global $wpdb;
        $user = $wpdb->get_row(
            "select *
             from {$wpdb->prefix}xh_social_shopify_user u
             where u.id='{$id}'
                   and u.uid='{$uid}'
                   and u.channel_id='{$channel_id}'
             limit 1;");
        
        if($user&&$user->shopify_user_id){
            $shopify_user = $this->get_shopify_user($user);
            if($shopify_user){
                $this->shopify_login($domain,$user);exit;
            }
        }
       
        $email = $info['email'];
        
        $password = str_shuffle(time());
       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "X-Shopify-Access-Token:{$shop->access_token}"
        ));
        //过滤掉201状态的http
        add_filter('xunhu_http_post_errcode', function($false,$code,$ch){
            if($code==201){
                return false;
            }
            return $false;
        },10,3);
        
        $response =  XH_Social_Helper_Http::http_get("https://{$shop->shop}/admin/customers/search.json?query=email:{$email}&limit=1",false,$ch);
        $response = $response?json_decode($response,true):array();
        if(isset($response['customers'])&&count($response['customers'])>0){
            $this->shopify_login($domain,$user);exit;
        }else{
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                "X-Shopify-Access-Token:{$shop->access_token}"
            ));
            
            $user_info = $info;
            if(!$user_info||!is_array($user_info)){$user_info=array();}
          
            $user_info['email'] = $email;
            $user_info['password']=$password;
            $user_info['password_confirmation']=$password;
            $user_info['send_email_welcome']=false;
            $user_info['verified_email']=true;
            
            $response =  XH_Social_Helper_Http::http_post("https://{$shop->shop}/admin/customers.json",array(
                'customer'=>$user_info
            ),false,$ch);
            
            $response = $response?json_decode($response,true):array();
             
            if(isset($response['customer']['id'])){
                if(!$user){
                    $wpdb->insert("{$wpdb->prefix}xh_social_shopify_user", array(
                        'id'=>$id,
                        'uid'=>$uid,
                        'email'=>$email,
                        'password'=>$password,
                        'shop'=>$shop->shop,
                        'last_update'=>date_i18n('Y-m-d H:i:s'),
                        'channel_id'=>$channel_id,
                        'shopify_user_id'=>$response['customer']['id'],
                        'info'=>json_encode($info,JSON_UNESCAPED_UNICODE)
                    ));
                }else{
                    $wpdb->update("{$wpdb->prefix}xh_social_shopify_user", array(
                        'uid'=>$uid,
                        'email'=>$email,
                        'password'=>$password,
                        'shop'=>$shop->shop,
                        'last_update'=>date_i18n('Y-m-d H:i:s'),
                        'channel_id'=>$channel_id,
                        'shopify_user_id'=>$response['customer']['id'],
                        'info'=>json_encode($info,JSON_UNESCAPED_UNICODE)
                    ),array(
                        'id'=>$id
                    ));
                }
                
                if(!empty($wpdb->last_error)){
                    XH_Social_Log::error($wpdb->last_error);
                    XH_Social::instance()->WP->wp_die(XH_Social_Error::err_code(500));
                    exit;
                }
                
                $user = $wpdb->get_row(
                   "select *
                    from {$wpdb->prefix}xh_social_shopify_user u
                    where u.id='{$id}'
                        and u.uid='{$uid}'
                        and u.channel_id='{$channel_id}'
                    limit 1;");
                
                if($user&&$user->shopify_user_id){
                    $shopify_user = $this->get_shopify_user($user);
                    if($shopify_user){
                        $this->shopify_login($domain,$user);exit;
                    }
                }
            }else{
                XH_Social::instance()->WP->wp_die(print_r($response,true));
            }
            
            
        }
        
        XH_Social::instance()->WP->wp_die(XH_Social_Error::error_unknow());
        exit;

    }
}