<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Shopify_Social_QQ extends XH_Social_Shopify_Social{
   
    public function get_channel(){
        return XH_Social_Channel_QQ::instance();
    }
    
    /**
     * {@inheritDoc}
     * @see XH_Social_Shopify_Social::redirect()
     */
    public function redirect($redirect_uri)
    {
        // TODO Auto-generated method stub
        $shop = $this->shop;
        $config = $this->config;
        
        $appid = isset($config['qq_appid'])?$config['qq_appid']:null;
        $appsecret = isset($config['qq_appsecret'])?$config['qq_appsecret']:null;
        
        $api = $this->get_channel();
        //代理登录账户？那么直接登录
        if(class_exists('XH_Social_Settings_WP_Open_Default')&&$appid==XH_Social_Settings_WP_Open_Default::APP_ID_QQ){
            $params = array();
            $cross_domain_url = XH_Social_Helper_Uri::get_uri_without_params( $api->get_option("cross_domain_url"),$params);
            $params['appid']=$appid;
            $params['callback']=$redirect_uri;
            $params['hash'] = XH_Social_Helper::generate_hash(array('callback'=>$redirect_uri), $appsecret);
    
            wp_redirect($cross_domain_url."?".http_build_query($params));
            exit;
        }
        
        wp_redirect($api->get_qq_authorize_url($appid, $redirect_uri));
        exit;
    }

    /**
     * {@inheritDoc}
     * @see XH_Social_Shopify_Social::notify()
     */
    public function notify($domain)
    {
        $shop = $this->shop;
        $config = $this->config;
        $appid = isset($config['qq_appid'])?$config['qq_appid']:null;
        $appsecret = isset($config['qq_appsecret'])?$config['qq_appsecret']:null;
        $multipass_login_secret = isset($config['multipass_login_secret'])?$config['multipass_login_secret']:null;

        $userdata = array();
        if(isset($_POST['userdata'])&&isset($_POST['user_hash'])){
            $userdata = isset($_POST['userdata'])? base64_decode($_POST['userdata']):null;
            $user_hash = isset($_POST['user_hash'])?$_POST['user_hash']:'';
             
            $userdata =$userdata?json_decode($userdata,true):null;
            if(!$userdata){
                wp_redirect($domain.'/account/login');
                exit;
            }
             
            $ohash =XH_Social_Helper::generate_hash($userdata, $appsecret);
            if($user_hash!=$ohash){
                XH_Social::instance()->WP->XH_Social::instance()->WP->wp_die(__('Please check cross-domain app secret config(equal to current website app secret)!',XH_SOCIAL));
                exit;
            }
        }else{
            if(!isset($_GET['code'])){
               wp_redirect($domain.'/account/login');
               exit;
            }
            
            try {
                $userdata = $this->get_channel()->get_qq_user_by_code($_GET['code'], $appid, $appsecret);
            } catch (Exception $e) {
                XH_Social_Log::error($e);
                XH_Social::instance()->WP->wp_die($e);
                exit;
            }
        }
        
        $this->create_shopify_user($domain,$userdata['openid'],array(
            'email'=>"{$userdata['openid']}@qq.com",
            'first_name'=>XH_Social_Helper_String::remove_emoji($userdata['nickname']),
            'last_name'=>'',
            'tag_string'=>'qq',//系统在使用这个参数，不要去掉
            'identifier'=>$userdata['openid'],
            'remote_ip'=>XH_Social_Helper_Http::get_client_ip(),
            'return_to'=>$domain.'/account/login',
            'addresses'=>array(
                array(
                    'country'=>'china',
                    'first_name'=>XH_Social_Helper_String::remove_emoji($userdata['nickname']),
                    'city'=>$userdata['city'],
                    'province'=>$userdata['province'],
                )
            )
         ));
        
        
        exit;
    }
}