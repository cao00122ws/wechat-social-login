/**
 * handle social login portal
 * @param api_shopify
 * @param api_theme
 * @param api_analytics
 */
(function(api_shopify ){
	"use strict";
	
	if(!api_shopify){
		return;
	}
	var s = location.search;
	//get login bars
	var login_bars = document.getElementsByClassName('wsocial-bar');
	if(!login_bars||login_bars.length==0){
		return;
	}
	
	for(var index=0;index<login_bars.length;index++){
		var login_bar = login_bars[index];
		
		login_bar.onclick=function(event){
			if(typeof this.href=='undefined'){
				return false;
			}
			
			var indexof_ = this.href.lastIndexOf('#');
			if(indexof_<0){return false;}
			
			var social = this.href.substr(indexof_+1);
			event.preventDefault();
			
			var reg = new RegExp("(^|&)checkout_url=([^&]*)(&|$)");
		    var match = window.location.search.substr(1).match(reg);
		    var redirect_to =match? decodeURIComponent(match[2]):'';
			//get location
			location.href='https://www.weixinsocial.com/shopify/redirect?scope='+social+'&shop='+encodeURIComponent(api_shopify.shop)+'&location='+encodeURIComponent(location.href.toString())+'&redirect_to='+encodeURIComponent(redirect_to);
			return false;
		}
	}
})(Shopify);