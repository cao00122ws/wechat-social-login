<?php 
class XH_Social_Shopify_Helper{
    public static function auth_check($domain,$user){
        $request = array(
            'form_type'=>'customer_login',
            'utf8'=>'✓',
            'customer[email]'=>$user->email,
            'customer[password]'=>$user->password
        );
        add_filter('xunhu_http_post_errcode', function($false,$code,$ch){
            if($code==302){
                return false;
            }
            return $false;
        },10,3);
        
       try {
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
           $response = XH_Social_Helper_Http::http_post($domain.'/account/login',$request,false,$ch,true);
           XH_Social_Log::error($response);
       } catch (Exception $e) {
           echo $e->getMessage();exit;
       }
    }
}
?>