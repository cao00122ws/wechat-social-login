<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once 'abstract-xh-social-shopify-page.php';

/**
 * 微信登录
 * 
 * @author ranj
 * @since 1.0.0
 */
class XH_Social_Add_On_Social_Shopify extends XH_Social_Shopify_Page{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var XH_Social_Add_On_Social_Shopify
     */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    public $url;
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Add_On_Social_Shopify
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    private function __construct(){
        $this->id='add_ons_social_shopify';
        $this->title='Shopify - 社会化登录';
        $this->description='';
        $this->version='1.0.0';
        $this->setting_uri = admin_url('admin.php?page=social_page_default&section=menu_default_ext&sub=add_ons_social_shopify');
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',XH_SOCIAL);
        $this->author_uri='https://www.wpweixin.net';
        $this->dir=XH_Social_Helper_Uri::wp_dir(__FILE__);
        $this->url= XH_Social_Helper_Uri::wp_url(__FILE__);
        $this->init_form_fields();
        $this->enabled ='yes'== $this->get_option('enabled');
    }
        
    public function init_form_fields(){
        $this->form_fields=array(
            'enabled'=>array(
                'title'=>__('Enable/Disable',XH_SOCIAL),
                'type'=>'checkbox',
                'label'=>'启用shopify登陆接口',
                'default'=>'yes'
            ),
            'title'=>array(
                'title'=>__('App title',XH_SOCIAL),
                'type'=>'text'
            ),
            'logo'=>array(
                'title'=>__('App logo',XH_SOCIAL),
                'type'=>'image'
            ),
            'appid'=>array(
                'title'=>__('App key',XH_SOCIAL),
                'type'=>'text'
            ),
            'appsecret'=>array(
                'title'=>__('App Secret',XH_SOCIAL),
                'type'=>'text'
            ),
            'amount'=>array(
                'title'=>__('Amount',XH_SOCIAL),
                'type'=>'text'
            ),
            'free_days'=>array(
                'title'=>__('Free days',XH_SOCIAL),
                'type'=>'text'
            )
        );
    }
 
    public function on_install(){
        require_once 'class-xh-social-shopify-model.php';
        $model = new XH_Social_Shopify_Model();
        $model->init();
        
        $model = new XH_Social_Add_On_Shopify();
        $model->init();
    }
    
    public function on_load(){
        if(!$this->enabled){
            return;
        }
        add_filter('xh_social_ajax', function ($shortcodes){
            $shortcodes["wsocial_{$this->id}"]=array(XH_Social_Add_On_Social_Shopify::instance(),'do_ajax');
            return $shortcodes;
        },10,1);
        
        add_filter('xh_social_admin_menu_menu_default_ext', function ($menus){
            $menus[]=XH_Social_Add_On_Social_Shopify::instance();
            return $menus;
        },10,1);
        
        add_action('wsocial_after_init', function(){
            $request_uri =  isset($_SERVER['REQUEST_URI'])?explode('?', strtolower($_SERVER['REQUEST_URI'])):null;
            
            $uri = $request_uri?trim($request_uri[0],'/'):null;
            if(!$uri){
                return;
            }
            
            $api = XH_Social_Add_On_Social_Shopify::instance();
            switch ($uri){
				case 'shopify/js':
                    $api->shopify_js();exit;
                case 'shopify/install':
                    $api->shopify_install();exit;
                case 'shopify/install/callback':
                    $api->shopify_install_callback();exit;
                case 'shopify/social-notify':
                    $api->shopify_social_notify();exit;
                case 'shopify/payment/canceled':
                    $api->shopify_payment_canceled();exit;
                case 'shopify/redirect':
                    $api->shopify_redirect();exit;
                case 'shopify/recurring_application_charges/confirm':
                    $api->shopify_recurring_application_charges_confirm();exit;
                //case 'shopify/confirm':
                   // $api->shopify_confirm();exit;
                //case 'shopify/login':
                    //$api->shopify_login();exit;
                default:return;
            }
        },999);
    }
    
    public function do_ajax(){
        $tab = isset($_REQUEST['tab'])?$_REQUEST['tab']:'';
        
        switch ($tab){
            case 'config':
                $action ="wsocial_{$this->id}";
                $request=shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    'tab'=>$tab,
                    'hash'=>null,
                    'shop'=>null
                ), stripslashes_deep($_REQUEST));
        
                $validate =XH_Social::instance()->WP->ajax_validate($request,$request['hash']);
                if(!$validate){
                    echo (XH_Social_Error::err_code(701)->to_json());
                    exit;
                }
                
                $config = shortcode_atts(array(
                    'multipass_login_secret'=>null,
                    
                    'wechat_mp_appid'=>null,
                    'wechat_mp_appsecret'=>null,
                
                    'wechat_op_appid'=>null,
                    'wechat_op_appsecret'=>null,
                    
                    'qq_appid'=>null,
                    'qq_appsecret'=>null,
                    
                    'weibo_appid'=>null,
                    'weibo_appsecret'=>null,
                ), $_REQUEST);
                
                global $wpdb;
                $shop = $wpdb->get_row(
                    $wpdb->prepare(
                    "select *
                     from {$wpdb->prefix}xh_social_shopify
                     where shop=%s
                     limit 1;", $request['shop']));
                if(!$shop){
                    XH_Social_Log::error("shop not found,details:".print_r($_REQUEST,true));
                    echo XH_Social_Error::error_custom('Sorry,We can not found your shop info,please reinstall current app and try again.')->to_json();
                    exit;
                }
                
                $wpdb->update("{$wpdb->prefix}xh_social_shopify", array(
                    'config'=>maybe_serialize($config)
                ), array(
                    'shop'=>$shop->shop
                ));
                
                if(!empty($wpdb->last_error)){
                    XH_Social_Log::error($wpdb->last_error);
                    echo XH_Social_Error::err_code(500)->to_json();
                    exit;
                }
              
                echo XH_Social_Error::success()->to_json();
                exit;
        }
        
    }
}
class XH_Social_Add_On_Shopify extends Abstract_XH_Social_Schema{

    /**
     * {@inheritDoc}
     * @see Abstract_XH_Social_Schema::init()
     */
    public function init(){
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}xh_social_shopify_user` (
            `id` varchar(32) NOT NULL,
            `uid` varchar(128) NULL DEFAULT NULL,
            `email` varchar(128) NULL DEFAULT NULL,
            `password` VARCHAR(64) NULL DEFAULT NULL,
            `shop` VARCHAR(128) NULL DEFAULT NULL,
            `last_update` DATETIME NOT NULL,
            `info` TEXT NULL DEFAULT NULL,
            `channel_id` VARCHAR(64) NOT NULL,
            `shopify_user_id` VARCHAR(64) NULL DEFAULT NULL,
            PRIMARY KEY (`id`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}
return XH_Social_Add_On_Social_Shopify::instance();
?>