<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Abstract_XH_Social_Add_Ons_WOO_Api extends Abstract_XH_Social_Add_Ons{
    public $u;
    public $i;
    public $k;
    protected function __construct(){
        $o = $this;
        $o->u = XH_SOCIAL_URL;
        $o->i = XH_Social_Install::instance()->get_plugin_options();
        $o->k=XH_Social::license_id;
    }
    /**
     * 执行 on_load()
     */
    public function m1(){
        $o=$this;
        $o->m0(function($o){

        },function($o){
        });   
    }
    
    /**
     * 执行 on_init()
     */
    public function m2(){
        $o=$this;
        $o->m0(function($o){
            add_action('woocommerce_login_form', array($o,'woocommerce_login_form'));
            add_action('woocommerce_account_dashboard', array($o,'woocommerce_account_dashboard'));
          
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
       
            $api = XH_Social_Install::instance();
            $o->setting_uris['license']['title']=__('Change license',XH_SOCIAL);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
         
        },function($o){
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
             
            $api = XH_Social_Install::instance();
            $o->setting_uris['license']['title']=__('License',XH_SOCIAL);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
        });
    }

    public function m0($func_success,$func_fail){
	    $o = $this;
	    $website=$o->u;
	    $website = strtolower($website);
	    $license_id = $o->id;
	    if(strpos($website, 'http://')===0){
	        $website = substr($website, 7);
	    }else if(strpos($website, 'https://')===0){
	        $website = substr($website, 8);
	    }
	   
	    //去掉二级目录
	    if(strpos($website, '/')!==false){
	        $websites = explode('/', $website);
	        $website = $websites[0];
	    }
	    $prewebsite =$website;
	    
	    $info = $o->i;
	    $pre_license =$info&&isset($info[$o->id])?$info[$o->id]:null;
	    $license =$pre_license;
	    $licenses= $license?explode('=', $license):array();
	    $license =count($licenses)>0?$licenses[0]:null;
	    $expire=count($licenses)>1?$licenses[1]:null;
	    $global_license_check = false;
	    $old_license_check =false;
	    $id=$o->id;
	    while (true){
	        $str =$expire."|".$website."|".$id; 
	        $str =md5($str);
	        $b =0;
	        for ($i=0;$i<strlen($str);$i++){
	            $b+= ord($str[$i]);
	        }
	     
	        $xx=md5($str.$b)==$license;
	        $o->ia=$xx;
	        if($xx){
	            if($func_success){
	                if($old_license_check){  
	                    XH_Social_Install::instance()->update_plugin_options(array(
	                        $o->id=>$pre_license
	                    ));
	                }
	                call_user_func($func_success,$o);
	            }
	            break;
	        }
    
            if(substr_count($website,'.')<=1){ 
                if(!$global_license_check){
                  
                    $global_license_check=true;
                    $website=$prewebsite;
                    $pre_license = $license =$info&&isset($info['license'])?$info['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->k;
                    continue;
                }
                
                if(!$old_license_check){
                    $old_license_check=true;
                    $options =get_option ( $o->plugin_id . $o->id . '_settings', null );
                    
                    $pre_license = $license = $options&&isset($options['license'])?$options['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->id;
                    continue;
                }
               
                
                if($func_fail){
                    call_user_func($func_fail,$o);
                }
                break;
            }
    
            $index = strpos($website, '.');
            $website = substr($website, $index+1);
	    } 
	}
}