<?php 


if(isset($_GET["echostr"])
            &&isset($_GET['signature'])
            &&isset($_GET['nonce'])
            &&isset($_GET['timestamp'])){
           
                echo $_GET["echostr"];
                exit;
        }
 
define('WP_USE_THEMES', false);
require_once './wp-load.php';

if(!class_exists('XH_Social_Add_On_Social_Wechat_Sync')){
    wp_die('未安装“微信同步”扩展!');
}

XH_Social_Add_On_Social_Wechat_Sync::instance()->on_wechat_service_load();

?>