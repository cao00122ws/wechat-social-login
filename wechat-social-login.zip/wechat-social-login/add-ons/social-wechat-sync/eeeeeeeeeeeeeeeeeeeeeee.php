<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Abstract_XH_Social_Add_Ons_Wechat_Sync_Api extends Abstract_XH_Social_Add_Ons{
    public $u;
    public $i;
    public $k;
    protected function __construct(){
        $o = $this;
        $o->u = XH_SOCIAL_URL;
        $o->i = XH_Social_Install::instance()->get_plugin_options();
        $o->k=XH_Social::license_id;
    }
    /**
     * 执行 on_load()
     */
    public function m1(){
        $o=$this;
        $o->m0(function($o){
            add_filter('xh_social_admin_pages', array($o,'xh_social_admin_pages'),10,1);
            add_filter('xh_social_admin_menu_menu_wechat_connect', array($o,'add_menu'),10,1);
            add_filter('wsocial_wechat_qrcode_login_get_authorization_uri', array($o,'wsocial_wechat_qrcode_login_get_authorization_uri'),10,6);
            add_action('wsocial_wechat_qrcode_connect', array($o,'wsocial_wechat_qrcode_connect'),10,3);
            add_filter('wsocial_wechat_qrcode_content', array($o,'wsocial_wechat_qrcode_content'),10,3);
            
            add_action('xh_social_channel_wechat_receive_event', array($o,'wechat_receive_event'),0,2);
            add_action('xh_social_channel_wechat_receive_event', array($o,'wechat_receive_event_reply'),10,2);

            add_action('xh_social_channel_wechat_receive_msg', array($o,'wechat_receive_msg'),10,2);
            
            add_filter('xh_social_ajax',array($o,'_ajax'),10,1);
            add_action('wsocial_wechat_receive_event_click_newest_posts_8', array($o,'wechat_receive_event_click_get_newest_posts_8'),10,2);
            add_action('wsocial_wechat_receive_event_click_newest_products_8', array($o,'wechat_receive_event_click_get_newest_products_8'),10,2);
             
            //标识菜单自动同步
            add_action('edit_form_top', array($o,'edit_form_top'),10,1);
            add_action('save_post', array($o,'save_post'),10,3);
            add_action('admin_init', array($o,'admin_init'),10);
            //标识菜单自动同步 END
            
            add_filter('wsocial_obj_search_wechat_user', array($o,'obj_search_wechat_user'),10,4);
        },function($o){
        });   
    }
    
    /**
     * 执行 on_init()
     */
    public function m2(){
        $o=$this;
        $o->m0(function($o){
           
            $o->setting_uris=array();
            $o->setting_uris['settings']=array();
            $o->setting_uris['license']=array();
            $o->setting_uris['settings']['title']=__('Settings',XH_SOCIAL);
            $o->setting_uris['settings']['url']=admin_url('admin.php?page=social_page_wechat_connect&section=menu_wechat_connect&sub=wsocial_wechat_sync');
            
            $api = XH_Social_Install::instance();
            $o->setting_uris['license']['title']=__('Change license',XH_SOCIAL);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
             
        },function($o){
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
             
            $api = XH_Social_Install::instance();
            $o->setting_uris['license']['title']=__('License',XH_SOCIAL);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
        });
    }

    public function m0($func_success,$func_fail){
	    $o = $this;
	    $website=$o->u;
	    $website = strtolower($website);
	    $license_id = $o->id;
	    if(strpos($website, 'http://')===0){
	        $website = substr($website, 7);
	    }else if(strpos($website, 'https://')===0){
	        $website = substr($website, 8);
	    }
	   
	    //去掉二级目录
	    if(strpos($website, '/')!==false){
	        $websites = explode('/', $website);
	        $website = $websites[0];
	    }
	    $prewebsite =$website;
	    
	    $info = $o->i;
	    $pre_license =$info&&isset($info[$o->id])?$info[$o->id]:null;
	    $license =$pre_license;
	    $licenses= $license?explode('=', $license):array();
	    $license =count($licenses)>0?$licenses[0]:null;
	    $expire=count($licenses)>1?$licenses[1]:null;
	    $global_license_check = false;
	    $old_license_check =false;
	    $id=$o->id;
	    while (true){
	        $str =$expire."|".$website."|".$id; 
	        $str =md5($str);
	        $b =0;
	        for ($i=0;$i<strlen($str);$i++){
	            $b+= ord($str[$i]);
	        }
	     
	        $xx=md5($str.$b)==$license;
	        $o->ia=$xx;
	        if($xx){
	            if($func_success){
	                if($old_license_check){  
	                    XH_Social_Install::instance()->update_plugin_options(array(
	                        $o->id=>$pre_license
	                    ));
	                }
	                $func_success($o);
	            }
	            break;
	        }
    
            if(substr_count($website,'.')<=1){ 
                if(!$global_license_check){
                  
                    $global_license_check=true;
                    $website=$prewebsite;
                    $pre_license = $license =$info&&isset($info['license'])?$info['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->k;
                    continue;
                }
                
                if(!$old_license_check){
                    $old_license_check=true;
                    $options =get_option ( $o->plugin_id . $o->id . '_settings', null );
                    
                    $pre_license = $license = $options&&isset($options['license'])?$options['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->id;
                    continue;
                }
               
                
                if($func_fail){
                    $func_fail($o);
                }
                break;
            }
    
            $index = strpos($website, '.');
            $website = substr($website, $index+1);
	    } 
	}
}