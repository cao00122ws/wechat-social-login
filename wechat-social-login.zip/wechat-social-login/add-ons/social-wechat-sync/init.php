<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
require_once 'abstract-xh-add-ons-api.php';
/**
 * 微信登录
 * 
 * @author ranj
 * @since 1.0.0
 */
class XH_Social_Add_On_Social_Wechat_Sync extends Abstract_XH_Social_Add_Ons_Wechat_Sync_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var XH_Social_Add_On_Social_Wechat_Sync
     */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    public $url;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Add_On_Social_Wechat_Sync
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        parent::__construct();
        //TODO 在文章列表显示是否已同步，并显示已同步后的链接地址，列表新增 [同步状态][更新同步][删除同步][查看同步]功能
        $this->id='wsocial_wechat_sync';
        $this->title=__('Wechat sync',XH_SOCIAL);
        $this->menu_title=__('Server config',XH_SOCIAL);
        $this->description='同步文章到公众号，实现关注公众号登录，实现微信菜单同步等。</p>';
        $this->version='1.0.2';
        
        $this->min_core_version = '1.2.5';
        $this->author=__('xunhuweb',XH_SOCIAL);
        $this->author_uri='https://www.wpweixin.net';
        $this->plugin_uri="https://www.wpweixin.net/product/1135.html";
        $this->depends['add_ons_social_wechat']=array(
            'title'=>__('Wechat',XH_SOCIAL)
        );

        $this->dir=  XH_Social_Helper_Uri::wp_dir(__FILE__);
        $this->url=  XH_Social_Helper_Uri::wp_url(__FILE__);
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $protocol = (! empty ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] !== 'off' || $_SERVER ['SERVER_PORT'] == 443) ? "https://" : "http://";
        $home_url = isset($_SERVER['HTTP_HOST'])? rtrim($protocol.$_SERVER['HTTP_HOST'],'/'):'';
        
        $fields = array();
        $fields['url1']=array(
            'tr_css'=>'section-login_type section-1',
            'title'=>__('URL',XH_SOCIAL),
            'type'=>'text',
            'default'=>$home_url."/wsocial-wechat-receive.php",
            'custom_attributes'=>array(
                'disabled'=>'disabled'
            ),
            'description'=>sprintf(__('(拷贝文件<code>%s</code>到网站根目录)<br/><a href="https://mp.weixin.qq.com" target="_blank">微信公众平台</a>>基本设置>服务器配置',XH_SOCIAL),'/wp-content/wechat-social-login/add-ons/social-wechat-sync/wsocial-wechat-receive.php')
        );
        
        $fields['token']=array(
            'tr_css'=>'section-login_type section-1',
            'title'=>__('Token',XH_SOCIAL),
            'type'=>'text'
        );
        
        $fields['EncodingAESKey']=array(
            'tr_css'=>'section-login_type section-1',
            'title'=>__('EncodingAESKey',XH_SOCIAL),
            'type'=>'text'
        );
 
        $this->form_fields = $fields;
    }
   
    public function on_load(){
        $this->m1();
        add_action('pre_get_post_content', array($this,'pre_get_post_content'));
    }

    public function pre_get_post_content(){
        //兼容js_composer编辑器
        if(class_exists('Vc_Manager')&&class_exists('WPBMap')){
            WPBMap::addAllMappedShortcodes();
        }
    }
    
    public function on_install(){
        require_once 'class-wechat-model-sync.php';
        $api = new XH_Social_Channel_Wechat_Model_Sync();
        $api->init();
    }
    
    public function on_init(){
        $this->m2();
        add_action('wp_loaded', array($this,'do_ajax'));
    }
    
    public function obj_search_wechat_user($results,$type, $keywords,$post_ID){
        global $wpdb;
        $users = $wpdb->get_results($wpdb->prepare(
            "select u.ID,
                    u.user_login,
                    u.user_email
            from {$wpdb->prefix}users u
            inner join {$wpdb->prefix}xh_social_channel_wechat w on w.user_id = u.ID
            where ($post_ID=0 or u.ID=$post_ID)
                    and (%s='' or u.user_login like %s or u.user_email like %s)
                    and w.mp_openid is not null
                    and w.mp_openid !=''
            limit 10;",$keywords, "$keywords%","$keywords%"));
         
        $results = array();
        if($users){
            foreach ($users as $user){
                if(!empty($user->user_email)){
                    $results[]=array(
                        'id'=>$user->ID,
                        'text'=>"{$user->user_login}({$user->user_email})"
                    );
                }else{
                    $results[]=array(
                        'id'=>$user->ID,
                        'text'=>"{$user->user_login}"
                    );
                }
            }
        }
         
        return $results;
    }
    
    public function admin_init(){
        require_once 'includes/admin/menus/class-xh-social-wechat-menu-auto-sync.php';
        $setting = XH_Social_Wechat_Menu_Auto_Sync::instance();
        $post_types = $setting->get_option('post_types',array());
        if(!$post_types||!is_array($post_types)){
            $post_types = array();
        }
        
        if($setting->get_option('enabled')!='yes'){
            return;
        }
        
        foreach ($post_types as $post_type){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }
    
    public function manage_posts_columns($existing_columns){
        $existing_columns['wechat_auto_sync']=__('Wechat auto sync',XH_SOCIAL);
        return $existing_columns;
    }

    public function ajax_url($action=null,$hash = false,$notice=false){
        $ps =array();
        $url = XH_Social_Helper_Uri::get_uri_without_params(home_url( '/?t='.time() ),$ps);
        $params = array();
        
        if($action){
            if(is_string($action)){
                $params['action']=$action;
            }else if(is_array($action)){
                $params=$action;
            }
        }
        
        if(isset($params['action'])&&!empty($params['action'])){
            if($notice){
                $params[$params['action']]=wp_create_nonce($params['action']);
            }
        }
        
        if($hash){
            $params['notice_str'] = str_shuffle(time());
            $params['hash'] = XH_Social_Helper::generate_hash($params, XH_Social::instance()->get_hash_key());
        }
        
        if(count($params)>0){
            $url.="?".http_build_query($params);
        }
        return $url;
    }
    
    public function manage_posts_custom_column($column,$post_ID){
        if($column!='wechat_auto_sync'){
            return;
        }
        
        require_once 'includes/class-wechat-material-fixed-pusher.php';
        $api = XH_Social_Channel_Wechat::instance();
        $crossdomain = null;
        if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
            $crossdomain = $api->get_option('mp_cross_domain_url');
        }
        $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
        
        $reponse =$pusher->get_cached_media(array($post_ID));
        $is_synced = !$reponse instanceof XH_Social_Error;
        ?>
        <div id="wechat-menu-sync-container-<?php echo $post_ID?>"></div>
        <script type="text/javascript">
			(function($){
				window.generate_wechat_sync_<?php echo $post_ID?>=function(is_synced){
					if(is_synced){
						$('#wechat-menu-sync-container-<?php echo $post_ID?>').html(
							   '<button class="button-primary" type="button" onclick="window.on_wechat_sync_refresh_<?php echo $post_ID?>();" id="btn-wechat-refresh-sync-<?php echo $post_ID?>">刷新同步</button>\
			           		 	<button class="button" type="button" onclick="window.on_wechat_sync_delete_<?php echo $post_ID?>();" id="btn-wechat-delete-sync-<?php echo $post_ID?>">删除同步</button>');
	           		 	return;
					}

					return $('#wechat-menu-sync-container-<?php echo $post_ID?>').html(
							'<button class="button-primary" type="button" onclick="window.on_wechat_sync_add_<?php echo $post_ID?>();" id="btn-wechat-sync-<?php echo $post_ID?>">立即同步</button>');
				};

				window.generate_wechat_sync_<?php echo $post_ID?>(<?php echo$is_synced?'true':'false';?>);

				window.on_wechat_sync_refresh_<?php echo $post_ID?>=function(){
					$('#wpbody-content').loading();
					$.ajax({
						url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$this->id}",'tab'=>'refresh_post_sync','post_ID'=>$post_ID),true,true)?>',
						type:'post',
						timeout:120*1000,
						async:true,
						cache:false,
						dataType:'json',
						complete:function(){
							$('#wpbody-content').loading('hide');
						},
						success:function(e){
							if(e.errcode!=0){
								alert(e.errmsg);
								return;
							}
							
							window.generate_wechat_sync_<?php echo $post_ID?>(true);
						},
						error:function(e){
							console.error(e.responseText);
							alert('<?php echo XH_Social_Error::err_code(500)->to_string(); ?>');
						}
					});
				};

				window.on_wechat_sync_delete_<?php echo $post_ID?>=function(){
					$('#wpbody-content').loading();
					$.ajax({
						url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$this->id}",'tab'=>'delete_post_sync','post_ID'=>$post_ID),true,true)?>',
						type:'post',
						timeout:120*1000,
						async:true,
						cache:false,
						dataType:'json',
						complete:function(){
							$('#wpbody-content').loading('hide');
						},
						success:function(e){
							if(e.errcode!=0){
								alert(e.errmsg);
								return;
							}
							
							window.generate_wechat_sync_<?php echo $post_ID?>(false);
						},
						error:function(e){
							console.error(e.responseText);
							alert('<?php echo XH_Social_Error::err_code(500)->to_string(); ?>');
						}
					});
				};

				window.on_wechat_sync_add_<?php echo $post_ID?>=function(){
					$('#wpbody-content').loading();
					$.ajax({
						url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$this->id}",'tab'=>'add_post_sync','post_ID'=>$post_ID),true,true)?>',
						type:'post',
						timeout:120*1000,
						async:true,
						cache:false,
						dataType:'json',
						complete:function(){
							$('#wpbody-content').loading('hide');
						},
						success:function(e){
							if(e.errcode!=0){
								alert(e.errmsg);
								return;
							}
							
							window.generate_wechat_sync_<?php echo $post_ID?>(true);
						},
						error:function(e){
							console.error(e.responseText);
							alert('<?php echo XH_Social_Error::err_code(500)->to_string(); ?>');
						}
					});
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function save_post($post_ID, $post, $update){
        require_once 'includes/admin/menus/class-xh-social-wechat-menu-auto-sync.php';
        $setting = XH_Social_Wechat_Menu_Auto_Sync::instance();
        $post_types = $setting->get_option('post_types',array());
        if(!$post_types||!is_array($post_types)){
            $post_types = array();
        }
        
        if(!$post||$setting->get_option('enabled')!='yes'||!in_array($post->post_type, $post_types)){
            return;
        }
        
        if(!isset($_REQUEST['tag_wechat_auto_sync'])||$_REQUEST['tag_wechat_auto_sync']!=$post_ID){
            return;
        }
        
        require_once 'includes/class-wechat-material-fixed-pusher.php';
        $api = XH_Social_Channel_Wechat::instance();
        $crossdomain = null;
        if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
            $crossdomain = $api->get_option('mp_cross_domain_url');
        }
        $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
        $response = $pusher->push_articles(array($post_ID));
        if($response instanceof XH_Social_Error){
            XH_Social_Log::error($response);
        }
    }
    
    public function edit_form_top($post){
        require_once 'includes/admin/menus/class-xh-social-wechat-menu-auto-sync.php';
        $setting = XH_Social_Wechat_Menu_Auto_Sync::instance();
        $post_types = $setting->get_option('post_types',array());
        if(!$post_types||!is_array($post_types)){
            $post_types = array();
        }
        
        if($post&&$setting->get_option('enabled')=='yes'&&in_array($post->post_type, $post_types)){
            ?><input type="hidden" name="tag_wechat_auto_sync" value="<?php echo $post->ID?>" /><?php
        }
    }
    
    public function _ajax($shortcodes){
        $shortcodes["xh_social_{$this->id}"]=array($this,'do_ajax');
        return $shortcodes;
    }
    
    public function generate_wechat_menu_edit_html($config = null,$context=null){
        return XH_Social::instance()->WP->requires($this->dir, 'wechat/menu-edit.php',array(
            'request'=>$config,
            'context'=>$context?$context:XH_Social_Helper::generate_unique_id()
        ));
    }
    
    public function generate_wechat_msg_html($config = null,$context=null){
        return XH_Social::instance()->WP->requires($this->dir, 'wechat/__msg.php',array(
            'request'=>$config,
            'context'=>$context?$context:XH_Social_Helper::generate_unique_id()
        ));
    }
    
    private function set_wechat_msg_reply($data){
        global $wpdb;
        $result = $wpdb->insert("{$wpdb->prefix}xh_social_channel_wechat_msg", $data);
        if(!empty($wpdb->last_error)){
            XH_Social_Log::debug($wpdb->last_error);
            return XH_Social_Error::error_custom($wpdb->last_error);
        }
        
        if(!$result){
            XH_Social_Log::debug("插入微信消息({$wpdb->prefix}xh_social_channel_wechat_msg)时发生不可预测的错误！".print_r($wpdb,true));
            return XH_Social_Error::error_unknow();
        }
        
        return XH_Social_Error::success();
    }
    
    public function do_ajax(){
        
        
        $tab = isset($_REQUEST['tab'])?$_REQUEST['tab']:'';
        $action ="xh_social_{$this->id}";
        $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>null,
            $action=>null,
            'tab'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));

        if(isset($_REQUEST['post_ID'])){
            $request['post_ID']=$_REQUEST['post_ID'];
        }
       
        if(empty($request['notice_str'])
            ||empty($request['action'])
            ||empty($request[$action])
            ||empty($request['tab'])
            ||empty($request['hash'])
            ||$action!=$request['action']
            ){
            return;
        }
        
        $validate =XH_Social::instance()->WP->ajax_validate($request,$request['hash'],true);
        if(!$validate){
            return;
        }

        set_time_limit(120);
        require_once 'class-wechat-model-sync.php';
        switch ($tab){
            case 'wechat_msg_restore':
                global $wpdb;
                $msg_id = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $msg = $wpdb->get_row(
                    "select m.*
                    from {$wpdb->prefix}xh_social_channel_wechat_msg m
                    where m.id = $msg_id
                    limit 1;");
                if(!$msg){
                    echo XH_Social_Error::err_code(404)->to_json();
                    exit;
                }
                
                XH_Social_Wechat_Msg_Handler::update($msg_id, 'restore');
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'wechat_msg_delete':
                global $wpdb;
                $msg_id = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $msg = $wpdb->get_row(
                    "select m.*
                    from {$wpdb->prefix}xh_social_channel_wechat_msg m
                    where m.id = $msg_id
                    limit 1;");
                if(!$msg){
                    echo XH_Social_Error::err_code(404)->to_json();
                    exit;
                }
            
                XH_Social_Wechat_Msg_Handler::update($msg_id, 'delete');
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'wechat_msg_trash':
                global $wpdb;
                $msg_id = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $msg = $wpdb->get_row(
                   "select m.*
                    from {$wpdb->prefix}xh_social_channel_wechat_msg m
                    where m.id = $msg_id
                    limit 1;");
                if(!$msg){
                    echo XH_Social_Error::err_code(404)->to_json();
                    exit;
                }
            
                XH_Social_Wechat_Msg_Handler::update($msg_id, 'trash');
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'wechat_msg_reply':
                global $wpdb;
                $msg_id = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $msg = $wpdb->get_row(
                    "select m.*
                    from {$wpdb->prefix}xh_social_channel_wechat_msg m
                    where m.id = $msg_id
                    limit 1;");
                if(!$msg){
                    echo XH_Social_Error::err_code(404)->to_json();
                    exit;
                }
                
                $request = shortcode_atts(array(
                    'msg_type'=>null,
                    'msg_content'=>null
                ), stripslashes_deep($_REQUEST)) ;

                require_once 'includes/class-wechat-service-msg-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Service_Msg_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                
                switch($request['msg_type']){
                    //图文消息
                    case 'tw':
                        $post_datas = json_decode($request['msg_content'],true);
                        $_post_ids = array();
                        if($post_datas&&is_array($post_datas)){
                            foreach ($post_datas as $post_data){
                                $_post_id = isset($post_data['ID'])? intval($post_data['ID']):0;
                                if($_post_id>0){
                                    $_post_ids[]=$_post_id;
                                }
                            }
                        }
                         
                        if(count($_post_ids)<1||count($_post_ids)>8){
                            echo XH_Social_Error::error_custom('图文消息:一个图文消息支持1到8条图文')->to_json();
                            exit;
                        }
                
                        $response = $pusher->push_articles($msg->openid, $_post_ids);
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();exit;
                        }
                        
                        echo $this->set_wechat_msg_reply(array(
                            'parent_id'=>$msg->id,
                            'msg_id'=>null,
                            'openid'=>null,
                            'user_ID'=>get_current_user_id(),
                            'user_info'=>null,
                            'content'=>json_encode($_post_ids),
                            'msg_type'=>'mpnews',
                            'created_time'=>time(),
                            'status'=>'publish'
                        ))->to_json();
                        exit;
                        //文本消息
                    case 'txt':
                        global $wpdb;
                        require_once 'includes/emoji-editor/class-emoji-editor.php';
                       
                        $response = $pusher->push_text($msg->openid, XH_Social_Emoji_Editor::html_to_text($request['msg_content']));
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();exit;
                        }
                        
                        echo $this->set_wechat_msg_reply(array(
                            'parent_id'=>$msg->id,
                            'msg_id'=>null,
                            'openid'=>null,
                            'user_ID'=>get_current_user_id(),
                            'user_info'=>null,
                            //json_encode 转义表情符，方便存储
                            'content'=>json_encode($request['msg_content']),
                            'msg_type'=>'text',
                            'created_time'=>time(),
                            'status'=>'publish'
                        ))->to_json();
                        exit;
                        //多媒体消息
                    case 'img':
                        $post = json_decode($request['msg_content'],true);
                        $post_ID =isset($post['ID'])?intval($post['ID']):0;
                
                        $response = $pusher->push_media($msg->openid, $post_ID);
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();exit;
                        }
                        
                        echo $this->set_wechat_msg_reply(array(
                            'parent_id'=>$msg->id,
                            'msg_id'=>null,
                            'openid'=>null,
                            'user_ID'=>get_current_user_id(),
                            'user_info'=>null,
                            'content'=>$response['source_url'],
                            'msg_type'=>$response['msg_type'],
                            'created_time'=>time(),
                            'status'=>'publish'
                        ))->to_json();
                        exit;
                    default:
                        echo XH_Social_Error::error_custom('错误的消息类型!')->to_json();
                        exit;
                }
            case 'wechat_msg_view':
                global $wpdb;
                $msg_id = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $msg = $wpdb->get_row(
                   "select m.*
                    from {$wpdb->prefix}xh_social_channel_wechat_msg m
                    where m.id = $msg_id
                    limit 1;");
                if(!$msg){
                    echo XH_Social_Error::err_code(404)->to_json();
                    exit;
                }
              
                switch($msg->msg_type){
                    case 'text':
                        echo XH_Social_Error::success("<div>{$msg->content}</div>")->to_json();
                        exit;
                    case 'image':
                        $content = json_decode($msg->content,true);
                        if(!$content||!is_array($content)){$content=array();}
                        ob_start();
                        ?> <img style="max-width:100px;max-height:100px;" src="<?php echo isset($content['pic_url'])?$content['pic_url']:null;?>" /><?php 
                        echo XH_Social_Error::success(ob_get_clean())->to_json();
                        exit;
                    case 'voice':
                        $content = json_decode($msg->content,true);
                        if(!$content||!is_array($content)){$content=array();}
                        if(!isset( $content['source_url'])||empty( $content['source_url'])){
                            require_once 'includes/class-wechat-material-temp-pusher.php';
                            $api = XH_Social_Channel_Wechat::instance();
                            $crossdomain = null;
                            if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                                $crossdomain = $api->get_option('mp_cross_domain_url');
                            }
                            $pusher = new XH_Social_Wechat_Material_Temp_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                            $media = $pusher->get_temp_media($content['media_id']);  
                            if($media instanceof XH_Social_Error){
                                echo $media->to_json();
                                exit;
                            }
                           
                            $_config =wp_get_upload_dir();
                            $_filename = '/'.time().'.amr';
                            $filename = $_config['path'].$_filename;
                            $result = @file_put_contents($filename, $media);
                            if($result===false){
                                echo XH_Social_Error::error_custom(__('Get voice source failed,detail error:save voice source into system failed',XH_SOCIAL))->to_json();
                                exit;
                            }
                            
                            $content['source_url'] =$_config['url'].$_filename;
                            $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_msg", array(
                                'content'=>json_encode($content)
                            ), array(
                                'id'=>$msg->id
                            ));
                        }
                        
                        $context = XH_Social_Helper::generate_unique_id();
                        ob_start();
                        ?><input type="button" value="play" class="button-primary" id="playId-<?php echo $context?>"/>
						<input type="button" value="stop" class="button-primary" id="stopId-<?php echo $context?>"/>
                        <script type="text/javascript">
                            RongIMLib.RongIMVoice.init();
                            document.getElementById("playId-<?php echo $context?>").onclick = function(){
                                RongIMLib.RongIMVoice.play("<?php echo $content['source_url'];?>");
                            };
                            document.getElementById("playId-<?php echo $context?>").onclick = function(){
                                RongIMLib.RongIMVoice.stop();
                            };
                            </script>
                        
                        <?php 
                        echo XH_Social_Error::success(ob_get_clean())->to_json();
                        exit;
                    case 'shortvideo':
                    case 'video':
                        $content = json_decode($msg->content,true);
                        if(!$content||!is_array($content)){$content=array();}
                        if(!isset( $content['source_url'])||empty( $content['source_url'])){
                            require_once 'includes/class-wechat-material-temp-pusher.php';
                            $api = XH_Social_Channel_Wechat::instance();
                            $crossdomain = null;
                            if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                                $crossdomain = $api->get_option('mp_cross_domain_url');
                            }
                            $pusher = new XH_Social_Wechat_Material_Temp_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                            $media = $pusher->get_temp_media($content['media_id']);
                            if($media instanceof XH_Social_Error){
                                echo $media->to_json();
                                exit;
                            }
                            
                            $_config =wp_get_upload_dir();
                            $_filename = '/'.time().'.mp4';
                            $filename = $_config['path'].$_filename;
                            $result = @file_put_contents($filename, $media);
                            if($result===false){
                                echo XH_Social_Error::error_custom(__('Get voice source failed,detail error:save voice source into system failed',XH_SOCIAL))->to_json();
                                exit;
                            }
                            $content['source_url'] =$_config['url'].$_filename;
                            $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_msg", array(
                                'content'=>json_encode($content)
                            ), array(
                                'id'=>$msg->id
                            ));
                        }
                        
                        ob_start();
                        ?>
                        <video controls style="min-width:100px;min-height:100px;max-width:150px;max-height:150px;" src="<?php echo $content['source_url'];?>" poster="<?php echo wp_guess_url().'/wp-includes/images/media/video.png';?>"></video>
                        <?php 
                        echo XH_Social_Error::success(ob_get_clean())->to_json();
                        exit;
                    case 'location':
                        $content = json_decode($msg->content,true);
                        if(!$content||!is_array($content)){$content=array();}
                        ob_start();
                        ?>位置：<?php echo isset($content['label'])?$content['label']:null;?>(x:<?php echo isset($content['x'])?$content['x']:null;?>,y:<?php echo isset($content['y'])?$content['y']:null;?>,scale:<?php echo isset($content['scale'])?$content['scale']:null;?>) <?php 
                        echo XH_Social_Error::success(ob_get_clean())->to_json();
                        exit;
                    case 'link':
                        $content = json_decode($msg->content,true);
                        if(!$content||!is_array($content)){$content=array();}
                        ob_start();
                        ?><a target="_blank" href="<?php echo isset($content['url'])?$content['url']:null; ?>" title="<?php echo isset($content['title'])?$content['title']:null; ?>"><?php echo isset($content['url'])?$content['url']:null; ?></a><?php
                        echo XH_Social_Error::success(ob_get_clean())->to_json();
                        exit;
                }
                
            case 'wsocial_keywords_add_msg':
                $context = XH_Social_Helper::generate_unique_id();
                echo XH_Social_Error::success(array(
                    'context'=>$context,
                    'html'=>$this->generate_wechat_msg_html(array(),$context)
                ))->to_json();
                exit;
            case 'push_msg_mass':
            case 'preview_msg_mass':
                $request = shortcode_atts(array(
                    'msg_type'=>null,
                    'msg_content'=>null
                ), stripslashes_deep($_REQUEST)) ;
               
                require_once 'includes/class-wechat-msg-mass-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Msg_Mass_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                
                switch($request['msg_type']){
                    //图文消息
                    case 'tw':
                        $post_datas = json_decode($request['msg_content'],true);
                        $_post_ids = array();
                        if($post_datas&&is_array($post_datas)){
                            foreach ($post_datas as $post_data){
                                $_post_id = isset($post_data['ID'])? intval($post_data['ID']):0;
                                if($_post_id>0){
                                    $_post_ids[]=$_post_id;
                                }
                            }
                        }
                       
                        if(count($_post_ids)>8){
                            echo XH_Social_Error::error_custom('图文消息:一个图文消息支持1到8条图文')->to_json();
                            exit;
                        }
        
                        $response=null;
                        if($tab=='push_msg_mass'){
                            $response = $pusher->push_articles($_post_ids);
                        }else{
                            $user_id = isset($_REQUEST['user_ID'])?intval($_REQUEST['user_ID']):0;
                            $ext_user =class_exists('XH_Social_Channel_Wechat')&&$user_id>0? XH_Social_Channel_Wechat::instance()->get_ext_user_info_by_wp($user_id):null;
                            if(!$ext_user||empty($ext_user['mp_openid'])){
                                echo  XH_Social_Error::error_custom('当前预览用户未绑定微信，请重试！')->to_json();
                                exit;
                            }
                            
                            $response = $pusher->preview_articles($ext_user['mp_openid'], $_post_ids);
                        }
                        
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();
                            exit;
                        }
                        
                        echo XH_Social_Error::success()->to_json();
                        exit;
                        
                        //文本消息
                    case 'txt':
                        require_once 'includes/emoji-editor/class-emoji-editor.php';
                        global $wpdb;
                        $response=null;
                        if($tab=='push_msg_mass'){
                            $response = $pusher->push_text(XH_Social_Emoji_Editor::html_to_text($request['msg_content']));
                        }else{
                            $user_id = isset($_REQUEST['user_ID'])?intval($_REQUEST['user_ID']):0;
                            $ext_user =class_exists('XH_Social_Channel_Wechat')&&$user_id>0? XH_Social_Channel_Wechat::instance()->get_ext_user_info_by_wp($user_id):null;
                            if(!$ext_user||empty($ext_user['mp_openid'])){
                                echo XH_Social_Error::error_custom('当前预览用户未绑定微信，请重试！')->to_json();
                                exit;
                            }
                            require_once 'includes/emoji-editor/class-emoji-editor.php';
                            
                            $response = $pusher->preview_text($ext_user['mp_openid'], XH_Social_Emoji_Editor::html_to_text($request['msg_content']));
                        }
                        
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();
                            exit;
                        }
                        
                        echo XH_Social_Error::success()->to_json();
                        exit;
                        //多媒体消息
                    case 'img':
                        $post = json_decode($request['msg_content'],true);
                        $post_ID =isset($post['ID'])?intval($post['ID']):0;
                        
                        $response=null;
                        if($tab=='push_msg_mass'){
                            $response = $pusher->push_media($post_ID);
                        }else{
                            $user_id = isset($_REQUEST['user_ID'])?intval($_REQUEST['user_ID']):0;
                            $ext_user =class_exists('XH_Social_Channel_Wechat')&&$user_id>0? XH_Social_Channel_Wechat::instance()->get_ext_user_info_by_wp($user_id):null;
                            if(!$ext_user||empty($ext_user['mp_openid'])){
                                 echo XH_Social_Error::error_custom('当前预览用户未绑定微信，请重试！')->to_json();
                                exit;
                            }
                            
                            $response = $pusher->preview_media($ext_user['mp_openid'],$post_ID);
                        }
                        
                        if($response instanceof XH_Social_Error){
                            echo $response->to_json();
                            exit;
                        }
                        
                        echo XH_Social_Error::success()->to_json();
                        exit;
                    default:
                        echo XH_Social_Error::error_custom('错误的消息类型!')->to_json();
                        exit;
                }
                
            case 'add_menu_tw_post':
                $post_ID = isset($_REQUEST['id'])?intval($_REQUEST['id']):0;
                $post = $post_ID?get_post($post_ID):null;
                if(!$post){
                    echo (XH_Social_Error::err_code(404)->to_json());
                    exit;
                }
                
                $url =get_the_post_thumbnail_url( $post,array(360,200));
                if(empty($url)){
                    echo (XH_Social_Error::error_custom(__('Post\'s feature image is required!',XH_SOCIAL))->to_json());
                    exit;
                }
                echo XH_Social_Error::success(array(
                    'ID'=>$post->ID,
                    'post_title'=>$post->post_title,
                    'img'=> $url
                ))->to_json();
                exit;
            case 'push_articles':
                $post_datas = isset($_REQUEST['posts'])?json_decode(stripslashes($_REQUEST['posts']),true):null;
                $post_ids = array();
                if($post_datas){
                    foreach ($post_datas as $post_data){
                        $post_id = isset($post_data['ID'])?intval($post_data['ID']):0; 
                        if($post_id>0){
                            $post_ids[]=$post_id;
                        }
                    }
                }
                
                require_once 'includes/class-wechat-material-fixed-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                $response = $pusher->push_articles($post_ids);
                if($response instanceof XH_Social_Error){
                    echo XH_Social_Error::error_custom("推送文章微信同步时发生异常:{$response->to_string()}")->to_json();
                    exit;
                }
                
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'refresh_post_sync':
                $post_ID = $request['post_ID'];
                require_once 'includes/class-wechat-material-fixed-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                $media_id = $pusher->get_cached_media(array($post_ID));
                if($media_id instanceof XH_Social_Error){
                    echo XH_Social_Error::error_custom("获取文章微信同步 media_id时发生异常:{$response->to_string()}")->to_json();  
                    exit;
                }
                
                $media =  $pusher->get_fixed_media($media_id);
                if($media instanceof XH_Social_Error){
                    echo XH_Social_Error::error_custom("获取文章微信同步 media_id时发生异常:{$response->to_string()}")->to_json();  
                    exit;
                }
                
                $response = $pusher->update_article($media_id, $post_ID,0);
                if($response instanceof XH_Social_Error){
                    echo XH_Social_Error::error_custom("更新文章微信同步时发生异常:{$response->to_string()}")->to_json();
                    exit;
                }
                
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'add_post_sync':
                $post_ID = $request['post_ID'];
                require_once 'includes/class-wechat-material-fixed-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                $response = $pusher->push_articles(array($post_ID));
                if($response instanceof XH_Social_Error){
                    echo XH_Social_Error::error_custom("创建文章微信同步时发生异常:{$response->to_string()}")->to_json();
                    exit;
                }
                
                echo XH_Social_Error::success()->to_json();
                exit;
            case 'delete_post_sync':
                $post_ID = $request['post_ID'];
                require_once 'includes/class-wechat-material-fixed-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                echo $pusher->remove_fixed_media_by_post(array($post_ID))->to_json();
                exit;
            case 'create_menu':
                echo XH_Social_Error::success($this->generate_wechat_menu_edit_html())->to_json();
                exit;
            case 'push_menu':
            case 'save_menu':
               $menus = isset($_REQUEST['menus'])?json_decode(stripcslashes($_REQUEST['menus']),true):null;
               if(!$menus||count($menus)==0){
                   echo XH_Social_Error::err_code(600)->to_json();exit;
               }
               
               $buttons = array();
               if(count($menus)>3){
                   echo XH_Social_Error::error_custom("发布菜单时出错：定义菜单最多包括3个一级菜单!")->to_json();
                   exit;
               }
               
               require_once 'includes/admin/menus/class-xh-social-wechat-menu-edit.php';
               require_once 'includes/emoji-editor/class-emoji-editor.php';
               
               XH_Social_Wechat_Menu_Edit::instance()->update_option('menus', json_encode($menus));
               
               if($tab=='push_menu'){
                   foreach ($menus as $menu){
                       if(isset($menu['name'])){
                           $menu['name'] = XH_Social_Emoji_Editor::html_to_text($menu['name']);
                       }
                       
                       if(!isset($menu['name'])||empty($menu['name'])|| strlen($menu['name'])>16){
                           echo XH_Social_Error::error_custom("发布菜单[{$menu['name']}]时出错：菜单名称不能为空且不能超过16个字节(4个汉字)!")->to_json();
                           exit;
                       }
                     
                       $button=array(
                           'name'=>$menu['name']
                       );
                       
                       //第一级
                       if(isset($menu['children'])&&$menu['children']&&count($menu['children'])>0){
                           if(count($menu['children'])>5){
                               echo XH_Social_Error::error_custom("发布菜单[{$menu['name']}]时出错：每个一级菜单最多包含5个二级菜单!")->to_json();
                               exit;
                           }
                           
                           $button['sub_button']=array();
                           foreach ($menu['children'] as $child){
                               if(isset($child['name'])){
                                   $child['name'] = XH_Social_Emoji_Editor::html_to_text($child['name']);
                               }
                               
                               if(empty($child['name'])|| strlen($child['name'])>60){
                                   echo XH_Social_Error::error_custom("发布菜单[{$child['name']}]时出错：菜单名称不能为空且不能超过60个字节(7个汉字)!")->to_json();
                                   exit;
                               }
                               
                               $sub_button = array(
                                   'name'=>$child['name']
                               );
                               
                               $result = $this->create_wechat_menu($sub_button,$child);
                               if($result instanceof XH_Social_Error){
                                   echo XH_Social_Error::error_custom(sprintf("发布菜单[{$child['name']}]时出错：%s",$result->errmsg))->to_json();
                                   exit;
                               }
                               $button['sub_button'][]=$sub_button;
                           }
                       }else{
                           $result = $this->create_wechat_menu($button,$menu);
                           if($result instanceof XH_Social_Error){
                               echo XH_Social_Error::error_custom(sprintf("发布菜单[{$menu['name']}]时出错：%s",$result->errmsg))->to_json();
                               exit;
                           }
                       }
                       
                       $buttons[]=$button;
                   }
               
                   require_once 'includes/class-wechat-menu-pusher.php';
                   $api = XH_Social_Channel_Wechat::instance();
                   $crossdomain = null;
                   if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                       $crossdomain = $api->get_option('mp_cross_domain_url');
                   }
                   $pusher = new XH_Social_Wechat_Menu_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                   $response = $pusher->push_menu($buttons);
                   if($response instanceof XH_Social_Error){
                       echo $response->to_json();exit;
                   }
               }
               
               echo XH_Social_Error::success()->to_json();
               exit;
        }
    }
    
    public function set_wechat_event_cache($cache_id,$msg_type,$content){
        global $wpdb;
        $event =$wpdb->get_row(
            "select *
            from {$wpdb->prefix}xh_social_channel_wechat_event
            where id = '{$cache_id}'
                  and msg_type='$msg_type'
            limit 1;");
         
        if(!$event){
            $row = $wpdb->insert("{$wpdb->prefix}xh_social_channel_wechat_event", array(
                'id'=>$cache_id,
                'msg_type'=>$msg_type,
                'content'=>$content
            ));
             
            if(!empty($wpdb->last_error)){
                return XH_Social_Error::error_custom(sprintf('生成微信菜单事件时发生异常：插入事件时发生错误!详细错误:%s',$wpdb->last_error));
            }
             
            if(!$row){
                return XH_Social_Error::error_custom('生成微信菜单事件时发生异常：插入事件时发生错误!');
            }
        }
        
        return true;
    }
    
    /**
     * 创建微信图文消息
     * 返回 click media_id两种消息类型（TODO:若新增第三种消息类型，请同步修改消息自动回复）
     * @param array $menu
     * @param array $request
     * @param array $ext_p
     * @return XH_Social_Error|XH_Social_Error
     */
    public function create_wechat_menu_tw(&$menu,array $request,&$ext_p=array()){
        switch($request['msg_type']){
            //图文消息
            case 'tw':
                $post_datas = json_decode($request['msg_content'],true);
                $_post_ids = array();
                if($post_datas&&is_array($post_datas)){
                    foreach ($post_datas as $post_data){
                        $_post_id = isset($post_data['ID'])? intval($post_data['ID']):0;
                        if($_post_id>0){
                            $_post_ids[]=$_post_id;
                        }
                    }
                }
        
                if(count($_post_ids)<1||count($_post_ids)>8){
                    return XH_Social_Error::error_custom('图文消息:一个图文消息支持1到8条图文');
                }
        
                $msg_type ='articles';
                $cache_id = md5($msg_type.join(',', $_post_ids)) ;
                $response =$this->set_wechat_event_cache($cache_id,$msg_type,json_encode($_post_ids));
                if($response instanceof XH_Social_Error){
                    return $response;
                }
        
                $menu['type'] = 'click';
                $menu['key'] = "_INNER_{$cache_id}";
                break;
                //文本消息
            case 'txt':
                global $wpdb;
                $msg_type='text';
                $cache_id = md5($msg_type.$request['msg_content']);
                $response =$this->set_wechat_event_cache($cache_id,$msg_type,$request['msg_content']);
                if($response instanceof XH_Social_Error){
                    return $response;
                }
        
                $menu['type'] = 'click';
                $menu['key'] = "_INNER_{$cache_id}";
                break;
                //多媒体消息
            case 'img':
                require_once 'includes/class-wechat-material-fixed-pusher.php';
                $api = XH_Social_Channel_Wechat::instance();
                $crossdomain = null;
                if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
                    $crossdomain = $api->get_option('mp_cross_domain_url');
                }
                $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
                $post = json_decode($request['msg_content'],true);
                $response = $pusher->push_fixed_media(isset($post['ID'])?intval($post['ID']):0);
                if($response instanceof XH_Social_Error){
                    return $response;
                }
          
                $ext_p['media_type'] = $pusher->get_meida_type($response['mime_type']);
                
                $menu['type'] = 'media_id';
                $menu['media_id'] =$response['media_id'];
                break;
            default:
                return XH_Social_Error::error_custom('错误的消息类型!');
        }
        
        return $menu;
    }
    
    public function create_wechat_menu(&$menu,array $request){
        $request = shortcode_atts(array(
            'menu_type'=>null,
            'msg_type'=>null,
            'msg_content'=>null
        ), $request) ;
        
        switch($request['menu_type']){
            case 'msg':
                return $this->create_wechat_menu_tw($menu,$request);
                //菜单自定义点击事件
            case 'event':
                $menu['type'] = 'click';
                $menu['key'] = $request['msg_content'];
                break;
                //小程序
            case 'app':
                $menu['type'] = 'miniprogram';
                $menu['url'] = home_url('/');
        
                $_data = explode(',', $request['msg_content']);
                if(count($_data)!=2){
                    return XH_Social_Error::error_custom('小程序格式为：appid,启动页');
                }
        
                $menu['appid']=$_data[0];
                $menu['pagepath']=$_data[1];
                break;
                //跳转链接
            case 'link':
                $menu['type'] = 'view';
                $menu['url'] = $request['msg_content'];
                break;
            default:
                return XH_Social_Error::error_custom('错误的菜单类型!');
        }
         
        return $menu;
    }
    
    /**
     * @param array $data
     * @param XH_Social_Wechat_Msg_Receiver $handler
     */
    public function wechat_receive_event_click_get_newest_posts_8($data,$handler){
        global $wpdb;
        $posts = $wpdb->get_results(
           "select p.* 
            from {$wpdb->prefix}posts p
            where p.post_type='post'
                  and p.post_status='publish'
            order by p.ID desc
            limit 8;");
        
        $_posts = array();
        if($posts){
            foreach ($posts as $_p){
                $_posts[]=new WP_Post($_p);
            }
        }
        
        $handler->response_articles($_posts);
    }
    
    public function wechat_receive_event_click_get_newest_products_8($data,$handler){
        global $wpdb;
        $posts = $wpdb->get_results(
           "select p.*
            from {$wpdb->prefix}posts p
            where p.post_type='product'
                and p.post_status='publish'
                order by p.ID desc
            limit 8;");
    
        $_posts = array();
        if($posts){
            foreach ($posts as $_p){
                $_posts[]=new WP_Post($_p);
            }
        }
    
        $handler->response_articles($_posts);
    }
    
    /**
     * @param array $data
     * @param XH_Social_Wechat_Msg_Receiver $handler
     */
    public function wechat_receive_msg($data,$handler){    
        if($data['MsgType']!='text'){
            return;
        }
        
        $msg = $data['Content'];
        
        //关注时回复内容
        require_once 'includes/admin/menus/class-xh-social-wechat-menu-msg-keywords-reply.php';
        if('yes'!=XH_Social_Wechat_Menu_Msg_Keywords_Reply::instance()->get_option('enabled')){
            return;
        }
        $config = XH_Social_Wechat_Menu_Msg_Keywords_Reply::instance()->get_option('keywords_reply');
        $config = $config?json_decode($config,true):array();
        if(!$config||!is_array($config)){$config=array();}
        
        /*
         * <option value="0">完全全匹配</option>\
			<option value="1">关键字开始</option>\
			<option value="2">关键字结尾</option>\
			<option value="3">包含关键字</option>\
			<option value="4">不包含关键字</option>\
         * */
       
        foreach ($config as $item){
            $allowed = false;
           
            foreach (explode("\n", $item['keywords']) as $keywords){
                switch ($item['match']){
                    case '0':
                        $allowed = strcasecmp($msg, $keywords)===0;
                        break;
                    case '1':
                        $allowed = strlen($keywords)===0 || stripos($msg, $keywords)===0;
                        break;
                    case '2':
                        $length = strlen($keywords);
                        if($length === 0){
                            $allowed = true;
                            break;
                        }
                        
                        $allowed =  strcasecmp(substr($msg, -$length), $keywords)===0;
                        break;
                    case '3':
                        $allowed = strlen($keywords)===0 || stripos($msg, $keywords)!==false;
                        break;
                        
                    case '4':
                        $allowed = strlen($keywords)!==0 && stripos($msg, $keywords)===false;
                        break;
                }
                if($allowed){break;}
            }
            
            if(!$allowed){continue;}
            
            $config = $item['config'];
            if(isset($config['msg'])&&$config['msg']){
                switch ($config['msg']['type']){
                    case 'click':
                        $this->wechat_event_response($handler,$config['msg']['key']);
                        break;
                    case 'media_id':
                        $responser = new XH_Social_Wechat_Msg_Responser($data);
                        $responser->response_media($config['msg']['media_type'], $config['msg']['media_id']);
                        break;
                }
            }
        }
    }
    
    public function wechat_receive_event($data,$handler){
        if(!isset($data['Event'])){
            return;
        }
    
        switch ($data['Event']){
            case 'subscribe':
                if(isset($data['EventKey'])&&!empty($data['EventKey'])){
                    $this->on_scan_qrcode_subscribe($handler,$data['EventKey'],$data['FromUserName']);
                }break;
            case 'SCAN':
                if(isset($data['EventKey'])&&!empty($data['EventKey'])){
                    $this->on_scan_qrcode_subscribe($handler,$data['EventKey'],$data['FromUserName']);
                }
    
                break;
        }
    }
    
    
    /**
     * @param array $data
     * @param XH_Social_Wechat_Msg_Receiver $handler
     */
    public function wechat_receive_event_reply($data,$handler){
        if(!isset($data['Event'])){
            return;
        }
        
        switch ($data['Event']){
            case 'subscribe':
                //关注时回复内容
                require_once 'includes/admin/menus/class-xh-social-wechat-menu-msg-subscribe-reply.php';
                if('yes'==XH_Social_Wechat_Menu_Msg_Subscribe_Reply::instance()->get_option('enabled')){
                    $config = XH_Social_Wechat_Menu_Msg_Subscribe_Reply::instance()->get_option('subscribe_reply');
                    $config = $config?json_decode($config,true):array();
                    if(!$config||!is_array($config)){$config=array();}
                 
                    if(isset($config['msg'])&&$config['msg']){
                       switch ($config['msg']['type']){
                           case 'click':
                               $this->wechat_event_response($handler,$config['msg']['key']);
                               break;
                           case 'media_id':
                               $responser = new XH_Social_Wechat_Msg_Responser($data);
                               $responser->response_media($config['msg']['media_type'], $config['msg']['media_id']);
                               break;
                       }
                    }
                }
                
                //关注时回复内容 END
                
                do_action('xh_social_channel_wechat_receive_event_subscribe',$data,$handler);
                break;
            case 'SCAN': 
                do_action('xh_social_channel_wechat_receive_event_scan',$data,$handler);
                break;
            case 'CLICK':
                $this->wechat_event_response($handler,$data['EventKey']);
                
                $actions = $this->get_menu_events();
                if(isset($actions[$data['EventKey']])){
                    do_action("wsocial_wechat_receive_event_click_{$data['EventKey']}",$data,$handler);
                }
                break;
        }
    }
    
    private function wechat_event_response($handler,$event_key){
        if(strpos($event_key, '_INNER_')===0){
            global $wpdb;
            $msg_id = substr($event_key, 7);
            $event =$wpdb->get_row(
                "select *
                from {$wpdb->prefix}xh_social_channel_wechat_event
                where id = '{$msg_id}'
                limit 1;");
            if($event){
                switch($event->msg_type){
                    case 'text':
                        require_once 'includes/emoji-editor/class-emoji-editor.php';
                        $handler->response_txt(XH_Social_Emoji_Editor::html_to_text($event->content));
                        break;
                    case 'articles':
                        $post_IDs = json_decode($event->content,true);
                        $posts = array();
                        foreach ($post_IDs as $post_ID){
                            $post = get_post($post_ID);
                            if($post&&$post->post_status=='publish'){
                                $posts[]=$post;
                            }
                        }
       
                        if(count($posts)==0){
                            return;
                        }
                        $handler->response_articles($posts);
                        break;
                }
                 
            }
        }
    }
    
    /**
     * 
     * @param XH_Social_Wechat_Msg_Receiver $handler
     * @param string $uid
     * @param string $openid
     * @throws Exception
     */
    private function on_scan_qrcode_subscribe($handler,$uid,$openid){
        if(empty($uid)){
            return;
        }
    
        if(strpos($uid, 'qrscene_')===0){
            $uid = substr($uid,8 );
        }
    
        $api =XH_Social_Channel_Wechat::instance();
        require_once 'includes/class-wechat-user.php';
        $crossdomain = null;
        if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
            $crossdomain = $api->get_option('mp_cross_domain_url');
        }
        $user_handler = new XH_Social_Wechat_User($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
        $user_info = $user_handler->get_user($openid);
        if($user_info instanceof XH_Social_Error){
            $user_info = array(
                'openid'=>$openid
            );
        }
    
        do_action('wsocial_wechat_on_subscribe',$uid,$user_info);
        
        try {
            global $wpdb;
            $queue =$wpdb->get_row($wpdb->prepare(
                "select id,
                        user_id
                from {$wpdb->prefix}xh_social_channel_wechat_queue
                where id=%s
                limit 1;", $uid));
          
            if(!$queue){
                return;
            }
    
            $ext_user_id = XH_Social_Channel_Wechat::instance()->create_ext_user_info('mp',$user_info,$queue->user_id, XH_Social_Helper_String::guid());
             
            $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_queue", array(
                'ext_user_id'=>$ext_user_id
            ), array(
                'id'=>$uid
            ));
   
            if(!empty($wpdb->last_error)){
                throw new Exception($wpdb->last_error,500);
            }
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            $msg =$e->getMessage();
            if($e->getCode()==500){
                $msg= XH_Social_Error::err_code(500)->errmsg;
            }
            $handler->response_txt($msg);
            exit;
        }
    }
    
    public function get_menu_events(){
        $events = array(
            'newest_posts_8'=>'获取最新8条新闻'
        );
        
        if(class_exists('WooCommerce')){
           $events['newest_products_8'] ='获取最新8条产品信息';
        }
        
        return apply_filters('wsocial_wechat_sync_menu_events', $events);
    }
    
    public function wsocial_wechat_qrcode_content($empty,$login_type,$wp_user_id){
        if($login_type!=1){
            return $empty;
        }
        
        global $wpdb;
        $wpdb->insert("{$wpdb->prefix}xh_social_channel_wechat_queue", array(
            'created_date'=>date_i18n('Y-m-d H:i:s'),
            'ip'=>$_SERVER["REMOTE_ADDR"],
            'user_id'=>$wp_user_id
        ));
        
        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            return XH_Social_Error::err_code(500);
        }
        
        $queue_id = $wpdb->insert_id;
         
        require_once 'includes/class-wechat-qrcode.php';
        
        $api =XH_Social_Channel_Wechat::instance();
        $crossdomain = null;
        if('mp_cross_domain_enabled'==$api->get_option('mp_enabled_cross_domain')){
            $crossdomain = $api->get_option('mp_cross_domain_url');
        }
        $handler = new XH_Social_Wechat_Qrcode($api->get_option('mp_id'),$api->get_option('mp_secret'),$crossdomain);
        $code =$handler->create($wp_user_id,$queue_id);
         
        if($code instanceof XH_Social_Error){
            return $code;
        }
        
        $qrcode=$code['url'];
        $uid = $code['uid'];
        
        return array(
            'qrcode'=>$qrcode,
            'uid'=>$uid
        );
    }
    
    public function wsocial_wechat_qrcode_connect($login_type,$wp_user_id,$ext_mp_user){
        if($login_type!=1){
            return;
        }
        
        global $wpdb;
        if(!$ext_mp_user->ext_user_id){
            echo XH_Social_Error::err_code(404)->to_json();
            exit;
        }
        
        $api = XH_Social_Channel_Wechat::instance();
        if($wp_user_id>0){
            $wp_user =$api->get_wp_user_info($ext_mp_user->ext_user_id);
            if(!$wp_user||$wp_user->ID!=$wp_user_id){
                //未知错误！！
                $error = new XH_Social_Error(701,'logon user_id not equals to request data');
                echo $error->to_json();
                exit;
            }
        
            $error = XH_Social::instance()->WP->do_wp_login($wp_user);
            if(!$error instanceof XH_Social_Error){
                $error=XH_Social_Error::success();
            }
        
            $error = apply_filters('wsocial_login_succeed', $error,$wp_user);
            echo $error->to_json();
            exit;
        }
        
        $redirect_uri = $api->process_login($ext_mp_user->ext_user_id,$wp_user_id>0);
        $error = XH_Social::instance()->WP->get_wp_error($redirect_uri);
        if(!empty($error)){
            echo XH_Social_Error::error_custom($error)->to_json();
            exit;
        }
        
        $error = XH_Social_Error::success($redirect_uri);
        $error = apply_filters('wsocial_login_succeed', $error,$wp_user_id);
        echo $error->to_json();
        exit;
    }
    
    public function wsocial_wechat_qrcode_login_get_authorization_uri($redirect_uri,$login_type,$login_redirect_uri,$state,$uid,$wp_user_id){
        if($login_type!=1){return;}
        
        $page_qrcode = XH_Social_Add_On_Social_Wechat_Ext::instance()->get_page_qrcode();
        if(!$page_qrcode){
            XH_Social::instance()->WP->wp_die(__('wechat qrcode page not found!',XH_SOCIAL));
        }
        
        $params = array();
        $url = XH_Social_Helper_Uri::get_uri_without_params(get_page_link($page_qrcode),$params);
        
        $params1=array();
        $params1['uid'] =$wp_user_id;
        $params1['notice_str']=str_shuffle(time());
        $params1['hash'] =XH_Social_Helper::generate_hash($params1 ,XH_Social::instance()->get_hash_key());
        
        return $url."?".http_build_query(array_merge($params,$params1));
    }
    
    public function add_menu($menus){
        $menus[0]=$this;
       
        return $menus;
    }
    
    public function xh_social_admin_pages($menus){
        require_once 'includes/admin/menus/class-xh-social-page-wechat.php';
        require_once 'includes/admin/menus/class-xh-social-page-wechat-msgs.php';
        $menus[20]=XH_Social_Page_Wechat::instance();
        $menus[25]=XH_Social_Page_Wechat_Msgs::instance();
        return $menus;
    }
    
    private function checkSignature(){
        //先获取到这三个参数
        $signature = $_GET['signature'];
        $nonce = $_GET['nonce'];
        $timestamp = $_GET['timestamp'];
    
        //把这三个参数存到一个数组里面
        $tmpArr = array($timestamp,$nonce,$this->get_option('token'));
        //进行字典排序
        sort($tmpArr);
    
        //把数组中的元素合并成字符串，impode()函数是用来将一个数组合并成字符串的
        $tmpStr = implode($tmpArr);
    
        //sha1加密，调用sha1函数
        $tmpStr = sha1($tmpStr);
        //判断加密后的字符串是否和signature相等
        return $tmpStr == $signature;
    }
    public function on_wechat_service_load(){
        header("Content-Type:text/html; charset=utf-8");
    
        if(isset($_GET["echostr"])
            &&isset($_GET['signature'])
            &&isset($_GET['nonce'])
            &&isset($_GET['timestamp'])){
            if($this->checkSignature()){
                echo $_GET["echostr"];
                exit;
            }
        }
         
        require_once 'includes/class-wechat-msg-receiver.php';
        $api = XH_Social_Channel_Wechat::instance();
        $event =new XH_Social_Wechat_Msg_Receiver(
            $api->get_option('mp_id'),
            $api->get_option('mp_secret'),
            $this->get_option('token'),
            $this->get_option('EncodingAESKey'));
        
        try {
            $event->hook();
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return $event->response_txt(XH_Social_Error::err_code(500)->errmsg);
        }
    }
}

return XH_Social_Add_On_Social_Wechat_Sync::instance();
?>