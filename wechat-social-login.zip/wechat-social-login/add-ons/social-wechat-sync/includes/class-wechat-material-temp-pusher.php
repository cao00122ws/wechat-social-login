<?php 

if (! defined('ABSPATH'))
    exit();
require_once 'abstract-wechat-material.php';
class XH_Social_Wechat_Material_Temp_Pusher extends Abstract_XH_Social_Wechat_Material{
    /**
     * 获取临时素材
     * @param string $media_id
     * @return XH_Social_Error|array
     */
    public function get_temp_media($media_id){      
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $response = XH_Social_Helper_Http::http_get("https://api.weixin.qq.com/cgi-bin/media/get?access_token={$access_token}&media_id={$media_id}");
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when update articles!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function push_temp_media($post_id,$is_thumb=false){
        $post = $post_id>0?get_post($post_id):null;
        if(!$post){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        if($post->post_type!='attachment'){
            return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_type));
        }
        
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
       $file = wp_get_attachment_image_src($post->ID);
		if(!$file||count($file)==0){
			return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
		}
		
        $config = wp_get_upload_dir();
		
        $filename = str_replace($config['baseurl'],$config['basedir'],$file[0]);
        if(!file_exists($filename)){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        $type=$this->get_meida_type($post->post_mime_type);
        if(!$type){
            return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_mime_type));
        }
        
        if($is_thumb){
            $type = 'thumb';
        }
        try {
            $data =array(
                'access_token'=>$access_token,
                'type'=>$type
            );
           
            if(function_exists('curl_file_create')){
                $data['media'] = curl_file_create($filename);
            }else{
                $data['media'] = "@{$filename}";
            }
             
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/media/upload",$data,false,null,true);
             
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            $response = $error->validate($response);
            if(!$response instanceof XH_Social_Error){
                $response['mime_type'] =$post->post_mime_type;
                $response['source_url'] =$post->guid;
            }
        
            return $response;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when upload media source!detail error:%s,fileinfo:%s',XH_SOCIAL),$e->getMessage(),$filename));
        }
    }
}