<?php 

if (! defined('ABSPATH'))
    exit();

/**
 * 客服消息推送
 * @author rain
 *
 */
class XH_Social_Wechat_Service_Msg_Pusher{
    /**
     * @var XH_Social_Wechat_Token
     */
    public $wechat_token;
    public function __construct($appid,$appsecret,$crossdomain=null){
        require_once XH_SOCIAL_DIR.'/includes/wechat/class-wechat-token.php';
        $this ->wechat_token = new XH_Social_Wechat_Token($appid,$appsecret,$crossdomain);
    }
    
    public function push_text($openid,$content){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $request=json_encode(array(
                'touser'=>$openid,
                'msgtype'=>'text',
                'text'=>array(
                    'content'=>$content
                )
            ),JSON_UNESCAPED_UNICODE);
            
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$access_token}",$request);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when send text msg!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function push_media($openid,$post_id){
        require_once 'class-wechat-material-temp-pusher.php';
        $pusher = new XH_Social_Wechat_Material_Temp_Pusher($this->wechat_token->appid,$this->wechat_token->appsecret,$this->wechat_token->crossdomain_url);
        
        $response = $pusher->push_temp_media($post_id);
        if($response instanceof XH_Social_Error){
            return $response;
        }
       
        $media_id = $response['media_id'];
        $source_url = $response['source_url'];
        $msg_type = $pusher->get_meida_type($response['mime_type']);
      
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
    
        try {
            $request=json_encode(array(
                'touser'=>$openid,
                'msgtype'=>$msg_type,
                $msg_type =>array(
                    'media_id'=>$response['media_id']
                )
            ),JSON_UNESCAPED_UNICODE);
   
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$access_token}",$request);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            $response =  $error->validate($response);
            if(!$response instanceof XH_Social_Error){
                $response['media_id'] = $media_id;
                $response['source_url'] = $source_url;
                $response['msg_type']=$msg_type;
            }
            return $response;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when send media msg!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function push_articles($openid,array $post_ids){
        require_once 'class-wechat-material-fixed-pusher.php';
        $pusher = new XH_Social_Wechat_Material_Fixed_Pusher($this->wechat_token->appid,$this->wechat_token->appsecret,$this->wechat_token->crossdomain_url);
        $response = $pusher->push_articles($post_ids);
        if($response instanceof XH_Social_Error){
            return $response;
        }
        
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $request=json_encode(array(
                'touser'=>$openid,
                'msgtype'=>'mpnews',
                'mpnews'=>array(
                    'media_id'=>$response['media_id']
                )
            ),JSON_UNESCAPED_UNICODE);
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token={$access_token}",$request);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when send news msg!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
}