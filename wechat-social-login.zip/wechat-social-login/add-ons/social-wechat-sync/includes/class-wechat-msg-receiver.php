<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once 'class-wechat-msg-responser.php';
class XH_Social_Wechat_Msg_Receiver extends XH_Social_Wechat_Msg_Responser{   
    public function __construct($appid,$appsecret,$token,$EncodingAESKey){
        $xml = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
        if (empty($xml)) {
            $xml = @file_get_contents("php://input");
        }

        if(empty($xml)){
            return;
        }
        
        $xml_parser = xml_parser_create();
        if(!xml_parse($xml_parser,$xml,true)){
            xml_parser_free($xml_parser);
            return;
        }
     
        require_once 'class-wechat-hash.php';
        $api = new XH_Social_Wechat_Hash($appid,$appsecret,$token,$EncodingAESKey);
        
        parent::__construct($api->decrypt($xml),$appid,$appsecret);
    }
    
    public function hook(){
        if($this->data){
            $this->__hook();
        }
        
        echo 'success';
        exit;
    }
   
    private function __hook(){
        if(!$this->data){
            return;
        }
     
        switch ($this->data['MsgType']){
            case 'text':
                require_once 'emoji-editor/class-emoji-editor.php';
         
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode($this->data['Content'])
                ));
                break;
            case 'image':
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode(array(
                        'pic_url'=>$this->data['PicUrl'],
                        'media_id'=>$this->data['MediaId'],
                    ))
                ));
                break;
            case 'voice':
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode(array(
                        'format'=>$this->data['Format'],
                        'media_id'=>$this->data['MediaId']
                    ))
                ));
                break;
            case 'shortvideo':
            case 'video':
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode(array(
                        'thumb_media_id'=>$this->data['ThumbMediaId'],
                        'media_id'=>$this->data['MediaId']
                    ))
                ));
                break;
            case 'location':
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode(array(
                        'x'=>$this->data['Location_X'],
                        'y'=>$this->data['Location_Y'],
                        'scale'=>$this->data['Scale'],
                        'label'=>XH_Social_Emoji_Editor::text_to_html($this->data['Label']),
                    ))
                ));
                break;
            case 'link':
                $this->receive_msg(array(
                    'msg_id'=>$this->data['MsgId'],
                    'openid'=>$this->data['FromUserName'],
                    'created_time'=>$this->data['CreateTime'],
                    'msg_type'=>$this->data['MsgType'],
                    'content'=>json_encode(array(
                        'title'=>XH_Social_Emoji_Editor::text_to_html($this->data['Title']),
                        'description'=>XH_Social_Emoji_Editor::text_to_html($this->data['Description']),
                        'url'=>$this->data['Url']
                    ))
                ));
                break;
            case 'event':
                do_action('xh_social_channel_wechat_receive_event',$this->data,$this);
                return;
            default:
                return;
        }
    
        do_action('xh_social_channel_wechat_receive_msg',$this->data,$this);
        
        $this->response_2_customer_service();
    }

    private function receive_msg($data){
        $openid = $data['openid'];
        $user_ID = null;
        $user_info = null;
        if(!empty($openid)){
            if(class_exists('XH_Social_Channel_Wechat')){
                $user_info = XH_Social_Channel_Wechat::instance()->get_ext_user('mp_openid', $openid);
                if($user_info){
                    $user_info = get_object_vars($user_info);
                    $user_ID = $user_info['user_id'];
                }
            }
        }
        
        if(!$user_info){
            require_once 'class-wechat-user.php';
            $user_handler = new XH_Social_Wechat_User($this->appid,$this->appsecret,$this->crossdomain);
            $retry = 2;
            $response = $user_handler->get_user($openid,$retry);
            if(!$response instanceof XH_Social_Error){
                $user_info = $response;
                $user_info['img']= $response['headimgurl'];
                if(class_exists('XH_Social_Channel_Wechat')){
                   try {
                       $ext_user_id = XH_Social_Channel_Wechat::instance()->create_ext_user_info('mp', $response,null,null);
                   } catch (Exception $e) {
                       XH_Social_Log::error("缓存微信用户时发生异常:".$e->getMessage());
                   }
                }
            }else{
                XH_Social_Log::debug($response);
            }
        }
        
        $data['user_ID'] = $user_ID;
        $data['user_info'] = $user_info?json_encode($user_info):null;
        $data['status'] ='publish';
        global $wpdb;
        $result = $wpdb->insert("{$wpdb->prefix}xh_social_channel_wechat_msg", $data);
        if(!empty($wpdb->last_error)){
            XH_Social_Log::debug($wpdb->last_error);
            return XH_Social_Error::error_custom($wpdb->last_error);
        }
        
        if(!$result){
            XH_Social_Log::debug("插入微信消息({$wpdb->prefix}xh_social_channel_wechat_msg)时发生不可预测的错误！".print_r($wpdb,true));
            return XH_Social_Error::error_unknow();
        }
        
        return true;
    }
}