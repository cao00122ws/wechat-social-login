<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Msg_Keywords_Reply extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu_Msg_Keywords_Reply
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Msg_Auto_Reply
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_msg_keywords_reply';
        $this->title=__('Keywords reply',XH_SOCIAL);
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'enabled'=>array(
                'title' => __ ( 'Enable/Disable', XH_SOCIAL ),
                'type' => 'checkbox',
                'default' => 'no'
            ),
            'keywords_reply'=>array(
                'title'=>__('(Keywords)Reply content',XH_SOCIAL),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
                    $config = $api->get_option($key);
                    $config = $config?json_decode($config,true):array();
                    if(!$config||!is_array($config)){$config=array();}
                    ?>
                       </table>
                    			<table class="wp-list-table widefat fixed striped posts" style="table-layout:auto;">
                    				<thead>
                    					<tr>
                    						<td style="width:250px;">关键字</td>
                    						<td style="width:180px;">匹配规则</td>
                    						<td style="width:420px;">回复内容</td>
                    						<td style="width:70px;">操作</td>
                    					</tr>
                    				</thead>
                    				
                    				<tbody id="wsocial-k-msg-container">
                    					<?php 
                    					$keywords_placeholder="关键字1\r\n关键字2\r\n...";
                    					$index = 0;
                    					foreach ($config as $line){
                    					    ?>
                    					    <tr id="wsocial-k-msg-<?php echo $index;?>" data-context="keywords_reply_<?php echo $index;?>">
                    					    	<td>
                    					    		<textarea style="width:100%;" placeholder="<?php echo $keywords_placeholder;?>" data-row="3" class="wsocial-k-msg-keywords"><?php echo esc_textarea($line['keywords'])?></textarea>
                    					    	</td>
                    					    	<td>
                    					    		<select  class="wsocial-k-msg-match">
                    					    			<option value="0" <?php echo $line['match']=='0'?'selected':''?>>完全全匹配</option>
                    					    			<option value="1" <?php echo $line['match']=='1'?'selected':''?>>关键字开始</option>
                    					    			<option value="2" <?php echo $line['match']=='2'?'selected':''?>>关键字结尾</option>
                    					    			<option value="3" <?php echo $line['match']=='3'?'selected':''?>>包含关键字</option>
                    					    			<option value="4" <?php echo $line['match']=='4'?'selected':''?>>不包含关键字</option>
                    					    		</select>
                    					    	</td>
                    					    	<td>
                    					    		<?php 
                                    				    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg.php',array(
                                    				        'request'=>$line['config'],
                                    				        'context'=>'keywords_reply_'.$index
                                    				    ));
                                    				?>
                    					    	</td>
                    					    	<td><button type="button" class="button" style="float:right;"  onclick="window.wsocial_keywords_view.remove(<?php echo $index;?>);"><?php echo __('Remove',XH_SOCIAL)?></button></td>
                    					    </tr>
                    					    <?php 
                    					    $index++;
                    					}?>
                    				</tbody>
                    				<tfoot>
                    					<tr>
                    						<td colspan="3" style="float:left;">
                    							<button type="button" class="button-primary" onclick="window.wsocial_keywords_view.add();"><?php echo __('Add a line',XH_SOCIAL)?></button>
                    						</td>
                    					</tr>
                    				</tfoot>
                    			</table>
            				
            				<input type="hidden" name="<?php echo $field?>" id="<?php echo $field?>"/>
            				<script type="text/javascript">
            					(function($){
            						$('#mainform').submit(function(){
										var menus = [];
										$('#wsocial-k-msg-container tr').each(function(){
											var config={};
											window['on_wechat_menu_tw_submit_'+$(this).data('context')](config);
											
											menus.push({
												keywords:$(this).find(':input.wsocial-k-msg-keywords').first().val(),
												match:$(this).find(':input.wsocial-k-msg-match').first().val(),
												config:config
											});		
										});

										$('#<?php echo $field?>').val(JSON.stringify(menus));
									});
            						window.wsocial_keywords_view={
            							remove:function(index){
											if(!confirm('<?php echo __('Are you sure?',XH_SOCIAL)?>')){return;}

											$('#wsocial-k-msg-'+index).remove();
                						},
										add:function(){
											$('#wpbody-content').loading();
			    							$.ajax({
			    								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wsocial_keywords_add_msg'),true,true)?>',
			    								type:'post',
			    								timeout:120*1000,
			    								async:true,
			    								cache:false,
			    								dataType:'json',
			    								complete:function(){
			    									$('#wpbody-content').loading('hide');
			    								},
			    								success:function(e){
			    									if(e.errcode!=0){
			    										alert(e.errmsg);
			    										return;
			    									}
			    									
			    									var index = (new Date()).getTime();
			    									$('#wsocial-k-msg-container').append(
													'<tr id="wsocial-k-msg-'+index+'" data-context="'+e.data.context+'">\
			                    					    <td  style="width:250px;">\
													<textarea placeholder="关键字1\r\n关键字2\r\n..." style="width:100%;" data-row="3" class="wsocial-k-msg-keywords"></textarea>\
		                    					    	</td>\
	                    					    		<td><select class="wsocial-k-msg-match">\
                        					    			<option value="0">完全全匹配</option>\
                        					    			<option value="1">关键字开始</option>\
                        					    			<option value="2">关键字结尾</option>\
                        					    			<option value="3">包含关键字</option>\
                        					    			<option value="4">不包含关键字</option>\
                        					    		</select></td>\
		                    					    	<td style="width:410px;">'+e.data.html+'</td>\
		                    					    	<td style="width:70px;"><button type="button" class="button" style="float:right;"  onclick="window.wsocial_keywords_view.remove('+index+');"><?php echo __('Remove',XH_SOCIAL)?></button></td>\
		                    					    </tr>'
					    							);
			    								},
			    								error:function(e){
			    									console.error(e.responseText);
			    									alert('<?php echo XH_Social_Error::err_code(500)->to_string(); ?>');
			    								}
			    							});
										}
                    				};
                				})(jQuery);
								
            				</script>
                    <table>
                    <?php 
                },
                'validate'=>function($key ,$api){
                    $field = $api ->get_field_key($key);
                    $data =  isset($_POST[$field])? stripslashes($_POST[$field]):null;
                    $datas = $data?json_decode($data,true):array();
                  
                    $post_data = array();
                    foreach ($datas as $data){
                        $data['config'] = isset($data['config'])&&$data['config']&&is_array($data['config'])?$data['config']:array();
                         
                        $menu = array();
                        $ext_pro = array();
                        $response = XH_Social_Add_On_Social_Wechat_Sync::instance()->create_wechat_menu_tw($menu, $data['config'],$ext_pro);
                        if($response instanceof XH_Social_Error){
                            $this->errors[]=$response->to_string();
                        }
                        
                        $menu = array_merge($menu,$ext_pro);
                        $data['config']['msg'] = $menu;
                        $post_data[]=$data;
                    }
                 
                    return json_encode($post_data);
                }
            )
        );
    }
    
}