<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Edit extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Edit
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_menu_edit';
        $this->title=__('Menu',XH_SOCIAL);
        
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'menus'=>array(
                'title'=>__('Menu',XH_SOCIAL),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
                    
                    $menu_configs = json_decode($api->get_option($key),true);
                    ?>
                     </table>
                     
                     <link rel='stylesheet' id='nav-menus-css'  href='<?php echo $addon->url?>/assets/css/nav-menus.css' type='text/css' media='all' />
                     <link rel="stylesheet" type="text/css" href="<?php echo $addon->url?>/assets/css/emotion_editor.css"/>
                     <script type='text/javascript'>
                        /* <![CDATA[ */
                        var navMenuL10n = {"noResultsFound":"\u672a\u627e\u5230\u7ed3\u679c\u3002","warnDeleteMenu":"\u60a8\u5c06\u6c38\u4e45\u5220\u9664\u6240\u9009\u83dc\u5355\u3002\n\u70b9\u51fb\u201c\u53d6\u6d88\u201d\u505c\u6b62\uff0c\u70b9\u51fb\u201c\u786e\u5b9a\u201d\u5220\u9664\u3002","saveAlert":"\u79bb\u5f00\u8fd9\u4e2a\u9875\u9762\uff0c\u60a8\u6240\u505a\u7684\u66f4\u6539\u5c06\u4e22\u5931\u3002","untitled":"\uff08\u65e0\u6807\u7b7e\uff09"};
                        var menus = {"oneThemeLocationNoMenus":"","moveUp":"\u4e0a\u79fb\u4e00\u9879","moveDown":"\u4e0b\u79fb\u4e00\u9879","moveToTop":"\u4e0a\u79fb\u5230\u9876","moveUnder":"\u79fb\u81f3%s\u4e0b","moveOutFrom":"\u4ece%s\u79fb\u51fa","under":"%s\u4e0b","outFrom":"%s\u4e4b\u5916","menuFocus":"%1$s\u3002%3$s\u4e2a\u83dc\u5355\u9879\u4e4b%2$s\u3002","subMenuFocus":"%1$s\u3002%3$s\u83dc\u5355\u4e2d\u7684\u7b2c%2$d\u9879\u3002"};
                        /* ]]> */
                    </script>
                    <script type='text/javascript' src='<?php echo $addon->url?>/assets/js/nav-menu.js'></script>
                    <h2><button class="button" id="btn-add-menu" type="button"><?php echo __('Add menu',XH_SOCIAL)?></button></h2>
                    <div class="nav-menus-php">
                     	<ul class="menu ui-sortable" id="menu-to-edit">
                     		<?php if($menu_configs){
                     		    foreach ($menu_configs as $config){
                     		        echo $addon->generate_wechat_menu_edit_html($config);
                     		        if(isset($config['children'])&&$config['children']){
                     		            foreach($config['children'] as $child){
                     		                $child['is_submenu']=1;
                     		                echo $addon->generate_wechat_menu_edit_html($child);
                     		            }
                     		        }
                     		    }
                     		}?>
                     	</ul>
                     </div>
                     
                     <script type="text/javascript">
						(function($){
							$(document).bind('on_wechat_menu_position_change',function(){
								$('#menu-to-edit .menu-item.menu-item-depth-0').each(function(){
									var $submenu = $(this).next('.menu-item.menu-item-depth-1');
									if($submenu.length>0){
										$('#menu-'+$(this).data('context')+'-content').hide();
									}else{
										$('#menu-'+$(this).data('context')+'-content').show();
									}
								});
							});
							
							$(document).trigger('on_wechat_menu_position_change');
							
							$('#btn-add-menu').click(function(){
								$('#wpbody-content').loading();
    							$.ajax({
    								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'create_menu'),true,true)?>',
    								type:'post',
    								timeout:120*1000,
    								async:true,
    								cache:false,
    								dataType:'json',
    								complete:function(){
    									$('#wpbody-content').loading('hide');
    								},
    								success:function(e){
    									if(e.errcode!=0){
    										alert(e.errmsg);
    										return;
    									}
    									
    									wpNavMenu.addMenuItemToBottom(e.data);
    								},
    								error:function(e){
    									console.error(e.responseText);
    									alert('<?php echo __( 'System error while add menu !', XH_SOCIAL); ?>');
    								}
    							});
							});
						})(jQuery);
					</script>
                     <table class="form-table">
                     <?php 
                }
            )
        );
    }
    
    public function admin_form_end(){
        $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
        ?><p class="submit">
        	
			<input type="hidden" name="notice-<?php print $this->id?>" value="<?php print wp_create_nonce ( XH_Social::instance()->session->get_notice('admin:form:'.$this->id));?>"/>
			<input type="button" value="<?php print __('Save',XH_SOCIAL)?>" class="button" id="btn-form-save"/>
			<input type="button" value="<?php print __('Save and publish',XH_SOCIAL)?>" class="button-primary" id="btn-form-submit"/>
			<span style="color:green;" id="form-menu-msg"></span>
			<script type="text/javascript">
				(function($){
					window.generate_wechat_menu=function(){
						var menus =[];

						$('#menu-to-edit .menu-item').each(function(){
							var context = $(this).data('context');
							var menu = {	
								name:$.trim($('#wsocial-emoji-editor-'+context+'menu_name').html()),
								menu_type: $('.social-wechat-menu-type-'+context+':checked').val()
							};

							switch(menu.menu_type){
								case 'msg':
									window['on_wechat_menu_tw_submit_'+context](menu);
									break;
								case 'link':
									menu.msg_content=$('#menu-link-'+context).val();
									break;
								case 'app':
									menu.msg_content=$('#menu-app-'+context).val();
									break;
								case 'event':
									menu.msg_content=$('#menu-event-'+context).val();
									break;
							}
								
							if($(this).hasClass('menu-item-depth-0')){
								menus.push(menu);
							}else{
								if(!menus[menus.length-1].children){
									menus[menus.length-1].children=[];
								}

								menus[menus.length-1].children.push(menu);
							}
						});

						return menus;
					}

					$('#btn-form-save').click(function(){
						var menus = window.generate_wechat_menu();
						
						$('#wpbody-content').loading('微信菜单保存中...');
						$.ajax({
							url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'save_menu'),true,true)?>',
							type:'post',
							timeout:120*1000,
							async:true,
							cache:false,
							data:{menus:JSON.stringify(menus)},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}

								$('#form-menu-msg').html('保存成功！').show();
								setTimeout(function(){
									$('#form-menu-msg').html('').hide();
								},2000);
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'System error while add menu !', XH_SOCIAL); ?>');
							}
						});
					});
					$('#btn-form-submit').click(function(){
						var menus = window.generate_wechat_menu();
						
						$('#wpbody-content').loading('微信菜单发布中...');
						$.ajax({
							url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'push_menu'),true,true)?>',
							type:'post',
							timeout:120*1000,
							async:true,
							cache:false,
							data:{menus:JSON.stringify(menus)},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}

								$('#form-menu-msg').html('发布成功！').show();
								setTimeout(function(){
									$('#form-menu-msg').html('').hide();
								},2000);
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'System error while add menu !', XH_SOCIAL); ?>');
							}
						});
					});
				})(jQuery);
			</script>
		 </p>
		</form><?php
	}
}