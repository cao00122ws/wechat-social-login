<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Msg_Mass extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu_Msg_Mass
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Msg_Mass
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_msg_mass';
        $this->title=__('Mass msg',XH_SOCIAL);
        $this->description='在公众平台网站上，为服务号提供每月（自然月）4条的群发权限.';
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'content'=>array(
                'title'=>__('Posts',XH_SOCIAL),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
                    
                    ?>
                    </table>
                   <div>
        			<?php 
    				    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg.php',array(
    				        'request'=>array(),
    				        'context'=>'msg_mass'
    				    ));
    				?>
    				</div>
            		<table>
                    <?php 
                }
            )
        );
    }
    
    public function admin_form_end(){
        $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
        $context = 'msg_mass';
        
        ?><p class="submit">
        	<style type="text/css">.select2-container {width: 200px !important;}</style>
        	<select class="wsocial-search" id="search-wechat-msg-tw-<?php echo $context?>" data-type='wechat_user' name="post" data-sortable="true" data-placeholder="<?php echo __( 'Search for a wechat user(ID/user_login)&hellip;', XH_SOCIAL); ?>" data-allow_clear="true">
            	<input type="button" value="<?php print __('Preview',XH_SOCIAL)?>" class="button" id="btn-form-preview"/>
            	
        	
			<input type="hidden" name="notice-<?php print $this->id?>" value="<?php print wp_create_nonce ( XH_Social::instance()->session->get_notice('admin:form:'.$this->id));?>"/>	
			<?php echo __('Or',XH_SOCIAL)?>  <input type="button" value="<?php print __('Push',XH_SOCIAL)?>" class="button-primary" id="btn-form-submit"/>
			
			<div>点击预览按钮，群发消息会推送到指定用户(用户必须已绑定微信)，不会真实发送到所有用户(限制：100次/天)。</div>
			<span style="color:green;" id="form-menu-msg"></span>
			<script type="text/javascript">
				(function($){
					$('#btn-form-preview').click(function(){
						var data={
							user_ID:$('#search-wechat-msg-tw-<?php echo $context?>').val()
						};
						window.on_wechat_menu_tw_submit_msg_mass(data);
						
						$('#wpbody-content').loading('<?php __('Previewing...',XH_SOCIAL)?>');
						$.ajax({
							url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'preview_msg_mass'),true,true)?>',
							type:'post',
							timeout:120*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}

								$('#form-menu-msg').html('<?php echo __('Preview msg is send successfully!',XH_SOCIAL)?>').show();
								setTimeout(function(){
									$('#form-menu-msg').html('').hide();
								},2000);
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'System error while push msg !', XH_SOCIAL); ?>');
							}
						});
					});
					
					$('#btn-form-submit').click(function(){
						var data={};
						window.on_wechat_menu_tw_submit_msg_mass(data);
						
						$('#wpbody-content').loading('<?php __('Pushing...',XH_SOCIAL)?>');
						$.ajax({
							url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'push_msg_mass'),true,true)?>',
							type:'post',
							timeout:120*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}

								$('#form-menu-msg').html('<?php echo __('Msg is send successfully!',XH_SOCIAL)?>').show();
								setTimeout(function(){
									$('#form-menu-msg').html('').hide();
								},2000);
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'System error while push msg !', XH_SOCIAL); ?>');
							}
						});
					});
				})(jQuery);
			</script>
		 </p>
		</form><?php
	}
}