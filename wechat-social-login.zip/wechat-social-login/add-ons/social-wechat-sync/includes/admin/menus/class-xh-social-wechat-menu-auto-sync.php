<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Auto_Sync extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu_Auto_Sync
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Auto_Sync
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_auto_sync';
        $this->title=__('Auto sync',XH_SOCIAL);
        $this->description='选择文章类型，自动同步到微信公众号。';
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', XH_SOCIAL ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable wechat auto sync', XH_SOCIAL )
            ),
            'post_types'=>array(
                'title'=>__('Enabled post types',XH_SOCIAL),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_post_type_options'),
                'description'=>'同步条件：必须含特色图片'
            )
        );
    }
    
}