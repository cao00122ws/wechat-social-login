<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Mannel_Sync extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu_Mannel_Sync
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Mannel_Sync
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_mannel_sync';
        $this->title=__('Manual sync',XH_SOCIAL);
        $this->description='手动同步文章到微信公众号。';
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'content'=>array(
                'title'=>__('Posts',XH_SOCIAL),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
                    
                    ?>
                    <tr valign="top">
                    	<th scope="row" class="titledesc">
                    		<label for="xh_social_wsocial_wechat_sync_token"><?php echo __('Posts',XH_SOCIAL)?></label>
            			</th>
                    	<td class="forminp">
                    		<fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo __('Posts',XH_SOCIAL)?></span>
                    			</legend>
                    			
                    			<?php 
                        		    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg-tw.php',array(
                        		        'data'=>null,
                        		        'context'=>'mannel_sync'
                        		    ));
                        		?>
            				</fieldset>
                    	</td>
                    </tr>
                    <?php 
                }
            )
        );
    }
    
    public function admin_form_end(){
        $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
        ?><p class="submit">
			<input type="hidden" name="notice-<?php print $this->id?>" value="<?php print wp_create_nonce ( XH_Social::instance()->session->get_notice('admin:form:'.$this->id));?>"/>	
			<input type="button" value="<?php print __('Push',XH_SOCIAL)?>" class="button-primary" id="btn-form-submit"/>
			<span style="color:green;" id="form-menu-msg"></span>
			<script type="text/javascript">
				(function($){
					$('#btn-form-submit').click(function(){
						var data={
							posts:JSON.stringify(window.wechat_menu_tx_mannel_sync)	
						};
						
						$('#wpbody-content').loading('<?php echo __('Material is pushing...', XH_SOCIAL)?>');
						$.ajax({
							url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'push_articles'),true,true)?>',
							type:'post',
							timeout:120*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}

								$('#form-menu-msg').html('<?php echo __('Material is pushed successfully!', XH_SOCIAL)?>').show();
								setTimeout(function(){
									$('#form-menu-msg').html('').hide();
								},2000);
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'System error while push material !', XH_SOCIAL); ?>');
							}
						});
					});
				})(jQuery);
			</script>
		 </p>
		</form><?php
	}
}