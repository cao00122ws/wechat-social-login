<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Menu_Msg_Subscribe_Reply extends Abstract_XH_Social_Settings{
   /** 
    * @var XH_Social_Wechat_Menu_Msg_Subscribe_Reply
    */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Wechat_Menu_Msg_Subscribe_Reply
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='menu_wechat_connect_msg_subscribe_reply';
        $this->title=__('Subscribe reply',XH_SOCIAL);
        $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields=array(
            'enabled'=>array(
                'title' => __ ( 'Enable/Disable', XH_SOCIAL ),
                'type' => 'checkbox',
                'default' => 'no'
            ),
            'subscribe_reply'=>array(
                'title'=>__('(Subscribe)Reply content',XH_SOCIAL),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
                    $config = $api->get_option($key);
                    $config = $config?json_decode($config,true):array();
                    if(!$config||!is_array($config)){$config=array();}
                    ?>
                   </table>
                    		<fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo __('(Subscribe)Reply content',XH_SOCIAL)?></span>
                    			</legend>
                    			<?php 
                				    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg.php',array(
                				        'request'=>$config,
                				        'context'=>'subscribe_reply'
                				    ));
                				?>
            				</fieldset>
            				<input type="hidden" name="<?php echo $field?>" id="<?php echo $field?>"/>
            				<script type="text/javascript">
								(function($){
									$('#mainform').submit(function(){
										var data={};
										window.on_wechat_menu_tw_submit_subscribe_reply(data);
										$('#<?php echo $field?>').val(JSON.stringify(data));
									});
								})(jQuery);
            				</script>
                    	<table>
                    <?php 
                },
                'validate'=>function($key ,$api){
                    $field = $api ->get_field_key($key);
                    $data =  isset($_POST[$field])? stripslashes($_POST[$field]):null;
                    $post_data = $data?json_decode($data,true):array();
                    
                    $menu = array();
                    $ext_pro = array();
                    $response = XH_Social_Add_On_Social_Wechat_Sync::instance()->create_wechat_menu_tw($menu, $post_data,$ext_pro);
                    if($response instanceof XH_Social_Error){
                        $this->errors[]=$response->to_string();
                    }
                    
                    $menu = array_merge($menu,$ext_pro);
                    $post_data['msg'] = $menu;
                    
                    return json_encode($post_data);
                }
            )
        );
    }
    
}