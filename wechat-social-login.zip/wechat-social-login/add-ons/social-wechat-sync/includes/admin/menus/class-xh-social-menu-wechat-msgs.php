<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class XH_Social_Menu_Wechat_Msgs extends Abstract_XH_Social_Settings_Menu{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu_wechat_msgs';
        $this->title=__('Wechat msgs',XH_SOCIAL);
    }
    
    public function menus(){
        return apply_filters("xh_social_admin_menu_{$this->id}", array(
           20=> XH_Social_Menu_Wechat_Msgs_Default::instance()
        ));
    }
}

class XH_Social_Menu_Wechat_Msgs_Default extends Abstract_XH_Social_Settings{
    /**
     * @var XH_Social_Menu_Wechat_Msgs_Default
     */
    private static $_instance = null;
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return XH_Social_Menu_Wechat_Msgs_Default
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    protected function __construct(){
        $this->id='menu_wechat_msgs_default';
        $this->title=__('Wechat msgs',XH_SOCIAL);
       
    }

    public function admin_form_start(){}
     
    public function admin_options(){
        $addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
       ?>
       <div class="wrap">
       		<h2>
       			<?php echo __( 'Wechat msgs', XH_SOCIAL );?>
       		</h2>
           		<?php 
           		
           		$table = new XH_Social_Wechat_Msg_List_Table($this);
           		$table->process_action();
           		$table->views();
           		$table->prepare_items();
           		?>
           	<script type='text/javascript' src='<?php echo $addon->url?>/assets/js/emoji.js'></script>	
           		<script type='text/javascript' src='<?php echo $addon->url?>/assets/js/voice-2.0.js'></script>	
   			<form method="get" id="form-wshop-order">
   			   <input type="hidden" name="page" value="<?php echo XH_Social_Admin::instance()->get_current_page()->get_page_id()?>"/>
               <input type="hidden" name="section" value="<?php echo XH_Social_Admin::instance()->get_current_menu()->id?>"/>
               <input type="hidden" name="tab" value="<?php echo XH_Social_Admin::instance()->get_current_submenu()->id?>"/>
           		<div class="wechat-msg-list">
           		<?php $table->display(); ?>
           		</div>
       		</form>
       		<script type="text/javascript">
				(function($){
					$('.emoji').emoji();
					if(!window.thickboxL10n){
						window.thickboxL10n = {"next":"\u4e0b\u4e00\u9875 >","prev":"< \u4e0a\u4e00\u9875","image":"\u56fe\u50cf","of":"\/","close":"\u5173\u95ed","noiframes":"\u8fd9\u4e2a\u529f\u80fd\u9700\u8981iframe\u7684\u652f\u6301\u3002\u60a8\u53ef\u80fd\u7981\u6b62\u4e86iframe\u7684\u663e\u793a\uff0c\u6216\u60a8\u7684\u6d4f\u89c8\u5668\u4e0d\u652f\u6301\u6b64\u529f\u80fd\u3002","loadingAnimation":"http:\/\/ranj.mabaodian.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
        			}
					window.wsocial_wechat_msg_view={
						view:function(id){
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wechat_msg_view'),true,true)?>',
								type:'post',
								timeout:120*1000,
								data:{id:id},
								async:true,
								cache:false,
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}

									$('#wechat-msg-'+id).html(e.data);
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo __( 'System error while get source !', XH_SOCIAL); ?>');
								}
							});
						},
						reply:function(id){
							$('#wechat_msg_id_reply').val(id);
							tb_show(<?php echo json_encode( __( 'Reply msg', XH_SOCIAL ) ); ?>, '#TB_inline?inlineId=wechat_msg_reply_dialog');
							jQuery('#TB_window').css({'height':'500px','width':'500px'});
					         return false;   
						},
						reply_submit:function(){
							var data = {
								id:$('#wechat_msg_id_reply').val()
							};
							
							window.on_wechat_menu_tw_submit_msg_reply(data);

							$('#wpbody-content').loading();
							$('#btn-wechat-msg-reply').attr('disabled','disabled').val('<?php echo __('Processing...',XH_SOCIAL)?>');
							$.ajax({
								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wechat_msg_reply'),true,true)?>',
								type:'post',
								timeout:120*1000,
								data:data,
								async:true,
								cache:false,
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
									$('#btn-wechat-msg-reply').removeAttr('disabled').val('<?php echo __('Reply',XH_SOCIAL)?>');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}
									tb_remove();
									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo __( 'System error while reply msg !', XH_SOCIAL); ?>');
								}
							});
						},
						restore:function(id){
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wechat_msg_restore'),true,true)?>',
								type:'post',
								timeout:120*1000,
								data:{id:id},
								async:true,
								cache:false,
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}

									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo XH_Social_Error::err_code(500)->errmsg; ?>');
								}
							});
						},
						delete:function(id){
							if(!confirm('<?php echo __('Are you sure?',XH_SOCIAL)?>')){return;}
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wechat_msg_delete'),true,true)?>',
								type:'post',
								timeout:120*1000,
								data:{id:id},
								async:true,
								cache:false,
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}

									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo XH_Social_Error::err_code(500)->errmsg; ?>');
								}
							});
						},
						trash:function(id){
							if(!confirm('<?php echo __('Are you sure?',XH_SOCIAL)?>')){return;}
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'wechat_msg_trash'),true,true)?>',
								type:'post',
								timeout:120*1000,
								data:{id:id},
								async:true,
								cache:false,
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}

									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo XH_Social_Error::err_code(500)->errmsg; ?>');
								}
							});
						}
					};

					
				})(jQuery);
       		</script>
   		</div>
       	<div id="wechat_msg_reply_dialog" style="display:none;">
       		<input type="hidden"  id="wechat_msg_id_reply" />
			<div>

				<div class="setting-row">
					<?php 
    				    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg.php',array(
    				        'request'=>array(),
    				        'context'=>'msg_reply'
    				    ));
    				?>
				</div>
				<br/>
				<div class="submit-row">
					<input type="button" class="button button-large button-primary" onclick="window.wsocial_wechat_msg_view.reply_submit();" value="<?php echo __( 'Reply', XH_SOCIAL );?>" id="btn-wechat-msg-reply" />
					<div id="wechat-msg-reply-error-message" style="display:inline-block;"></div>
				</div>
			<script type="text/javascript">
				(function($){
					$(document).bind('wsocial_wechat_msg_tw_loading_start',function(){
						$('#btn-wechat-msg-reply').attr('disabled','disabled').val('<?php echo __('Processing...',XH_SOCIAL)?>');
					});

					$(document).bind('wsocial_wechat_msg_tw_loading_end',function(){
						$('#btn-wechat-msg-reply').removeAttr('disabled').val('<?php echo __('Reply',XH_SOCIAL)?>');
					});
				})(jQuery);
			</script>
			</div>
		</div>	
		
       <?php 
	}
	
    public function admin_form_end(){} 
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class XH_Social_Wechat_Msg_List_Table extends WP_List_Table {

    /**
     * @var XH_Social_Menu_Wechat_Msgs_Default
     * @since 1.0.0
     */
    public $api;

    /**
     * @var WP_User
     */
    private $customer_searched;
    
    private $created_time;
    private $status;
    
    /**
     * @param WShop_Menu_Order_Default_Settings $api
     * @param array $args
     * @since 1.0.0
     */
    public function __construct($api, $args = array() ) {
        $this->api = $api;
         
        parent::__construct( $args );
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'id');
        $this->status = isset($_REQUEST['status'])?$_REQUEST['status']:null;
        if(!in_array($this->status, array('publish','trash'))){
            $this->status ='publish';
        }
        
        $customer_id = isset($_REQUEST['_cid'])?intval($_REQUEST['_cid']):0;
        if($customer_id>0){
            $this->customer_searched = get_user_by('id', $customer_id);
        }
        
        $this->created_time = isset($_REQUEST['created_time'])&&!empty($_REQUEST['created_time'])?date_i18n('Y-m-d',strtotime($_REQUEST['created_time'])):null;

    }

    function get_sortable_columns() {
        return array(
            'id'    => array( 'id', false ),
            'created_time' => array( 'created_time', false )
        );
    }

    function get_views() {
        global $wpdb;
        $result =$wpdb->get_row(
           "select sum(if(o.`status`='trash',0,1)) as total,
                   sum(if(o.`status`='trash',1,0)) as trashed
            from `{$wpdb->prefix}xh_social_channel_wechat_msg` o
            where o.parent_id is null;");
         
        $msg_count= array(
            'publish'    => array(
                'title'=>__('Publish',XH_SOCIAL),
                'count'=>intval( $result->total )
            ),
            'trash'=> array(
                'title'=>__('Trash',XH_SOCIAL),
                'count'=>intval( $result->trashed )
            )
        );
    
        $page_now = XH_Social_Admin::instance()->get_current_admin_url();
        $views=array();
        foreach ($msg_count as $key=>$data){
            $views[$key] ="<a class=\"".($this->status==$key?'current':'')."\" href=\"{$page_now}&status={$key}\">{$data['title']} <span class=\"count\">(<span>{$data['count']}</span>)</span></a>";
        }
         
        return $views;
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'id';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        $status = empty($this->status)?"":" and o.status='{$this->status}' ";
        $customer_id = !$this->customer_searched?"":" and o.user_ID={$this->customer_searched->ID}";
        $created_time ="";
        if($this->created_time){
            $start = strtotime($this->created_time);
            $end = $start+24*60*60;
            $created_time=" and (o.created_time>=$start and o.created_time<=$end)";
        }
        
        global $wpdb;
        $sql=  "select count(o.id) as qty
                from `{$wpdb->prefix}xh_social_channel_wechat_msg` o
                where o.parent_id is null
                      $status
                      $customer_id
                      $created_time ;";
      
        $query = $wpdb->get_row($sql);

        $total = intval($query->qty);
        $per_page = 20;
        if($per_page<=0){$per_page=20;}
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            '_cid'=>$this->customer_searched?$this->customer_searched->ID:null,
            'created_time'=>$this->created_time
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql = "select o.*
                from `{$wpdb->prefix}xh_social_channel_wechat_msg` o
                where o.parent_id is null
                      $status
                      $customer_id
                      $created_time
                order by o.$sort_column $sort
                limit $start,$end;";
        
        $this->items = $wpdb->get_results($sql);  
        
        $sql = "select o.id
                from `{$wpdb->prefix}xh_social_channel_wechat_msg` o
                order by o.id desc
                limit 1;";
        
        $query = $wpdb->get_row($sql);
        if($query){
            update_option('wsocial_wechat_msg_last_view', $query->id,false);
        }
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?>
       
       <input type="search" id="search-msg-date" name="created_time" style="height:32px;" value="<?php echo esc_attr($this->created_time)?>" placeholder="<?php echo __('Date',XH_SOCIAL)?>"/>
       
       <script type="text/javascript">
       		(function($){
          		$(function(){
          			$("#search-msg-date").focus(function() {
              			WdatePicker({
              				dateFmt: 'yyyy-MM-dd'
              			});
              		});
              	});
           	})(jQuery);
	   </script>
	   <style type="text/css">.select2-container {width: 200px !important;}</style>
       <select class="wsocial-search" data-type='customer' name="_cid" data-sortable="true" data-placeholder="<?php echo __( 'Search for a customer(ID/user_login)&hellip;', XH_SOCIAL); ?>" data-allow_clear="true">
			<?php 
			if($this->customer_searched){
			    ?>
			    <option value="<?php echo $this->customer_searched->ID?>">
			    	<?php if(!empty($this->customer_searched->user_email)){
			    	    echo "{$this->customer_searched->user_login}({$this->customer_searched->user_email})";
			    	}else{
			    	    echo $this->customer_searched->user_login;
			    	}?>
			    </option>
			    <?php 
			}
			?>
		</select>
		
		<input type="submit" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',XH_SOCIAL)?>">
       <?php 
    }
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $msg_ids   = isset($_POST['msg_ids'])?$_POST['msg_ids']:null;;
        if(!$msg_ids||!is_array($msg_ids)){
            return;
        }
        require_once XH_Social_Add_On_Social_Wechat_Sync::instance()->dir .'/class-wechat-model-sync.php';
        foreach ($msg_ids as $msg_id){
            $error = XH_Social_Wechat_Msg_Handler::update($msg_id, $bulk_action);
            if(!XH_Social_Error::is_valid($error)){
                ?><div class="notice notice-error  is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',XH_SOCIAL)?></span></button></div><?php
                return;
            }
       }
    }
        
    function get_bulk_actions() {
        if ( $this->status == 'trash' ) {
            return array(
                'restore' => esc_html__( 'Restore', XH_SOCIAL ),
                'delete' => esc_html__( 'Delete permanently', XH_SOCIAL ),
            );
        }

        return array(
            'trash' => esc_html__( 'Move to trash', XH_SOCIAL )
        );
    }

    function get_columns() {
        return array(
            'cb'            => '<input type="checkbox" />',
            'ID'            => __( 'ID', XH_SOCIAL ),
            'user'          => __( 'User', XH_SOCIAL ),
            'msg_type'      => __( 'Msg type', XH_SOCIAL ),
            'content'       => __( 'Content', XH_SOCIAL ),
            'created_time'  => __( 'Created Time', XH_SOCIAL ),
            'toolbar'       => __( 'Toolbar', XH_SOCIAL ),
        );
    }

    public function single_row( $item ) {
        echo '<tr id="form-tr-'.$item->id .'">';
        $this->single_row_columns( $item );
        echo '</tr>';
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            // Comments column uses HTML in the display name with screen reader text.
            // Instead of using esc_attr(), we strip tags to get closer to a user-friendly string.
            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            } elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $msg ) {
		$msg_id = $msg->id;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $msg_id ); ?>"><?php echo __( 'Select msg',XH_SOCIAL ); ?></label>
		<input type="checkbox" class="wechat_msg_list_checkbox" name="msg_ids[]" value="<?php echo esc_attr( $msg_id ); ?>" />
		<?php
	}
   
	public function column_ID($item){
        ?>
        <a class="row-title"><strong>#<?php echo $item->id?></strong></a>
       
         <div class="row-actions">
         	 <?php if($this->status=='trash'){
         	     ?>
          	      <span class="restore"><a href="javascript:void(0);" onclick="window.wsocial_wechat_msg_view.restore(<?php echo $item->id;?>);"><?php echo __('Restore',XH_SOCIAL)?></a> | </span>
              	  <span class="delete"><a href="javascript:void(0);" onclick="window.wsocial_wechat_msg_view.delete(<?php echo $item->id;?>);" ><?php echo __('Delete permanently',XH_SOCIAL)?></a></span>
          	     <?php 
         	 }else{
         	     ?>
             	 <span class="trash"><a href="javascript:void(0);" onclick="window.wsocial_wechat_msg_view.trash(<?php echo $item->id;?>);"><?php echo __('Trash',XH_SOCIAL)?></a></span>
         	     <?php 
         	 }?>
             
         </div>
        <?php 
    }
    
    public function column_user($item){
        $item->user_info = json_decode($item->user_info,true);
        if($item->user_info&&is_array($item->user_info)){
            ?>
            <img src="<?php echo (isset($item->user_info['img'])?$item->user_info['img']:null)?>" style="max-width:30px;max-height:30px;border-radius: 50% !important;"/>
            <span><?php echo(isset($item->user_info['nickname'])?$item->user_info['nickname']:null)?></span>
            <?php 
            if($item->user_ID){
                ?><span>(ID:<?php echo $item->user_ID;?>)</span><?php 
            }
        }
    }
    
    public function column_msg_type($item){
        switch($item->msg_type){
            case 'text':
                echo '文本';
                break;
            case 'image':
                echo '图片';
                break;
            case 'voice':
                echo '语音';
                break;
            case 'video':
                echo '视频';
                break;
            case 'shortvideo':
                echo '小视频';
                break;
            case 'location':
                echo '地理位置';
                break;
            case 'link':
                echo '链接';
                break;
        }
    }
 
    public function column_content($item){
        $addon =XH_Social_Add_On_Social_Wechat_Sync::instance();
        require_once $addon->dir.'/includes/emoji-editor/class-emoji-editor.php';
        ?><div id="wechat-msg-<?php echo $item->id?>" class="emoji"><?php 
        switch($item->msg_type){
            case 'text':
               echo json_decode($item->content);
               break;
            case 'image':
                $content = json_decode($item->content,true);
                if(!$content||!is_array($content)){$content=array();}
                ?> <a href="<?php echo isset($content['pic_url'])?$content['pic_url']:null;?>" target="_blank"><img style="max-width:100px;max-height:100px;" src="<?php echo isset($content['pic_url'])?$content['pic_url']:null;?>" /></a><?php 
                break;
            case 'voice':
                $content = json_decode($item->content,true);
                if(!$content||!is_array($content)){$content=array();}
                if(!isset( $content['source_url'])||empty( $content['source_url'])){
                    ?>
                	<button class="button" type="button" onclick="window.wsocial_wechat_msg_view.view(<?php echo $item->id?>);"><?php echo __('Click to view',XH_SOCIAL)?></button>
                	<?php
                }else{
                    $context = XH_Social_Helper::generate_unique_id();
                    ?>
                    <input type="button" value="play" class="button-primary" id="playId-<?php echo $context?>"/>
					<input type="button" value="stop" class="button-primary" id="stopId-<?php echo $context?>"/>
                    <script type="text/javascript">
                        RongIMLib.RongIMVoice.init();
                        document.getElementById("playId-<?php echo $context?>").onclick = function(){
                            RongIMLib.RongIMVoice.play("<?php echo $content['source_url'];?>");
                        };
                        document.getElementById("playId-<?php echo $context?>").onclick = function(){
                            RongIMLib.RongIMVoice.stop();
                        };
                    </script>
                    <?php 
                }
                break;
            case 'shortvideo':
            case 'video':
                $content = json_decode($item->content,true);
                if(!$content||!is_array($content)){$content=array();}
                if(!isset( $content['source_url'])||empty( $content['source_url'])){
                    ?>
                	<button class="button" type="button" onclick="window.wsocial_wechat_msg_view.view(<?php echo $item->id?>);"><?php echo __('Click to view',XH_SOCIAL)?></button>
                	<?php
                }else{
                    ?>
                    <video controls style="min-width:100px;min-height:100px;max-width:150px;max-height:150px;" src="<?php echo $content['source_url'];?>" poster="<?php echo wp_guess_url().'/wp-includes/images/media/video.png';?>"></video>
                    <?php 
                }
                break;
            case 'location':
                $content = json_decode($item->content,true);
                if(!$content||!is_array($content)){$content=array();}
                ?>位置：<?php echo isset($content['label'])?$content['label']:null;?>(x:<?php echo isset($content['x'])?$content['x']:null;?>,y:<?php echo isset($content['y'])?$content['y']:null;?>,scale:<?php echo isset($content['scale'])?$content['scale']:null;?>) <?php 
               break;
            case 'link':
                $content = json_decode($item->content,true);
                if(!$content||!is_array($content)){$content=array();}
                ?><a target="_blank" href="<?php echo isset($content['url'])?$content['url']:null; ?>" title="<?php echo isset($content['title'])?$content['title']:null; ?>"><?php echo isset($content['url'])?$content['url']:null; ?></a><?php
                break;
        }
        ?></div><?php
        
        global $wpdb;
        $replys = $wpdb->get_results(
           "select *
            from {$wpdb->prefix}xh_social_channel_wechat_msg
            where parent_id={$item->id}
            order by id asc
            limit 20;");
        if($replys){
            ?>
            <h5>回复：</h5>
            <ul style="list-style:none;">
            	<?php foreach ($replys as $reply){
            	    ?>
            	    <li>
            	    	<span><?php echo date_i18n('Y-m-d H:i',$reply->created_time+8*60*60)?>:</span>
            	    	<div>
            	    	<?php 
            	    	switch($reply->msg_type){
            	    	    case 'mpnews':
            	    	        $post_ids = json_decode($reply->content,true);
            	    	        echo '文章ID:';
            	    	        if($post_ids){
            	    	            for ($index=0;$index<count($post_ids);$index++){
            	    	                if($index!=0){echo ',';}
            	    	                
            	    	                echo $post_ids[$index];
            	    	            }
            	    	        }
            	    	        break;
            	    	    case 'text':
            	    	        echo json_decode($reply->content);
            	    	        break;
            	    	    case 'image':
            	    	        ?> <img style="max-width:100px;max-height:100px;" src="<?php echo $reply->content;?>" /><?php
    	    	                break;
    	    	            case 'voice':
    	    	       
	    	                    $context = XH_Social_Helper::generate_unique_id();
	    	                    ?>
	    	                    <input type="button" value="play" class="button-primary" id="playId-<?php echo $context?>"/>
	    						<input type="button" value="stop" class="button-primary" id="stopId-<?php echo $context?>"/>
	    	                    <script type="text/javascript">
	    	                        RongIMLib.RongIMVoice.init();
	    	                        document.getElementById("playId-<?php echo $context?>").onclick = function(){
	    	                            RongIMLib.RongIMVoice.play("<?php echo $reply->content;?>");
	    	                        };
	    	                        document.getElementById("playId-<?php echo $context?>").onclick = function(){
	    	                            RongIMLib.RongIMVoice.stop();
	    	                        };
	    	                    </script>
	    	                    <?php 
    	    	                break;
    	    	            case 'video':
    	    	                $content = json_decode($reply->content,true);
    	    	                if(!$content||!is_array($content)){$content=array();}
    	    	                
	    	                    ?>
	    	                    <video controls style="min-width:100px;min-height:100px;max-width:150px;max-height:150px;" src="<?php echo $reply->content;?>" poster="<?php echo wp_guess_url().'/wp-includes/images/media/video.png';?>"></video>
	    	                    <?php 
    	    	                break;
    	    	        }
            	    	?></div>
            	    </li>
            	    <?php 
            	}?>
            </ul>
            <?php 
        }
        
    }
    
    public function column_created_time($item){
        ?>
        <time><?php echo date('Y-m-d H:i',$item->created_time+8*60*60)?></time>
        <?php 
    }
    
    /**
     * @param Abstract_WShop_Order $item
     */
    public function column_toolbar($item){
        ?><p>
            <a class="xh-list-imgbtn"  href="javascript:void(0);" onclick="window.wsocial_wechat_msg_view.reply(<?php echo $item->id;?>);">回复</a>			
		  </p>
        <?php 
    }  

	function no_items() {
		echo __( "You don't have any msgs!", XH_SOCIAL ) ;
	}
}