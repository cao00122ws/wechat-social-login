<?php 

if (! defined('ABSPATH'))
    exit();
class XH_Social_Wechat_Menu_Pusher{
    /**
     * @var XH_Social_Wechat_Token
     */
    public $wechat_token;
    public function __construct($appid,$appsecret,$crossdomain=null){
        require_once XH_SOCIAL_DIR.'/includes/wechat/class-wechat-token.php';
        $this ->wechat_token = new XH_Social_Wechat_Token($appid,$appsecret,$crossdomain);
    }
    
    public function push_menu(array $menus){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        try {
            $data =json_encode(array(
                'button'=>$menus
            ),JSON_UNESCAPED_UNICODE);
          
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/menu/create?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when create wechat menu!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
}