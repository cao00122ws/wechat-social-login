<?php 

if (! defined('ABSPATH'))
    exit();
require_once 'abstract-wechat-material.php';
class XH_Social_Wechat_Material_Fixed_Pusher extends Abstract_XH_Social_Wechat_Material{
    public function update_article($media_id,$post_id,$index=0){
        $post = $post_id>0?get_post($post_id):null;
        if(!$post){
            return XH_Social_Error::error_custom(sprintf(__('Post (ID:%s) is not found!',XH_SOCIAL),$post_id));
        }
         
        $post_thumbnail_id = get_post_thumbnail_id( $post );
        $response = $this->push_thumb_media($post_thumbnail_id);
        if($response instanceof XH_Social_Error){
            $errmsg = $response->to_string();
            return XH_Social_Error::error_custom(sprintf(__('Upload post(ID:%s) feature image failed,detail errors:%s',XH_SOCIAL),$post_id,$errmsg));
        }
        
        do_action('pre_get_post_content');
        
        if(empty($post->post_content)){
            $post->post_content = $post->post_title;
        }
        
        $excerpt = $post->post_excerpt;
        if(empty($excerpt)){
            $excerpt = $post->post_content;
        }
        
        
        try {
            $request = array(
                'media_id'=>$media_id,
                'index'=>$index,
                'articles'=>array(
                    'title'=>mb_strimwidth(strip_tags($post->post_title), 0, 60,'...','utf-8'),
                    'thumb_media_id'=>$response['media_id'],
                    'author'=>mb_strimwidth(strip_tags(get_option('blogname')), 0, 32,'...','utf-8'),
                	'digest'=>mb_strimwidth(trim(strip_tags(do_shortcode($excerpt))), 0, 120,'...','utf-8'),
                    'show_cover_pic'=>0,
                    //图文消息的具体内容，支持HTML标签，必须少于2万字符，小于1M，且此处会去除JS,涉及图片url必须来源 "上传图文消息内的图片获取URL"接口获取。外部图片url将被过滤。
                    'content'=>mb_strimwidth(preg_replace_callback("/(<\s*img.+)src\s*=\s*(['\"])\s*([^'\"<>]+)\s*(['\"])(.*>)/i",array($this,'_preg_replace_callback_push_articles'), do_shortcode($post->post_content)), 0, 39900,'...','utf-8'),
                    'content_source_url'=>get_permalink($post)
                )
            );
            
            $retry =2;
            $access_token = $this ->wechat_token->access_token($retry);
            if($access_token instanceof XH_Social_Error){
                return $access_token;
            }
        
            $data =json_encode($request,JSON_UNESCAPED_UNICODE);
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/update_news?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when update articles!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function remove_fixed_media($media_id){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $data =json_encode( array(
                'media_id'=>$media_id
            ),JSON_UNESCAPED_UNICODE);
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/del_material?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when remove fixed media!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function remove_fixed_media_by_post($post_ids){
        $media_id = $this->get_cached_media($post_ids);
        if(!$media_id instanceof XH_Social_Error){
            $media =  $this->get_fixed_media($media_id);
            if(!$media instanceof XH_Social_Error){
                $response = $this->remove_fixed_media($media_id);
                if($response instanceof XH_Social_Error){
                    return $response;
                }
            }
        }
        
        return $this->remove_cached_media($post_ids);
    }
    
    /**
     * 上传永久图文素材
     * @param array $post_ids
     * @return array 
     * array(
     *      media_id
     * )
     */
    public function push_articles(array $post_ids){
        $media_id = $this->get_cached_media($post_ids);
        if(!($media_id instanceof XH_Social_Error)){
            $media =  $this->get_fixed_media($media_id);
            if(!($media instanceof XH_Social_Error)){
                return array(
                    'media_id'=>$media_id
                );
            }
        }
         
        $articles = array();
        try { 
            foreach ($post_ids as $post_id){
                $post = $post_id>0?get_post($post_id):null;
                if(!$post){
                    return XH_Social_Error::error_custom(sprintf(__('Post (ID:%s) is not found!',XH_SOCIAL),$post_id));
                }
                 
                $post_thumbnail_id = get_post_thumbnail_id( $post );
                $response = $this->push_thumb_media($post_thumbnail_id);
                if($response instanceof XH_Social_Error){
                    $errmsg = $response->to_string();
                    return XH_Social_Error::error_custom(sprintf(__('Upload post(ID:%s) feature image failed,detail errors:%s',XH_SOCIAL),$post_id,$errmsg));
                }
                do_action('pre_get_post_content');
                if(empty($post->post_content)){
                    $post->post_content = $post->post_title;
                }
                
                $excerpt = $post->post_excerpt;
                if(empty($excerpt)){
                    $excerpt = $post->post_content;
                } 
                
                $articles[]=array(
                    'title'=>mb_strimwidth(strip_tags($post->post_title), 0, 60,'...','utf-8'),
                    'thumb_media_id'=>$response['media_id'],
                    'author'=>mb_strimwidth(strip_tags(get_option('blogname')), 0, 32,'...','utf-8'),
                	'digest'=>mb_strimwidth(trim(strip_tags(do_shortcode($excerpt))), 0, 120,'...','utf-8'),
                    'show_cover_pic'=>0,
                    //图文消息的具体内容，支持HTML标签，必须少于2万字符，小于1M，且此处会去除JS,涉及图片url必须来源 "上传图文消息内的图片获取URL"接口获取。外部图片url将被过滤。
                    //'/src\s*=\s*(\'|")([^\'"]*\/\/[^\'"]+\.\s*((jpg)|(png)))\s*(\'|")/i'
                    'content'=>mb_strimwidth(preg_replace_callback("/(<\s*img.+)src\s*=\s*(['\"])\s*([^'\"<>]+)\s*(['\"])(.*>)/i",array($this,'_preg_replace_callback_push_articles'), do_shortcode($post->post_content)), 0, 39900,'...','utf-8'),
                    'content_source_url'=>get_permalink($post)
                );
            }
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push articles!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $data =json_encode(array(
                'articles'=>$articles
            ),JSON_UNESCAPED_UNICODE);
            
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/add_news?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            $response = $error->validate($response);
            if(!$response instanceof XH_Social_Error){
                $this->set_cached_media($post_ids, $response['media_id']);
            }
            
            return $response;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push articles!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function _preg_replace_callback_push_articles($m){
        if(count($m)!=6){
            return $m[0];
        }
        
        $response = $this->push_articles_inner_img($m[3]);
        if($response===false){
            return $m[0];
        }
        if($response instanceof XH_Social_Error){
           throw new Exception($response->errmsg, $response->errcode);
        }
        
        return "{$m[1]}src={$m[2]}{$response['url']}{$m[4]}{$m[5]}";
    }
    
    /**
     * 上传永久素材(仅缩略图)
     * @param int $img_post_id 图片ID
     * @return XH_Social_Error|array
     * array(
     *      media_id
     * )
     */
    public function push_thumb_media($img_post_id){
        $post = $img_post_id>0?get_post($img_post_id):null;
        if(!$post){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        if($post->post_type!='attachment'){
            return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_type));
        }
        
        $media_id = $this->get_cached_media(array($img_post_id));
        if(!($media_id instanceof XH_Social_Error)){
            $media =  $this->get_fixed_media($media_id);
            if(!($media instanceof XH_Social_Error)){
                return array(
                    'media_id'=>$media_id
                );
            }
        }
         
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        $file = wp_get_attachment_image_src($post->ID);
		if(!$file||count($file)==0){
			return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
		}
		
        $config = wp_get_upload_dir();
		
        $filename = str_replace($config['baseurl'],$config['basedir'],$file[0]);

        if(!file_exists($filename)){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        $size = filesize($filename);
        
        $type=null;
        switch($post->post_mime_type){
            case 'image/png':
            case 'image/jpg':
            case 'image/jpeg':
            case 'image/gif':
            case 'image/bmp':
                $type='thumb';
                break;
            default:
                return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_mime_type));
        }
        
        try {
            $data =array(
                'access_token'=>$access_token,
                'type'=>$type
            );
            
            if(function_exists('curl_file_create')){
                $data['media'] = curl_file_create($filename);
            }else{
                $data['media'] = "@{$filename};";
            }
            
            if($type=='video'){
                $data['title']=$post->post_title;
                $data['introduction']=$post->post_title;
            }
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/add_material",$data,false,null,true);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            $response = $error->validate($response);
            if(!$response instanceof XH_Social_Error){
                $this->set_cached_media(array($img_post_id), $response['media_id']);
            }
            
            return $response;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when upload image source!detail error:%s,fileinfo:%s',XH_SOCIAL),$e->getMessage(),$filename));
        }
    }
    
    
    public function get_fixed_media($media_id){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $data =json_encode(array(
                'media_id'=>$media_id
            ));
            
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/get_material?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when get media source!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    /**
     * 上传永久素材(不包含缩略图)
     * @param int $img_post_id 图片ID
     * @return XH_Social_Error|array
     * array(
     *      media_id
     * )
     */
    public function push_fixed_media($img_post_id){
        $post = $img_post_id>0?get_post($img_post_id):null;
        if(!$post){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        if($post->post_type!='attachment'){
            return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_type));
        }
        
        $media_id = $this->get_cached_media(array($img_post_id));
        if(!($media_id instanceof XH_Social_Error)){
            $media =  $this->get_fixed_media($media_id);
            if(!($media instanceof XH_Social_Error)){
                return array(
                    'mime_type'=>$post->post_mime_type,
                    'title'=>$post->post_title,
                    'desc'=>$post->post_title,
                    'media_id'=>$media_id
                );
            }
        }
         
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        $file = wp_get_attachment_image_src($post->ID);
		if(!$file||count($file)==0){
			return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
		}
		
        $config = wp_get_upload_dir();
		
        $filename = str_replace($config['baseurl'],$config['basedir'],$file[0]);
        if(!file_exists($filename)){
            return XH_Social_Error::error_custom(__('Media source is not found!',XH_SOCIAL));
        }
        
        $type=$this->get_meida_type($post->post_mime_type);
        if(!$type){
            return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$post->post_mime_type));
        }
        
        try {
            $data =array(
                'access_token'=>$access_token,
                'type'=>$type
            );
         
            if(function_exists('curl_file_create')){
                $data['media'] = curl_file_create($filename);
            }else{
                $data['media'] = "@{$filename}";
            }
         
            if($type=='video'){
                $data['description'] = json_encode(array(
                    'title'=>$post->post_title,
                    'introduction'=>$post->post_title
                ),JSON_UNESCAPED_UNICODE);
            }
           
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/material/add_material",$data,false,null,true);
           
            $error = new XH_Social_Wechat_Error($this->wechat_token);  
            $response = $error->validate($response);
            if(!$response instanceof XH_Social_Error){
                $this->set_cached_media(array($img_post_id), $response['media_id']);
                $response['title'] = $post->post_title;
                $response['desc'] = $post->post_title;
                $response['mime_type'] =$post->post_mime_type;
            }
            
            return $response;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when upload media source!detail error:%s,fileinfo:%s',XH_SOCIAL),$e->getMessage(),$filename));
        }
    }
}
