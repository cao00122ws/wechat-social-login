<?php 

if (! defined('ABSPATH'))
    exit();

  abstract class Abstract_XH_Social_Wechat_Material{
      /**
       * @var XH_Social_Wechat_Token
       */
      public $wechat_token;
      public function __construct($appid,$appsecret,$crossdomain=null){
          require_once XH_SOCIAL_DIR.'/includes/wechat/class-wechat-token.php';
          $this ->wechat_token = new XH_Social_Wechat_Token($appid,$appsecret,$crossdomain);
      }

      public function get_meida_type($mime_type){
          $type=null;
          switch($mime_type){
              case 'image/png':
              case 'image/jpg':
              case 'image/jpeg':
              case 'image/gif':
              case 'image/bmp':
                  $type='image';
                  break;
              case 'video/mp4':
                  $type='video';
                  break;
              case 'audio/mpeg':
              case 'audio/x-ms-wma':
              case 'audio/wav':
              case '"audio/amr':
                  $type='voice';
                  break;
          }
          return $type;
      }
      
      /**
       * 上传图文内包含的图片
       * @param string $src 图片地址
       * @return XH_Social_Error|array
       * array(
       *      url
       * )
       */
      public function push_articles_inner_img($src){
          $url = trim($src);
          if(empty($url)){
              return false;
          }
      
          if(strpos($url, '//')===0){
              $protocol = (! empty ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] !== 'off' || $_SERVER ['SERVER_PORT'] == 443) ? "https:" : "http:";
              $url=$protocol.$url;
          }
      
          $_p =strrpos($url, '/');
          $_filename =strtolower($_p===false?$url: substr($url,$_p+1));
      
          switch (substr($_filename, -4)){
              case '.png':
                  $post_mime_type='image/png';
                  break;
              case '.jpg':
                  $post_mime_type='image/jpg';
                  break;
              default:
                   return false;
          }
          
          $filename=null;
          $config =wp_get_upload_dir();
          if(strpos($url, $config['baseurl'])===0){
              $filename = str_replace($config['baseurl'],$config['basedir'],$url);
          }else{
              $content = @file_get_contents($url);
              if($content===false){
                  return XH_Social_Error::error_custom('加载远程图片信息时发生异常:'.$url);
              }
              
              $filename = $config['path'].'/'.$_filename;
              $result = @file_put_contents($filename, $content);
              if($result===false){
                  return XH_Social_Error::error_custom('保存远程图片信息时发生异常:'.$url);
              }
          }
          
          $retry =2;
          $access_token = $this ->wechat_token->access_token($retry);
          if($access_token instanceof XH_Social_Error){
              return $access_token;
          }
          try {
              $data =array(
                  'access_token'=>$access_token
              );
      
              if(function_exists('curl_file_create')){
                  $data['media'] = curl_file_create($filename);
              }else{
                  $data['media'] = "@{$filename}";
              }
      
              $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/media/uploadimg",$data,false,null,true);
              $error = new XH_Social_Wechat_Error($this->wechat_token);
              return $error->validate($response);
          } catch (Exception $e) {
              XH_Social_Log::error($e);
              return XH_Social_Error::error_custom(sprintf(__('Something is wrong when upload article inner image!detail error:%s,file info:%s',XH_SOCIAL),$e->getMessage(),$src));
          }
          
      }
      
      /**
       * 获取media id
       * @param array $post_ids
       * @param $material_type fixed|temp|news
       * @return string|XH_Social_Error
       */
      public function get_cached_media(array $post_ids,$material_type='fixed'){
          if(count($post_ids)==0){return XH_Social_Error::err_code(404);}
      
          $cached_id = md5($material_type.join(',', $post_ids));
          global $wpdb;
          $material = $wpdb->get_row(
              "select *
              from {$wpdb->prefix}xh_social_channel_wechat_material m
              where m.id='{$cached_id}'
                    and m.material_type='$material_type'
              limit 1;");
          if(!$material||empty($material->media_id)){
              return XH_Social_Error::err_code(404);
          }
      
          //--查看 素材内容是否已更新
          $posts = array();
          foreach ($post_ids as $post_ID){
              $post = get_post($post_ID);
              if(!$post){
                  return XH_Social_Error::error_custom(sprintf(__('Something is wrong when cache media!detail error:Post (ID:%s) is not found!',XH_SOCIAL),$post_ID));
              }
      
              $posts[] = array(
                  'post_ID'=>$post_ID,
                  'post_modified'=>$post->post_modified
              );
          }
      
          $_posts =json_decode($material->posts,true);
          if(!$_posts){
              return XH_Social_Error::err_code(404);
          }
      
          if(count($posts)!=count($_posts)){
              return XH_Social_Error::err_code(404);
          }
      
          foreach ($posts as $index => $post){
              $_post = $_posts[$index];
              if($post['post_ID']!=$_post['post_ID']||$post['post_modified']!=$_post['post_modified']){
                  return XH_Social_Error::err_code(404);
              }
          }
          
          return $material->media_id;
      }
      
      /**
       *
       * @param array $post_ids
       * @param $material_type fixed|temp|news
       * @return XH_Social_Error
       */
      public function remove_cached_media(array $post_ids,$material_type='fixed'){
          $cached_id = md5($material_type.join(',', $post_ids));
          global $wpdb;
          $wpdb->delete("{$wpdb->prefix}xh_social_channel_wechat_material", array(
              'id'=>$cached_id
          ));
      
          if(!empty($wpdb->last_error)){
              return XH_Social_Error::error_custom($wpdb->last_error);
          }
      
          return XH_Social_Error::success();
      }
      
      public function set_cached_media(array $post_ids,$media_id,$material_type='fixed'){
          $cached_id = md5($material_type.join(',', $post_ids));
      
          $posts = array();
          foreach ($post_ids as $post_ID){
              $post = get_post($post_ID);
              if(!$post){
                  return XH_Social_Error::error_custom(sprintf(__('Something is wrong when cache media!detail error:Post (ID:%s) is not found!',XH_SOCIAL),$post_ID));
              }
      
              $posts[] = array(
                  'post_ID'=>$post_ID,
                  'post_modified'=>$post->post_modified
              );
          }
      
          global $wpdb;
          $material = $wpdb->get_row(
              "select *
              from {$wpdb->prefix}xh_social_channel_wechat_material m
              where m.id='{$cached_id}'
              limit 1;");
          if($material){
              $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_material", array(
                  'media_id'=>$media_id,
                  'posts'=>json_encode($posts),
                  'material_type'=>$material_type,
                  'created_time'=> date_i18n('Y-m-d H:i')
              ), array(
                  'id'=>$cached_id
              ));
      
              if(!empty($wpdb->last_error)){
                  return XH_Social_Error::error_custom($wpdb->last_error);
              }
          }else{
              $inserted = $wpdb->insert("{$wpdb->prefix}xh_social_channel_wechat_material", array(
                  'id'=>$cached_id,
                  'media_id'=>$media_id,
                  'material_type'=>$material_type,
                  'posts'=>json_encode($posts),
                  'created_time'=> date_i18n('Y-m-d H:i')
              ));
      
              if(!empty($wpdb->last_error)){
                  return XH_Social_Error::error_custom($wpdb->last_error);
              }
      
              if(!$inserted){
                  return XH_Social_Error::error_unknow();
              }
          }
      
          return true;
      }
      
  }