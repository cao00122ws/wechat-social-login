<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_User{
    /**
     * @var XH_Social_Wechat_Token
     */
    public $wechat_token;
    public function __construct($appid,$appsecret,$crossdomain=null){
       require_once XH_SOCIAL_DIR.'/includes/wechat/class-wechat-token.php';
       $this ->wechat_token = new XH_Social_Wechat_Token($appid,$appsecret,$crossdomain);
    }
    
    public function get_user($openid,&$retry=2){
        try {
            $c=2;
            $access_token = $this->wechat_token->access_token($c);
            if($access_token instanceof XH_Social_Error){
                return $access_token;
            }
           
            $response =XH_Social_Helper_Http::http_get("https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$openid}&lang=zh_CN");
            $error = new XH_Social_Wechat_Error($this ->wechat_token);
            $user_info  = $error->validate($response);
            if($user_info instanceof XH_Social_Error){
                return $user_info;
            }
            
            if(isset($user_info['nickname'])){
                $user_info['nickname'] = XH_Social_Helper_String::remove_emoji($user_info['nickname']);
            }
            if(isset($user_info['headimgurl'])&&!empty($user_info['headimgurl'])){
                $user_info['img']=str_replace('http://', '//', $user_info['headimgurl']);
            }
            
            return $user_info;
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            if($e->getCode()==500){
                return new XH_Social_Error($e->getCode(),$e->getMessage());
            }
            if($retry-->0){
                return $this->get_user($openid,$retry);
            }
        }
        
        return XH_Social_Error::error_unknow();
    }
}
?>