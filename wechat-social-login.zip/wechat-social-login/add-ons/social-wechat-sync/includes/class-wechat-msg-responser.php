<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class XH_Social_Wechat_Msg_Responser{
    public $data,$appid,$appsecret,$crossdomain;
    public function __construct($data,$appid,$appsecret,$crossdomain=null){
        $this->data = $data;
        $this->appid = $appid;
        $this->appsecret = $appsecret;
        $this->crossdomain = $crossdomain;
    }
    /**
     * 
     * @param string $content
     */
    public function response_txt($content=''){
        if(!$this->data){
            return;
        }
    
        if(empty($content)){
            echo 'success';
            exit;
        }
    
        $content = strip_tags($content);//去除html标签
        $now = time();
        echo "<xml>
                    <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                    <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                    <CreateTime>{$now}</CreateTime>
                    <MsgType><![CDATA[text]]></MsgType>
                    <Content><![CDATA[{$content}]]></Content>
                </xml>";
        exit;
    }
    
    public function response_2_customer_service(){
        if(!$this->data){
            return;
        }
    
        $now = time();
        echo "<xml>
                <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                <CreateTime>{$now}</CreateTime>
                <MsgType><![CDATA[transfer_customer_service]]></MsgType>
            </xml>";
    
        exit;
    }
    
    public function response_media($media_type,$media_id,$title=null,$description=null){
        switch ($media_type){
            case 'image':
                $this->response_img($media_id);
                break;
            case 'voice':
                $this->response_voice($media_id);
                break;
            case 'video':
                $this->response_video($media_id,$title,$description);
                break;
        }
    }
    
    public function response_img($media_id){
        if(!$this->data){
            return;
        }
    
        $now = time();
        echo "<xml>
                    <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                    <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                    <CreateTime>{$now}</CreateTime>
                    <MsgType><![CDATA[image]]></MsgType>
                    <Image><MediaId><![CDATA[{$media_id}]]></MediaId></Image>
                </xml>";
        exit;
    }
    
    public function response_voice($media_id){
        if(!$this->data){
            return;
        }
    
        $now = time();
        echo "<xml>
                    <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                    <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                    <CreateTime>{$now}</CreateTime>
                    <MsgType><![CDATA[voice]]></MsgType>
                    <Voice><MediaId><![CDATA[{$media_id}]]></MediaId></Voice>
                </xml>";
    
        exit;
    }
    
    public function response_video($media_id,$title='',$description=''){
        if(!$this->data){
            return;
        }
        $title = strip_tags($title);//去除html标签
        $description = strip_tags($description);//去除html标签
        $now = time();
        echo "<xml>
                    <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                    <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                    <CreateTime>{$now}</CreateTime>
                    <MsgType><![CDATA[video]]></MsgType>
                    <Video>
                        <MediaId><![CDATA[{$media_id}]]></MediaId>
                        <Title><![CDATA[{$title}]]></Title>
                        <Description><![CDATA[{$description}]]></Description>
                    </Video>
                </xml>";
    
        exit;
    }
    
    /**
     * 
     * @param WP_Post[] $posts
     */
    public function response_articles($posts){
        $count = $posts?count($posts):0;
        if($count==0){
            return;
        }
        do_action('pre_get_post_content');
        $msg = '';
        $index = 0;
        foreach ($posts as $post){
            $excerpt = $post->post_excerpt;
            if(empty($excerpt)){
            	$excerpt = $post->post_content;
            }
           
            $excerpt = mb_strimwidth(trim(strip_tags(do_shortcode($excerpt))), 0, 300,'...','utf-8');
            $link = get_permalink($post);
            $title =  mb_strimwidth(strip_tags($post->post_title), 0, 300,'...','utf-8');
            $url = get_the_post_thumbnail_url( $post,$index++==0?array(360,200):array(200,200));
            
            $msg.="<item>
                        <Title><![CDATA[{$title}]]></Title> 
                        <Description><![CDATA[{$excerpt}]]></Description>
                        <PicUrl><![CDATA[{$url}]]></PicUrl>
                        <Url><![CDATA[{$link}]]></Url>
                  </item>";
        }
        $now = time();
        echo "<xml>
                    <ToUserName><![CDATA[{$this->data['FromUserName']}]]></ToUserName>
                    <FromUserName><![CDATA[{$this->data['ToUserName']}]]></FromUserName>
                    <CreateTime>{$now}</CreateTime>
                    <MsgType><![CDATA[news]]></MsgType>
                    <ArticleCount>{$count}</ArticleCount>
                    <Articles>{$msg}</Articles>
                </xml>";
        exit;
    }
}