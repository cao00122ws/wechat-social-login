<?php 

if (! defined('ABSPATH'))
    exit();

require_once 'class-wechat-material-fixed-pusher.php';
class XH_Social_Wechat_Msg_Mass_Pusher extends XH_Social_Wechat_Material_Fixed_Pusher{
 
    public function push_articles(array $post_ids){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        //获取永久素材
        $response =parent::push_articles($post_ids);
        if($response instanceof XH_Social_Error){
            return $response;
        }
        
        try {
            $data =json_encode(array(
                'filter'=>array(
                    'is_to_all'=>true
                ),
                'mpnews'=>array(
                    'media_id'=>$response['media_id']
                ),
                'msgtype'=>'mpnews',
                'send_ignore_reprint'=>1
            ),JSON_UNESCAPED_UNICODE);
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push news!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function push_text($txt){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        try {
            $data =json_encode(array(
                'filter'=>array(
                    'is_to_all'=>true
                ),
                'text'=>array(
                    'content'=>$txt
                ),
                'msgtype'=>'text',
                'send_ignore_reprint'=>1
            ),JSON_UNESCAPED_UNICODE);
    
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push news!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function push_media($post_id){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        $response = $this->push_fixed_media($post_id);
        if($response instanceof XH_Social_Error){
            return $response;
        }
        
        $data=null;
        $type = $this->get_meida_type($response['mime_type']);
        switch($type){
            case 'voice':
                $data =json_encode(array(
                    'filter'=>array(
                        'is_to_all'=>true
                    ),
                    'voice'=>array(
                        'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'voice',
                    'send_ignore_reprint'=>1
                ),JSON_UNESCAPED_UNICODE);
                break;
            case 'image':
                $data =json_encode(array(
                    'filter'=>array(
                        'is_to_all'=>true
                    ),
                    'image'=>array(
                        'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'image',
                    'send_ignore_reprint'=>1
                ),JSON_UNESCAPED_UNICODE);
                break;
            case 'video':
               try {
                   $data =json_encode(array(
                       'media_id'=>$response['media_id'],
                       'title'=>$response['title'],
                       'description'=>$response['desc'],
                   ),JSON_UNESCAPED_UNICODE);
                   
                   $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/media/uploadvideo?access_token={$access_token}",$data);
                   $error = new XH_Social_Wechat_Error($this->wechat_token);
                   $response =  $error->validate($response);
                   if($response instanceof XH_Social_Error){
                       return $response;
                   }
               } catch (Exception $e) {
                   XH_Social_Log::error($e);
                   return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push news!detail error:%s,',XH_SOCIAL),$e->getMessage()));
               }
                
                $data =json_encode(array(
                    'filter'=>array(
                        'is_to_all'=>true
                    ),
                    'mpvideo'=>array(
                        'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'mpvideo',
                    'send_ignore_reprint'=>1
                ),JSON_UNESCAPED_UNICODE);
                break;
            default:
                return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$type));
        }
        
        try {
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when push news!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function preview_articles($openid,array $post_ids){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
        
        $response = parent::push_articles($post_ids);
        if($response instanceof XH_Social_Error){
            return $response;
        }
        
        try {
            $data =json_encode(array(
                'touser'=>$openid,
                'mpnews'=>array(
                    'media_id'=>$response['media_id']
                ),
                'msgtype'=>'mpnews'
            ),JSON_UNESCAPED_UNICODE);
        
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when preview news!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function preview_text($openid,$txt){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
    
        try {
            $data =json_encode(array(
                'touser'=>$openid,
                'text'=>array(
                    'content'=>$txt
                ),
                'msgtype'=>'text'
            ),JSON_UNESCAPED_UNICODE);
    
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when preview news!detail error:%s',XH_SOCIAL),$e->getMessage()));
        }
    }
    
    public function preview_media($openid,$post_id){
        $retry =2;
        $access_token = $this ->wechat_token->access_token($retry);
        if($access_token instanceof XH_Social_Error){
            return $access_token;
        }
    
        $response = $this->push_fixed_media($post_id);
        if($response instanceof XH_Social_Error){
            return $response;
        }
    
        $data=null;
        $type = $this->get_meida_type($response['mime_type']);
        switch($type){
            case 'voice':
                $data =json_encode(array(
                    'touser'=>$openid,
                    'voice'=>array(
                        'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'voice'
                ),JSON_UNESCAPED_UNICODE);
                break;
            case 'image':
                $data =json_encode(array(
                    'touser'=>$openid,
                    'image'=>array(
                    'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'image'
                ),JSON_UNESCAPED_UNICODE);
                break;
            case 'video':
                $data =json_encode(array(
                    'touser'=>$openid,
                    'mpvideo'=>array(
                        'media_id'=>$response['media_id']
                    ),
                    'msgtype'=>'mpvideo'
                ),JSON_UNESCAPED_UNICODE);
                break;
            default:
                return XH_Social_Error::error_custom(sprintf(__('Media source is invalid(%s)!',XH_SOCIAL),$type));
        }
    
        try {
            $response = XH_Social_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/mass/preview?access_token={$access_token}",$data);
            $error = new XH_Social_Wechat_Error($this->wechat_token);
            return $error->validate($response);
        } catch (Exception $e) {
            XH_Social_Log::error($e);
            return XH_Social_Error::error_custom(sprintf(__('Something is wrong when preivew media!detail error:%s,',XH_SOCIAL),$e->getMessage()));
        }
    }
}