<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once XH_SOCIAL_DIR.'/includes/abstracts/abstract-xh-schema.php';
class XH_Social_Channel_Wechat_Model_Sync extends Abstract_XH_Social_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Social_Schema::init()
     */
    public function init(){
        $this->on_version_102();
    }

    public function on_version_102(){
        $collate=$this->get_collate();
        global $wpdb;
        

        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}xh_social_channel_wechat_msg`(
            `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
            `parent_id` BIGINT(20) NULL DEFAULT NULL,
            `msg_id` varchar(256) NULL DEFAULT NULL,
            `openid` varchar(256) NULL DEFAULT NULL,
            `user_ID` BIGINT(20) NULL DEFAULT NULL,
            `user_info` text NULL DEFAULT NULL,
            `content` text NULL DEFAULT NULL,
            `msg_type` varchar(32) NOT NULL DEFAULT 'text',
            `created_time` BIGINT(20) NOT NULL,
            `status` varchar(16) NOT NULL DEFAULT 'publish',
            PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}xh_social_channel_wechat_event`(
           `id` varchar(32) NOT NULL,
            `content` text NULL DEFAULT NULL,
            `msg_type` varchar(32) NOT NULL DEFAULT 'text',
            PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}xh_social_channel_wechat_material`(
            `id` varchar(32) NOT NULL,
            `posts` text NULL DEFAULT NULL,
            `media_id` text NULL DEFAULT NULL,
            `created_time` datetime NOT NULL,
            `material_type` varchar(32) NOT NULL DEFAULT 'fixed',
            PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            XH_Social_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}
    
 class XH_Social_Wechat_Msg_Handler{
     public static function update($msg_id,$action){
         global $wpdb;
         switch ($action){
             case 'restore':
                 $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_msg", array(
                     'status'=>'publish'
                 ), array(
                     'id'=>$msg_id
                 ));
                 break;
             case 'delete':
                 $wpdb->delete("{$wpdb->prefix}xh_social_channel_wechat_msg", array(
                     'id'=>$msg_id
                 ));
                 break;
             case 'trash':
                 $wpdb->update("{$wpdb->prefix}xh_social_channel_wechat_msg", array(
                     'status'=>'trash'
                 ), array(
                     'id'=>$msg_id
                 ));
                  break;
         }
         if(!empty($wpdb->last_error)){
             return XH_Social_Error::error_custom($wpdb->last_error);
         }
         return XH_Social_Error::success();
     }
 }  