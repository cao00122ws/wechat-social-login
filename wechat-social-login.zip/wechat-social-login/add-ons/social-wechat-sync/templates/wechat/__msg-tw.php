<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
$data = XH_Social_Temp_Helper::clear('atts','templates');
$request = $data['data'];
$context = $data['context'];
if(!defined('WSOCIAL_WECHAT_MSG_TW_STYLE')){
    define('WSOCIAL_WECHAT_MSG_TW_STYLE', 1);
    ?>
    <style type="text/css">
        .xh-qfbox{width: 400px;border:1px solid #eee;border-radius: 4px;}
        .xh-top-img{position: relative;}
        .xh-top-img img{max-width: 100%;}
        .xh-top-title{background: rgba(0,0,0,0.4); width: 100%;font-size:16px;position: absolute;bottom: 0;left: 0;padding: 10px 0}
        .xh-del{padding:5px 10px;border-radius: 4px;border:1px solid #eee;position: absolute;right:-60px;top:40%;background: rgba(255,255,255,0.6);text-decoration: none;color: #ff0000;}
        .xh-top-title .ddd{padding: 0px 15px;}
        .xh-items{display: flex;justify-content: space-between;align-items:flex-start;border-bottom: 1px solid #ddd;position: relative;}
        .xh-items-left{flex:0 0 76%;padding:2%;} 
        .xh-items-right{flex:0 0 16%;padding:2%;} 
        .xh-items-right img{max-width: 100%;}
        .select2-container {width: 200px !important;}
    </style>
    <?php 
}
?>
<div style="min-height:80px;">
    <div class="xh-qfbox"  id="wechat-menu-tw-preview-<?php echo $context?>"></div>
    <div>
    	<select class="wsocial-search" id="search-wechat-menu-tw-<?php echo $context?>" data-type='' name="post" data-sortable="true" data-placeholder="<?php echo __( 'Search for a post(ID/post_title)&hellip;', XH_SOCIAL); ?>" data-allow_clear="true">
    </select>
    <button type="button" class="button" id="wechat-menu-tw-add-<?php echo $context?>"><?php echo __('Add',XH_SOCIAL)?></button>
    </div>
</div>
<script type="text/javascript">
	<?php 
	   $msg_content = array();
	   if($request){
	       $msg_content =json_decode($request,true);
	       if(!$msg_content||!is_array($msg_content)){
	           $msg_content=array();
	       }
	   }
	?>
	(function($){
		if(window.wsocial_function_on_obj_search){
			window.wsocial_function_on_obj_search('#search-wechat-menu-tw-<?php echo $context?>');
		}
		
		window.wechat_menu_tx_<?php echo $context?> = <?php echo json_encode($msg_content,JSON_UNESCAPED_UNICODE); ?>;
		window.generate_wechat_menu_tx_<?php echo $context?>=function(){
			var $container = $('#wechat-menu-tw-preview-<?php echo $context?>').empty();
			var html='';
			for(var index=0;index<window.wechat_menu_tx_<?php echo $context?>.length;index++){
				var menu = window.wechat_menu_tx_<?php echo $context?>[index];
				if(index==0){
					html+='<div class="xh-top-img wechat-menu-tx-item" id="wechat-menu-tx-<?php echo $context?>-'+index+'">\
        				          <img src="'+menu.img+'" />\
        				          <div class="xh-top-title"><span class="ddd">'+menu.post_title+'</span></div>\
        				          <a href="javascript:void(0);" onclick="window.on_wechat_menu_tx_<?php echo $context?>_remove('+index+');" class="xh-del"><?php echo __('remove',XH_SOCIAL)?></a>\
        				   </div>';
				}else{
					html+='<div class="xh-items wechat-menu-tx-item"  id="wechat-menu-tx-<?php echo $context?>-'+index+'">\
        				        <div class="xh-items-left">'+menu.post_title+'</div>\
        				        <div class="xh-items-right"><img src="'+menu.img+'"></div>\
        				        <a href="javascript:void(0);" onclick="window.on_wechat_menu_tx_<?php echo $context?>_remove('+index+');" class="xh-del"><?php echo __('remove',XH_SOCIAL)?></a>\
        				  	</div>';
				}
			}

			$container.html(html);
		}
		window.on_wechat_menu_tx_<?php echo $context?>_remove=function(_index){
			var new_menus = [];
			for(var index=0;index<window.wechat_menu_tx_<?php echo $context?>.length;index++){
				var menu = window.wechat_menu_tx_<?php echo $context?>[index];
				if(index!=_index){
					new_menus.push(menu);
				}
			}

			window.wechat_menu_tx_<?php echo $context?>=new_menus;
			window.generate_wechat_menu_tx_<?php echo $context?>();
		}
		window.generate_wechat_menu_tx_<?php echo $context?>();
		$('#wechat-menu-tw-add-<?php echo $context?>').click(function(){
			var data={
				id:$('#search-wechat-menu-tw-<?php echo $context?>').val()
			};

			if($('#wechat-menu-tw-preview-<?php echo $context?> .wechat-menu-tx-item').length>=8){
				alert('图文消息:一个图文消息支持1到8条图文');return;
			}
			
			$('#wpbody-content').loading();
			$(document).trigger('wsocial_wechat_msg_tw_loading_start');
			$.ajax({
				url:'<?php echo XH_Social_Add_On_Social_Wechat_Sync::instance()->ajax_url(array('action'=>"xh_social_{$addon->id}",'tab'=>'add_menu_tw_post'),true,true)?>',
				type:'post',
				timeout:120*1000,
				async:true,
				data:data,
				cache:false,
				dataType:'json',
				complete:function(){
					$('#wpbody-content').loading('hide');
					$(document).trigger('wsocial_wechat_msg_tw_loading_end');
				},
				success:function(e){
					if(e.errcode!=0){
						alert(e.errmsg);
						return;
					}

					window.wechat_menu_tx_<?php echo $context?>.push(e.data);
					window.generate_wechat_menu_tx_<?php echo $context?>();
				},
				error:function(e){
					console.error(e.responseText);
					alert('<?php echo __( 'System error while add menu !', XH_SOCIAL); ?>');
				}
			});
		});
	})(jQuery);
</script>