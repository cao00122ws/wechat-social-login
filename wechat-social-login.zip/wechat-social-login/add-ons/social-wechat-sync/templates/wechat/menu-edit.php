<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$data = XH_Social_Temp_Helper::clear('atts','templates');
$config = $data['request'];
$addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
$context =  $data['context'];

$request = shortcode_atts(array(
    'is_submenu'=>0,
    'name'=>__('New menu',XH_SOCIAL),
    'menu_type'=>null,
    'msg_type'=>null,
    'msg_content'=>null
), $config) ;

?>
<li data-context="<?php echo $context;?>" class="menu-item <?php echo $request['is_submenu']?'menu-item-depth-1':'menu-item-depth-0'?> menu-item-page menu-item-edit-inactive" id="menu-<?php echo $context?>" >
	<div class="menu-item-bar">
		<div class="menu-item-handle ui-sortable-handle">
			<span class="item-title"><span class="menu-item-title" id="menu-title-<?php echo $context?>"><?php echo $request['name'];?></span></span>
			<span class="item-controls">
				<a class="item-edit" href="javascript:void(0);" id="btn-menu-edit-<?php echo $context?>"><span class="screen-reader-text"><?php echo __('Edit',XH_SOCIAL)?></span></a>
			</span>
		</div>
	</div>
	
	<div class="menu-item-settings wp-clearfix" style="display: none;" id="menu-panel-<?php echo $context?>">
		<p class="description description-wide">
			<label><?php echo __('Menu name',XH_SOCIAL)?></label>
			<br>
			
			<?php 
			require_once $addon->dir.'/includes/emoji-editor/class-emoji-editor.php';
    		XH_Social_Emoji_Editor::editor($request['name'],$context.'menu_name',array('style'=>'height:24px;min-height:24px;'));
    		?>
		</p>
		
		<div id="menu-<?php echo $context?>-content">
    		<p class="description description-wide">
    			<label><?php echo __('Menu content',XH_SOCIAL)?></label>
    			<br>
    			<div>
    				<label><input class="social-wechat-menu-type-<?php echo $context?>" <?php echo !$request['menu_type']||$request['menu_type']=='msg'?'checked':'';?> name="social-wechat-menu-type-<?php echo $context?>" value="msg" type="radio" /> 发送消息</label> 
    				<label><input class="social-wechat-menu-type-<?php echo $context?>" <?php echo $request['menu_type']=='link'?'checked':'';?> value="link" name="social-wechat-menu-type-<?php echo $context?>" type="radio" /> 跳转网页</label>  
    				<label><input class="social-wechat-menu-type-<?php echo $context?>" <?php echo $request['menu_type']=='app'?'checked':'';?> value="app" name="social-wechat-menu-type-<?php echo $context?>" type="radio" /> 跳转小程序</label>
    				<label><input class="social-wechat-menu-type-<?php echo $context?>" <?php echo $request['menu_type']=='event'?'checked':'';?> value="event" name="social-wechat-menu-type-<?php echo $context?>" type="radio" /> 自定义事件</label>
    			</div>
    		</p>
    		<p class="description description-wide" id="social-wechat-menu-type-container">
    			<div id="social-wechat-menu-type-<?php echo $context?>-msg" class="social-wechat-menu-type-<?php echo $context?>-item" style="display:none;">
    				<?php 
    				    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg.php',array(
    				        'request'=>$request['menu_type']=='msg'?$request:array(),
    				        'context'=>$context
    				    ));
    				?>
    			</div>
    			
    			<div id="social-wechat-menu-type-<?php echo $context?>-link" class="social-wechat-menu-type-<?php echo $context?>-item" style="display:none;">
    				<label>页面地址</label>
    				<br>
    				<input type="text" id="menu-link-<?php echo $context?>" class="widefat edit-menu-item-title" value="<?php echo $request['menu_type']=='link'?esc_attr($request['msg_content']):null;?>" />
    				<div class="help-block">订阅者点击该子菜单会跳到以上链接</div>
    			</div>
    			
    			<div id="social-wechat-menu-type-<?php echo $context?>-app" class="social-wechat-menu-type-<?php echo $context?>-item" style="display:none;">
    				<label>小程序地址</label>
    				<br>
    				<input type="text" placeholder="APPID,pagepath" id="menu-app-<?php echo $context?>" class="widefat edit-menu-item-title" value="<?php echo $request['menu_type']=='app'?esc_attr($request['msg_content']):null;?>" />
    				<div class="help-block">订阅者点击该子菜单会跳到以上小程序</div>
    			</div>
    			<div id="social-wechat-menu-type-<?php echo $context?>-event" class="social-wechat-menu-type-<?php echo $context?>-item" style="display:none;">
    				<label>事件</label>
    				<br>
    				<?php 
    				  $events = XH_Social_Add_On_Social_Wechat_Sync::instance()->get_menu_events();
    				?>
    				<select id="menu-event-<?php echo $context?>" class="widefat edit-menu-item-title">
    					<?php foreach ($events as $event=>$desc){
    					    ?><option value="<?php echo $event;?>" <?php echo $request['menu_type']=='event'&&$request['msg_content']==$event?'selected':null;?>><?php echo $desc;?></option><?php 
    					}?>
    				</select>
    				<div class="help-block">订阅者点击该子菜单会触发选中事件</div>
    			</div>
    		</p>
		</div>
		<p class="description description-wide">
			<button class="button" type="button" style="float:right;" id="btn-menu-delete-<?php echo $context;?>"><?php echo __('Remove menu',XH_SOCIAL)?></button>
		</p>
		<script type="text/javascript">
		
			(function($){
				$('#wsocial-emoji-editor-<?php echo $context.'menu_name'?>').keyup(function(){
					//TODO 加入表情包后，此处会有所修改
					$('#menu-title-<?php echo $context?>').html($('#wsocial-emoji-editor-<?php echo $context.'menu_name'?>').html());
				});
				
				$('#wsocial-emoji-editor-<?php echo $context.'menu_name'?>').keyup();
				
				$('#menu-<?php echo $context?>').attr('data',<?php echo $config?json_encode($config):'[]'?>);
				$('#btn-menu-edit-<?php echo $context?>').click(function(){
					if($('#menu-<?php echo $context?>').hasClass('menu-item-edit-inactive')){
						$('#menu-<?php echo $context?>').removeClass('menu-item-edit-inactive').addClass('menu-item-edit-active');
						$('#menu-panel-<?php echo $context?>').slideDown();
					}else{
						$('#menu-<?php echo $context?>').removeClass('menu-item-edit-active').addClass('menu-item-edit-inactive');
						$('#menu-panel-<?php echo $context?>').slideUp();
					}
				});
				
				$('.social-wechat-menu-type-<?php echo $context?>').change(function(){
					var menu_type = $('.social-wechat-menu-type-<?php echo $context?>:checked').val();
					$('.social-wechat-menu-type-<?php echo $context?>-item').css({display:'none'});
					$('#social-wechat-menu-type-<?php echo $context?>-'+menu_type).show();
				});
				$('.social-wechat-menu-type-<?php echo $context?>:checked').change();

				$('#btn-menu-delete-<?php echo $context;?>').click(function(){
					if(!confirm('<?php echo __('Are you sure?',XH_SOCIAL)?>')){
						return;
					}

					if($('#menu-<?php echo $context?>').hasClass('menu-item-depth-0')){
    					//删除当前菜单的下级
    					$next = $('#menu-<?php echo $context?>').next('.menu-item');
    					var remove_list = [];
    					while($next.length>0&&!$next.hasClass('menu-item-depth-0')){
    						remove_list.push($next);
    						$next = $next.next('.menu-item');
    					}
    					
    					for(var index=0;index<remove_list.length;index++){
    						wpNavMenu.removeMenuItem(remove_list[index]);
    					}
    					
    					remove_list=[];
					}
					
					wpNavMenu.removeMenuItem($('#menu-<?php echo $context?>'));
				});

			})(jQuery);
		</script>
	</div>
	<ul class="menu-item-transport" id="menu-<?php echo $context?>-children"></ul>
</li>