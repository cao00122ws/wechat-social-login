<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$data = XH_Social_Temp_Helper::clear('atts','templates');
$request = $data['request'];
$context = $data['context'];
$addon = XH_Social_Add_On_Social_Wechat_Sync::instance();
$request = shortcode_atts(array(
    'msg_type'=>null,
    'msg_content'=>null
), $request);
?>
<div>
	<label><input class="social-wechat-menu-type-<?php echo $context?>-msg" value="tw" <?php echo !$request['msg_type']||$request['msg_type']=='tw'?'checked':'';?> name="social-wechat-menu-type-<?php echo $context?>-msg" type="radio" /> 图文消息</label> 
	<label><input class="social-wechat-menu-type-<?php echo $context?>-msg" value="txt" <?php echo $request['msg_type']=='txt'?'checked':'';?> name="social-wechat-menu-type-<?php echo $context?>-msg" type="radio" /> 文字</label>  
	<label><input class="social-wechat-menu-type-<?php echo $context?>-msg" value="img" <?php echo $request['msg_type']=='img'?'checked':'';?> name="social-wechat-menu-type-<?php echo $context?>-msg" type="radio" /> 图像/音频/视频</label>
</div>

<div id="social-wechat-menu-type-<?php echo $context?>-msg-container">
	<div id="social-wechat-menu-type-<?php echo $context?>-msg-tw" class="social-wechat-menu-type-<?php echo $context?>-msg-item" style="display:none;">
		<?php 
		    echo XH_Social::instance()->WP->requires($addon->dir, 'wechat/__msg-tw.php',array(
		        'data'=>$request['msg_type']=='tw'&&isset($request['msg_content'])?$request['msg_content']:null,
		        'context'=>$context
		    ));
		?>
	</div>
	<div id="social-wechat-menu-type-<?php echo $context?>-msg-txt" class="social-wechat-menu-type-<?php echo $context?>-msg-item" style="display:none;">
		<?php require_once $addon->dir.'/includes/emoji-editor/class-emoji-editor.php';
		XH_Social_Emoji_Editor::editor($request['msg_type']=='txt'?$request['msg_content']:null,$context.'_tw_txt');
		?>
	</div>
	<?php 
	   $img_config=array();
	   if($request['msg_type']=='img'){
	       $img_config = json_decode($request['msg_content'],true);
	       if(!$img_config||!is_array($img_config)){$img_config=array();}
	   }
	?>
	<div id="social-wechat-menu-type-<?php echo $context?>-msg-img" class="social-wechat-menu-type-<?php echo $context?>-msg-item" style="display:none;">
		<video controls  id="social-wechat-menu-type-<?php echo $context?>-msg-img-val" style="min-width:100px;min-height:100px;max-width:150px;max-height:150px;" src="<?php echo isset($img_config['src'])?esc_attr($img_config['src']):null;?>" poster="<?php echo isset($img_config['poster'])?esc_attr($img_config['poster']):null;?>" data-id="<?php echo isset($img_config['ID'])?esc_attr($img_config['ID']):null;?>"></video>
		
		<br/>
		<input type="button" class="button" id="social-wechat-menu-type-<?php echo $context?>-msg-img-upload" value="选择(图像/音频/视频)" />
		
		<script type="text/javascript">
		(function($){
			$('#social-wechat-menu-type-<?php echo $context?>-msg-img-upload').click(function() {  
				var send_attachment_bkp = wp.media.editor.send.attachment;
			    wp.media.editor.send.attachment = function(props, attachment) {
				    if(typeof attachment.image!='undefined'){
				    	$('#social-wechat-menu-type-<?php echo $context?>-msg-img-val').attr({
				        	'src':attachment.url,
				        	'poster':attachment.image.src,
				        	'data-id':attachment.id
						});
					}else{
						$('#social-wechat-menu-type-<?php echo $context?>-msg-img-val').attr({
				        	'src':null,
				        	'poster':attachment.url,
				        	'data-id':attachment.id
						});
					}
			        
			        wp.media.editor.send.attachment = send_attachment_bkp;
			    }
			    wp.media.editor.open();
			    return false;    
		    });
		})(jQuery);
		</script>
	</div>
</div>
<script type="text/javascript">
	(function($){
		$('.social-wechat-menu-type-<?php echo $context?>-msg').change(function(){
			var menu_type = $('.social-wechat-menu-type-<?php echo $context?>-msg:checked').val();
			$('.social-wechat-menu-type-<?php echo $context?>-msg-item').css({display:'none'});
			$('#social-wechat-menu-type-<?php echo $context?>-msg-'+menu_type).show();
		});
		$('.social-wechat-menu-type-<?php echo $context?>-msg:checked').change();
		
		window.on_wechat_menu_tw_submit_<?php echo $context?>=function(menu){
			var context = '<?php echo $context?>';
			menu.msg_type=$('.social-wechat-menu-type-'+context+'-msg:checked').val();
			
			switch(menu.msg_type){
				default:
					alert('unknow msg type!');
					break;
				case 'tw':
					menu.msg_content = JSON.stringify(window.wechat_menu_tx_<?php echo $context?>);
					break;
				case 'txt':
					menu.msg_content = $('#wsocial-emoji-editor-<?php echo $context.'_tw_txt'?>').html();
					break;
				case 'img':
					menu.msg_content =JSON.stringify({
						poster:$('#social-wechat-menu-type-'+context+'-msg-img-val').attr('poster'),
						src:$('#social-wechat-menu-type-'+context+'-msg-img-val').attr('src'),
						ID:$('#social-wechat-menu-type-'+context+'-msg-img-val').attr('data-id')
					}); ;
					break;
			}
		}
	})(jQuery);
</script>
