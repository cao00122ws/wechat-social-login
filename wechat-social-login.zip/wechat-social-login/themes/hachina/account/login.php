<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
require '_common.php';