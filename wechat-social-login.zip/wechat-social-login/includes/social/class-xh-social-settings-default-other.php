<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * Social Admin
 *
 * @since 1.0.0
 * @author ranj
 */
class XH_Social_Settings_Default_Other_Default extends Abstract_XH_Social_Settings{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
        return self::$_instance;
    }

    private function __construct(){
        $this->id='settings_default_other_default';
        $this->title=__('Basic Settings',XH_SOCIAL);

        $this->init_form_fields();
    }

    public function init_form_fields(){
        $this->form_fields =array(
            'logo'=>array(
                'title'=>__('Website Logo',XH_SOCIAL),
                'type'=>'image',
                'default'=>XH_SOCIAL_URL.'/assets/image/wordpress-logo.png'
            ),
            'bingbg'=>array(
                'title'=>'调用Bing背景作为登录页背景',
                'type'=>'checkbox'
            ),
            'enable_emoji_filter'=>array(
                'title'=>'昵称表情符(emoji)',
                'type'=>'checkbox',
                'label'=>'过滤',
                'default'=>'yes',
                'description'=>'<b style="color:red;">注意</b>: 如需保留表情符，条件：mysql(5.5.3+)utf8mb4'
            ),
            'captcha'=>array(
                'title'=>'验证码模式',
                'type'=>'select',
                'func'=>true,
                'default'=>'default',
                'options'=>function(){
                    $captchats =  XH_Social::instance()->WP->get_captchas();
                    $options = array();
                    foreach ($captchats as $captcha){
                        $options[$captcha->id] = $captcha->title;
                    };
                    return $options;
                },
            )
        );
    }
}

abstract class Abstract_WSocial_Captcha{
    public $title;
    public $id;
}

class WSocial_Captcha extends Abstract_WSocial_Captcha{
    public $title="图形验证码";
    public $id = 'default';
  
    //生成表单验证码字段
    public function create_captcha_form($form_id, $data_name, $settings){
        $html_name = $data_name;
        $html_id = isset($settings['id']) ? $settings['id'] : ($form_id . "_" . $data_name);

        ob_start();
        ?>
        <div class="xh-input-group" style="width:100%;">
            <input name="<?php echo esc_attr($html_name); ?>" type="text" id="<?php echo esc_attr($html_id); ?>"
                   maxlength="6" class="form-control"
                   placeholder="<?php echo __('image captcha', XH_SOCIAL) ?>">
            <span class="xh-input-group-btn" style="width:96px;"><img
                    style="width:96px;height:35px;border:1px solid #ddd;background:url('<?php echo XH_SOCIAL_URL ?>/assets/image/loading.gif') no-repeat center;"
                    id="img-captcha-<?php echo esc_attr($html_id); ?>"/></span>
        </div>

        <script type="text/javascript">
            (function ($) {
                if (!$) {
                    return;
                }

                window.captcha_<?php echo esc_attr($html_id);?>_load = function () {
                    $('#img-captcha-<?php echo esc_attr($html_id);?>').attr('src', '<?php echo XH_SOCIAL_URL?>/assets/image/empty.png');
                    $.ajax({
                        url: '<?php echo XH_Social::instance()->ajax_url(array(
                            'action' => 'xh_social_captcha',
                            'social_key' => $settings['social_key']
                        ), true, true)?>',
                        type: 'post',
                        timeout: 60 * 1000,
                        async: true,
                        cache: false,
                        data: {},
                        dataType: 'json',
                        success: function (m) {
                            if (m.errcode == 0) {
                                $('#img-captcha-<?php echo esc_attr($html_id);?>').attr('src', m.data);
                            }
                        }
                    });
                };

                $('#img-captcha-<?php echo esc_attr($html_id);?>').click(function () {
                    window.captcha_<?php echo esc_attr($html_id);?>_load();
                });

                window.captcha_<?php echo esc_attr($html_id);?>_load();
            })(jQuery);
        </script>
        <?php
        XH_Social_Helper_Html_Form::generate_field_scripts($form_id, $html_name, $html_id);
        return ob_get_clean();
    }

    //验证
    public function validate_captcha($name, $datas, $settings){
        //插件未启用，那么不验证图形验证码
        $code_post = isset($_REQUEST[$name]) ? trim($_REQUEST[$name]) : '';
        if (empty($code_post)) {
            return XH_Social_Error::error_custom(__('image captcha is required!', XH_SOCIAL));
        }

        $captcha = XH_Social::instance()->session->get($settings['social_key']);
        if (empty($captcha)) {
            return XH_Social_Error::error_custom(__('Please refresh the image captcha!', XH_SOCIAL));
        }

        if (strcasecmp($captcha, $code_post) !== 0) {
            return XH_Social_Error::error_custom(__('image captcha is invalid!', XH_SOCIAL));
        }

        XH_Social::instance()->session->__unset($settings['social_key']);

        return $datas;
    }
}
?>